<template>
  <n-layout class="admin-layout" has-sider>
    <!-- Sidebar -->
    <n-layout-sider
      bordered
      collapse-mode="width"
      :collapsed-width="64"
      :width="240"
      :collapsed="collapsed"
      show-trigger
      @collapse="collapsed = true"
      @expand="collapsed = false"
      class="admin-sider"
    >
      <!-- Logo -->
      <div class="sider-logo" @click="router.push('/admin/dashboard')">
        <n-icon :component="BookOutline" size="24" color="#fff" />
        <span v-if="!collapsed" class="sider-logo-text">图书商城管理</span>
      </div>

      <!-- Menu -->
      <n-menu
        :collapsed="collapsed"
        :collapsed-width="64"
        :collapsed-icon-size="22"
        :options="menuOptions"
        :value="activeKey"
        @update:value="handleMenuSelect"
      />
    </n-layout-sider>

    <n-layout>
      <!-- Header -->
      <n-layout-header bordered class="admin-header">
        <div class="admin-header-inner">
          <n-breadcrumb>
            <n-breadcrumb-item>管理后台</n-breadcrumb-item>
            <n-breadcrumb-item>{{ currentTitle }}</n-breadcrumb-item>
          </n-breadcrumb>

          <div class="admin-header-right">
            <n-dropdown :options="adminMenuOptions" @select="handleAdminMenu">
              <n-button quaternary>
                <template #icon>
                  <n-icon :component="PersonCircleOutline" />
                </template>
                {{ userStore.userInfo?.nickname || '管理员' }}
              </n-button>
            </n-dropdown>
          </div>
        </div>
      </n-layout-header>

      <!-- Content -->
      <n-layout-content class="admin-content">
        <router-view />
      </n-layout-content>
    </n-layout>
  </n-layout>
</template>

<script setup lang="ts">
import { ref, computed, h } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import {
  NLayout, NLayoutSider, NLayoutHeader, NLayoutContent,
  NMenu, NIcon, NButton, NDropdown, NBreadcrumb, NBreadcrumbItem,
  useMessage,
} from 'naive-ui'
import type { MenuOption } from 'naive-ui'
import {
  BookOutline, GridOutline, LibraryOutline, ReceiptOutline,
  PeopleOutline, BarChartOutline, PersonCircleOutline,
  LogOutOutline, HomeOutline,
} from '@vicons/ionicons5'
import { useUserStore } from '@/stores/user'
import { useCartStore } from '@/stores/cart'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()
const cartStore = useCartStore()
const message = useMessage()
const collapsed = ref(false)

const activeKey = computed(() => route.name as string)

const currentTitle = computed(() => {
  const map: Record<string, string> = {
    AdminDashboard: '控制台',
    AdminBooks: '图书管理',
    AdminCategories: '分类管理',
    AdminOrders: '订单管理',
    AdminUsers: '用户管理',
    AdminStats: '数据统计',
  }
  return map[route.name as string] || ''
})

const renderIcon = (icon: any) => () => h(NIcon, null, { default: () => h(icon) })

const menuOptions: MenuOption[] = [
  {
    label: '控制台',
    key: 'AdminDashboard',
    icon: renderIcon(GridOutline),
  },
  {
    label: '图书管理',
    key: 'AdminBooks',
    icon: renderIcon(BookOutline),
  },
  {
    label: '分类管理',
    key: 'AdminCategories',
    icon: renderIcon(LibraryOutline),
  },
  {
    label: '订单管理',
    key: 'AdminOrders',
    icon: renderIcon(ReceiptOutline),
  },
  {
    label: '用户管理',
    key: 'AdminUsers',
    icon: renderIcon(PeopleOutline),
  },
  {
    label: '数据统计',
    key: 'AdminStats',
    icon: renderIcon(BarChartOutline),
  },
]

const adminMenuOptions = [
  { label: '返回前台', key: 'home', icon: renderIcon(HomeOutline) },
  { type: 'divider', key: 'd1' },
  { label: '退出登录', key: 'logout', icon: renderIcon(LogOutOutline) },
]

function handleMenuSelect(key: string) {
  router.push({ name: key })
}

function handleAdminMenu(key: string) {
  if (key === 'home') {
    router.push('/')
  } else if (key === 'logout') {
    userStore.logout()
    cartStore.clear()
    message.success('已退出登录')
    router.push('/admin/login')
  }
}
</script>

<style scoped>
.admin-layout {
  height: 100vh;
}

.admin-sider {
  background: #1e1e2e !important;
}

:deep(.n-layout-sider-scroll-container) {
  background: #1e1e2e;
}

:deep(.n-layout-toggle-button) {
  background: #2a2a3e !important;
  color: #fff !important;
  border-color: rgba(255, 255, 255, 0.1) !important;
}

:deep(.n-menu) {
  background: transparent !important;
  --n-item-text-color: rgba(255, 255, 255, 0.65) !important;
  --n-item-text-color-hover: #fff !important;
  --n-item-text-color-active: #fff !important;
  --n-item-text-color-active-hover: #fff !important;
  --n-item-icon-color: rgba(255, 255, 255, 0.5) !important;
  --n-item-icon-color-hover: #fff !important;
  --n-item-icon-color-active: #fff !important;
  --n-item-icon-color-active-hover: #fff !important;
  --n-item-color-hover: rgba(255, 255, 255, 0.08) !important;
  --n-item-color-active: rgba(255, 255, 255, 0.12) !important;
  --n-item-color-active-hover: rgba(255, 255, 255, 0.15) !important;
  --n-item-color-active-collapsed: rgba(255, 255, 255, 0.12) !important;
  --n-arrow-color: rgba(255, 255, 255, 0.4) !important;
  --n-arrow-color-hover: #fff !important;
  --n-arrow-color-active: #fff !important;
  --n-arrow-color-active-hover: #fff !important;
  --n-border-color-horizontal: transparent !important;
}

:deep(.n-menu-item-content) {
  color: rgba(255, 255, 255, 0.7) !important;
  font-weight: 500;
  font-size: 14px;
}

:deep(.n-menu-item-content .n-icon) {
  color: rgba(255, 255, 255, 0.55) !important;
}

:deep(.n-menu-item-content--selected),
:deep(.n-menu-item-content--selected .n-icon) {
  color: #fff !important;
}

:deep(.n-menu-item-content--selected) {
  background: rgba(255, 255, 255, 0.12) !important;
  border-radius: 8px;
}

:deep(.n-menu-item-content:hover),
:deep(.n-menu-item-content:hover .n-icon) {
  color: #fff !important;
}

:deep(.n-menu-item-content:hover) {
  background: rgba(255, 255, 255, 0.06) !important;
}

.sider-logo {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 20px 16px;
  cursor: pointer;
  border-bottom: 1px solid rgba(255,255,255,0.08);
  margin-bottom: 8px;
}

.sider-logo-text {
  font-size: 16px;
  font-weight: 700;
  color: #fff;
  white-space: nowrap;
}

.admin-header {
  background: #fff;
  padding: 0 24px;
  height: 56px;
  display: flex;
  align-items: center;
}

.admin-header-inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
}

.admin-header-right {
  display: flex;
  align-items: center;
  gap: 12px;
}

.admin-content {
  padding: 24px;
  background: #FAFAF8;
  min-height: calc(100vh - 56px);
  overflow-y: auto;
}
</style>
