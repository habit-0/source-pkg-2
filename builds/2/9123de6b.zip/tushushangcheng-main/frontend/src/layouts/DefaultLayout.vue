<template>
  <n-layout class="layout-root">
    <!-- Top Navigation -->
    <n-layout-header class="app-header" bordered>
      <div class="header-inner">
        <!-- Logo -->
        <div class="logo" @click="router.push('/')">
          <span class="logo-text">图书商城</span>
        </div>

        <!-- Navigation Links -->
        <nav class="nav-links">
          <span
            class="nav-link"
            :class="{ active: route.path === '/' }"
            @click="router.push('/')"
          >首页</span>
          <span
            class="nav-link"
            :class="{ active: route.path === '/books' }"
            @click="router.push('/books')"
          >全部图书</span>
          <n-popover trigger="hover" :show-arrow="false" placement="bottom" style="padding: 0">
            <template #trigger>
              <span class="nav-link">分类</span>
            </template>
            <div class="cat-dropdown">
              <div
                v-for="cat in categories"
                :key="cat.id"
                class="cat-dropdown-item"
                @click="filterByCategory(cat.id)"
              >
                {{ cat.name }}
              </div>
            </div>
          </n-popover>
        </nav>

        <!-- Search Bar -->
        <div class="search-bar">
          <n-input
            v-model:value="keyword"
            placeholder="搜索书名、作者..."
            clearable
            @keyup.enter="handleSearch"
          >
            <template #prefix>
              <n-icon :component="SearchOutline" color="#9B9B9B" />
            </template>
          </n-input>
        </div>

        <!-- Right Actions -->
        <div class="header-actions">
          <!-- Cart -->
          <n-badge :value="cartStore.cartCount" :max="99" :offset="[-4, 0]">
            <div class="action-btn" @click="goCart">
              <n-icon :component="CartOutline" size="20" />
            </div>
          </n-badge>

          <!-- User -->
          <template v-if="userStore.isLoggedIn">
            <n-dropdown :options="userMenuOptions" @select="handleUserMenu">
              <div class="action-btn user-btn">
                <n-avatar
                  round
                  :size="28"
                  :src="userStore.userInfo?.avatar"
                  :fallback-src="defaultAvatar"
                />
                <span class="user-name">{{ userStore.nickname }}</span>
              </div>
            </n-dropdown>
          </template>
          <template v-else>
            <n-button size="small" quaternary @click="router.push('/login')">登录</n-button>
            <n-button size="small" type="primary" @click="router.push('/register')">注册</n-button>
          </template>
        </div>
      </div>
    </n-layout-header>

    <!-- Main Content -->
    <n-layout-content class="main-content">
      <div class="content-inner">
        <router-view />
      </div>
    </n-layout-content>

    <!-- Footer -->
    <n-layout-footer class="app-footer">
      <div class="footer-inner">
        <span class="footer-brand">图书商城</span>
        <p class="footer-copy">© 2024 图书商城 · 海量图书，精选推荐</p>
      </div>
    </n-layout-footer>
  </n-layout>
</template>

<script setup lang="ts">
import { ref, onMounted, computed, h } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import {
  NLayout, NLayoutHeader, NLayoutContent, NLayoutFooter,
  NBadge, NButton, NInput, NIcon, NDropdown, NAvatar, NPopover,
  useMessage,
} from 'naive-ui'
import {
  SearchOutline, CartOutline,
  PersonOutline, ListOutline, LogOutOutline,
} from '@vicons/ionicons5'
import { useUserStore } from '@/stores/user'
import { useCartStore } from '@/stores/cart'
import { categoryApi } from '@/api/book'
import type { Category } from '@/api/book'

const router = useRouter()
const route = useRoute()
const userStore = useUserStore()
const cartStore = useCartStore()
const message = useMessage()

const keyword = ref('')
const categories = ref<Category[]>([])
const defaultAvatar = 'https://api.dicebear.com/7.x/avataaars/svg?seed=bookmall'

const userMenuOptions = [
  { label: '个人中心', key: 'profile', icon: () => h(NIcon, null, { default: () => h(PersonOutline) }) },
  { label: '我的订单', key: 'orders', icon: () => h(NIcon, null, { default: () => h(ListOutline) }) },
  { type: 'divider', key: 'd1' },
  { label: '退出登录', key: 'logout', icon: () => h(NIcon, null, { default: () => h(LogOutOutline) }) },
]

function handleUserMenu(key: string) {
  if (key === 'profile') router.push('/user')
  else if (key === 'orders') router.push('/orders')
  else if (key === 'logout') {
    userStore.logout()
    cartStore.clear()
    message.success('已退出登录')
    router.push('/')
  }
}

function handleSearch() {
  if (keyword.value.trim()) {
    router.push({ path: '/books', query: { keyword: keyword.value.trim() } })
  }
}

function goCart() {
  if (!userStore.isLoggedIn) {
    message.warning('请先登录')
    router.push('/login')
    return
  }
  router.push('/cart')
}

function filterByCategory(id: number) {
  router.push({ path: '/books', query: { category_id: id } })
}

onMounted(async () => {
  try {
    categories.value = await categoryApi.getCategories()
  } catch {
    // ignore
  }
  if (userStore.isLoggedIn) {
    cartStore.fetchCount()
  }
})
</script>

<style scoped>
.layout-root {
  min-height: 100vh;
  background: #FAFAF8;
}

/* ─── Header ─── */
.app-header {
  position: sticky;
  top: 0;
  z-index: 100;
  background: rgba(255, 255, 255, 0.92);
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  border-bottom: 1px solid #F0EDE8 !important;
  box-shadow: none;
  padding: 0;
}

.header-inner {
  display: flex;
  align-items: center;
  gap: 32px;
  padding: 0 48px;
  height: 60px;
  max-width: 1280px;
  margin: 0 auto;
  width: 100%;
}

.logo {
  cursor: pointer;
  flex-shrink: 0;
}

.logo-text {
  font-size: 20px;
  font-weight: 700;
  color: #1A1A1A;
  letter-spacing: -0.03em;
}

/* ─── Navigation ─── */
.nav-links {
  display: flex;
  align-items: center;
  gap: 4px;
  flex-shrink: 0;
}

.nav-link {
  font-size: 14px;
  color: #6B6B6B;
  padding: 6px 12px;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.15s ease;
  font-weight: 500;
  white-space: nowrap;
}

.nav-link:hover {
  color: #1A1A1A;
  background: #F5F3F0;
}

.nav-link.active {
  color: #1A1A1A;
  font-weight: 600;
}

/* ─── Category Dropdown ─── */
.cat-dropdown {
  padding: 4px;
  min-width: 120px;
}

.cat-dropdown-item {
  padding: 8px 12px;
  font-size: 13px;
  color: #4A4A4A;
  border-radius: 6px;
  cursor: pointer;
  transition: all 0.15s ease;
}

.cat-dropdown-item:hover {
  background: #F5F3F0;
  color: #1A1A1A;
}

/* ─── Search ─── */
.search-bar {
  flex: 1;
  max-width: 400px;
}

/* ─── Actions ─── */
.header-actions {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
  margin-left: auto;
}

.action-btn {
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  cursor: pointer;
  color: #6B6B6B;
  transition: all 0.15s ease;
}

.action-btn:hover {
  background: #F5F3F0;
  color: #1A1A1A;
}

.user-btn {
  width: auto;
  gap: 8px;
  padding: 4px 12px 4px 4px;
}

.user-name {
  font-size: 13px;
  font-weight: 500;
  color: #4A4A4A;
}

/* ─── Main Content ─── */
.main-content {
  min-height: calc(100vh - 140px);
  background: #FAFAF8 !important;
}

.content-inner {
  padding: 32px 48px;
  max-width: 1280px;
  margin: 0 auto;
  width: 100%;
}

/* ─── Footer ─── */
.app-footer {
  padding: 24px 48px;
  background: #FAFAF8 !important;
  border-top: 1px solid #F0EDE8;
}

.footer-inner {
  max-width: 1280px;
  margin: 0 auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.footer-brand {
  font-size: 14px;
  font-weight: 600;
  color: #1A1A1A;
  letter-spacing: -0.02em;
}

.footer-copy {
  color: #9B9B9B;
  font-size: 13px;
}

/* ─── Responsive ─── */
@media (max-width: 768px) {
  .header-inner {
    padding: 0 20px;
    gap: 16px;
  }
  .nav-links {
    display: none;
  }
  .content-inner {
    padding: 20px;
  }
}
</style>
