<template>
  <n-config-provider :theme-overrides="themeOverrides" :locale="zhCN" :date-locale="dateZhCN">
    <n-loading-bar-provider>
      <n-dialog-provider>
        <n-notification-provider>
          <n-message-provider>
            <router-view />
          </n-message-provider>
        </n-notification-provider>
      </n-dialog-provider>
    </n-loading-bar-provider>
  </n-config-provider>
</template>

<script setup lang="ts">
import {
  NConfigProvider,
  NLoadingBarProvider,
  NDialogProvider,
  NNotificationProvider,
  NMessageProvider,
  zhCN,
  dateZhCN,
  type GlobalThemeOverrides,
} from 'naive-ui'

const themeOverrides: GlobalThemeOverrides = {
  common: {
    primaryColor: '#1A1A1A',
    primaryColorHover: '#404040',
    primaryColorPressed: '#000000',
    primaryColorSuppl: '#1A1A1A',
    borderRadius: '8px',
    fontFamily: '"Inter", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    fontFamilyMono: '"JetBrains Mono", "Fira Code", Consolas, monospace',
    bodyColor: '#FAFAF8',
    baseColor: '#fff',
    borderColor: '#E8E5E0',
    dividerColor: '#F0EDE8',
    hoverColor: '#F5F3F0',
  },
  Button: {
    borderRadiusMedium: '8px',
    borderRadiusSmall: '6px',
    fontSizeMedium: '14px',
    fontSizeLarge: '15px',
  },
  Card: {
    borderRadius: '12px',
    paddingMedium: '20px 24px',
  },
  Input: {
    borderRadius: '8px',
  },
  Tag: {
    borderRadius: '20px',
  },
  Badge: {
    colorInfo: '#1A1A1A',
  },
}
</script>
