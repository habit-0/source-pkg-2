import request from './request'
import type { PageData } from './request'

export interface Category {
  id: number
  name: string
  icon: string
  sort_order: number
  parent_id: number
  description: string
}

export interface BookInventory {
  stock: number
  locked: number
}

export interface Book {
  id: number
  title: string
  author: string
  publisher: string
  isbn: string
  category_id: number
  category?: Category
  price: number
  original_price: number
  cover: string
  description: string
  tags: string
  status: number
  is_recommend: number
  is_hot: number
  sales: number
  rating: number
  inventory?: BookInventory
  created_at: string
}

export interface BookListParams {
  page?: number
  page_size?: number
  category_id?: number
  keyword?: string
  is_recommend?: number
  is_hot?: number
  sort_by?: string
}

export const categoryApi = {
  getCategories: () => request.get<any, Category[]>('/categories'),
}

export const bookApi = {
  getList: (params?: BookListParams) =>
    request.get<any, PageData<Book>>('/books', { params }),
  getDetail: (id: number) => request.get<any, Book>(`/books/${id}`),
  getHot: () => request.get<any, Book[]>('/books/hot'),
  getRecommend: () => request.get<any, Book[]>('/books/recommend'),
}

// Admin book API
export const adminBookApi = {
  getList: (params?: any) =>
    request.get<any, PageData<Book>>('/admin/books', { params }),
  create: (data: any) => request.post<any, Book>('/admin/books', data),
  update: (id: number, data: any) => request.put(`/admin/books/${id}`, data),
  delete: (id: number) => request.delete(`/admin/books/${id}`),
  getCategories: () => request.get<any, Category[]>('/admin/categories'),
  createCategory: (data: any) => request.post<any, Category>('/admin/categories', data),
  updateCategory: (id: number, data: any) => request.put(`/admin/categories/${id}`, data),
  deleteCategory: (id: number) => request.delete(`/admin/categories/${id}`),
}
