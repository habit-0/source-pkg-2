import request from './request'

export interface CartItem {
  id: number
  book_id: number
  title: string
  cover: string
  author: string
  price: number
  quantity: number
  subtotal: number
  stock: number
}

export interface CartSummary {
  items: CartItem[]
  total_count: number
  total_price: number
}

export const cartApi = {
  getCart: () => request.get<any, CartSummary>('/cart'),
  getCount: () => request.get<any, { count: number }>('/cart/count'),
  addToCart: (book_id: number, quantity: number) =>
    request.post('/cart', { book_id, quantity }),
  updateQuantity: (id: number, quantity: number) =>
    request.put(`/cart/${id}`, { quantity }),
  removeItem: (id: number) => request.delete(`/cart/${id}`),
}
