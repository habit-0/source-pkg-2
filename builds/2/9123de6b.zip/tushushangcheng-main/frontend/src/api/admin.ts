import request from './request'

export interface DashboardStats {
  total_users: number
  total_books: number
  total_orders: number
  total_revenue: number
  today_orders: number
  today_revenue: number
  pending_orders: number
}

export interface SalesChart {
  date: string
  orders: number
  revenue: number
}

export const adminApi = {
  login: (data: { username: string; password: string }) =>
    request.post<any, any>('/admin/login', data),
  getDashboard: () => request.get<any, DashboardStats>('/admin/dashboard'),
  getSalesChart: () => request.get<any, SalesChart[]>('/admin/stats/sales'),
  listUsers: (params?: any) => request.get<any, any>('/admin/users', { params }),
  updateUserStatus: (id: number, status: number) =>
    request.put(`/admin/users/${id}/status`, { status }),
}

// Stats API used by the Stats.vue admin page
export const adminStatsApi = {
  getOverview: (params?: { period?: string }) =>
    request.get<any, any>('/admin/stats/overview', { params }),
  getSalesTrend: (params?: { period?: string }) =>
    request.get<any, { day: string; amount: number }[]>('/admin/stats/sales-trend', { params }),
  getCategoryStats: () =>
    request.get<any, { name: string; count: number }[]>('/admin/stats/categories'),
}
