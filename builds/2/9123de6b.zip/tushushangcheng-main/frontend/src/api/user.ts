import request from './request'
import type { PageData } from './request'

export interface LoginParams {
  username: string
  password: string
}

export interface RegisterParams {
  username: string
  email: string
  password: string
  nickname?: string
}

export interface UserInfo {
  id: number
  username: string
  email: string
  nickname: string
  avatar: string
  phone: string
  status: number
  created_at: string
}

// Alias used in admin pages
export type User = UserInfo

export interface Address {
  id: number
  user_id: number
  name: string
  phone: string
  province: string
  city: string
  district: string
  address: string
  is_default: number
}

export const authApi = {
  login: (params: LoginParams) => request.post<any, any>('/auth/login', params),
  register: (params: RegisterParams) => request.post<any, any>('/auth/register', params),
}

export const userApi = {
  getProfile: () => request.get<any, UserInfo>('/user/profile'),
  updateProfile: (data: Partial<UserInfo>) => request.put('/user/profile', data),
  changePassword: (data: { old_password: string; new_password: string }) =>
    request.put('/user/password', data),
  getAddresses: () => request.get<any, Address[]>('/user/addresses'),
  createAddress: (data: Omit<Address, 'id' | 'user_id'>) =>
    request.post<any, Address>('/user/addresses', data),
  updateAddress: (id: number, data: Partial<Address>) =>
    request.put(`/user/addresses/${id}`, data),
  deleteAddress: (id: number) => request.delete(`/user/addresses/${id}`),
}

// Admin user API
export const adminUserApi = {
  getList: (params?: any) =>
    request.get<any, PageData<UserInfo>>('/admin/users', { params }),
  updateStatus: (id: number, status: number) =>
    request.put(`/admin/users/${id}/status`, { status }),
}
