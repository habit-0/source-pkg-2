import request from './request'
import type { PageData } from './request'

export interface OrderItemBook {
  id: number
  title: string
  cover: string
  author: string
}

export interface OrderItem {
  id: number
  book_id: number
  book?: OrderItemBook
  title: string
  cover: string
  author: string
  price: number
  quantity: number
  subtotal: number
}

export interface OrderAddress {
  name: string
  phone: string
  province: string
  city: string
  district: string
  detail: string
}

export interface Order {
  id: number
  order_no: string
  user_id: number
  total_price: number
  total_amount: number
  actual_price: number
  status: number
  receiver_name: string
  receiver_phone: string
  receiver_addr: string
  address?: OrderAddress
  remark: string
  items: OrderItem[]
  paid_at: string | null
  shipped_at: string | null
  completed_at: string | null
  created_at: string
}

export const ORDER_STATUS_MAP: Record<number, string> = {
  0: '待支付',
  1: '已支付',
  2: '已发货',
  3: '已完成',
  4: '已取消',
}

export const ORDER_STATUS_TYPE: Record<number, string> = {
  0: 'warning',
  1: 'info',
  2: 'processing',
  3: 'success',
  4: 'default',
}

export const orderApi = {
  createOrder: (data: { address_id: number; cart_ids: number[]; remark?: string }) =>
    request.post<any, Order>('/orders', data),
  getList: (params?: { page?: number; page_size?: number; status?: number }) =>
    request.get<any, PageData<Order>>('/orders', { params }),
  getDetail: (id: number) => request.get<any, Order>(`/orders/${id}`),
  payOrder: (id: number, pay_method: string) =>
    request.post(`/orders/${id}/pay`, { pay_method }),
  cancelOrder: (id: number) => request.post(`/orders/${id}/cancel`),
}

// Admin order API
export const adminOrderApi = {
  getList: (params?: any) =>
    request.get<any, PageData<Order>>('/admin/orders', { params }),
  updateStatus: (id: number, status: number) =>
    request.put(`/admin/orders/${id}/status`, { status }),
  ship: (id: number) =>
    request.put(`/admin/orders/${id}/status`, { status: 3 }),
}
