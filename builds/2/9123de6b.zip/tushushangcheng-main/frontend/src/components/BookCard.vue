<template>
  <div class="book-card" @click="goDetail">
    <!-- Cover -->
    <div class="book-cover">
      <img
        :src="book.cover || fallbackCover"
        :alt="book.title"
        loading="lazy"
        @error="onImgError"
      />
      <!-- Badge -->
      <div v-if="book.is_hot" class="badge">热销</div>
      <div v-else-if="book.is_recommend" class="badge rec">推荐</div>
    </div>

    <!-- Info -->
    <div class="book-info">
      <h3 class="book-title" :title="book.title">{{ book.title }}</h3>
      <p class="book-author">{{ book.author }}</p>

      <div class="book-footer">
        <div class="price-block">
          <span class="price-current">¥{{ book.price.toFixed(2) }}</span>
          <span v-if="book.original_price > book.price" class="price-original">
            ¥{{ book.original_price.toFixed(2) }}
          </span>
        </div>
        <div
          class="cart-btn"
          @click.stop="addToCart"
        >
          <n-icon :component="AddOutline" size="16" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { NIcon, useMessage } from 'naive-ui'
import { AddOutline } from '@vicons/ionicons5'
import { useUserStore } from '@/stores/user'
import { useCartStore } from '@/stores/cart'
import type { Book } from '@/api/book'

const props = defineProps<{ book: Book }>()
const router = useRouter()
const userStore = useUserStore()
const cartStore = useCartStore()
const message = useMessage()
const addingToCart = ref(false)

const fallbackCover = 'https://placehold.co/180x240/F5F3F0/9B9B9B?text=Book'

function goDetail() {
  router.push(`/books/${props.book.id}`)
}

function onImgError(e: Event) {
  ;(e.target as HTMLImageElement).src = fallbackCover
}

async function addToCart() {
  if (!userStore.isLoggedIn) {
    message.warning('请先登录后再加入购物车')
    router.push('/login')
    return
  }
  if (addingToCart.value) return
  addingToCart.value = true
  try {
    await cartStore.addToCart(props.book.id, 1)
    message.success(`《${props.book.title}》已加入购物车`)
  } catch (err: any) {
    message.error(err.message || '添加失败，请重试')
  } finally {
    addingToCart.value = false
  }
}
</script>

<style scoped>
.book-card {
  background: #fff;
  border-radius: 12px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.2s ease;
  border: 1px solid #F0EDE8;
  display: flex;
  flex-direction: column;
}

.book-card:hover {
  border-color: #E0DDD8;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.06);
  transform: translateY(-3px);
}

/* ── Cover ── */
.book-cover {
  position: relative;
  width: 100%;
  padding-top: 136%;
  background: #F5F3F0;
  overflow: hidden;
}

.book-cover img {
  position: absolute;
  top: 0; left: 0;
  width: 100%; height: 100%;
  object-fit: cover;
  transition: transform 0.3s ease;
}

.book-card:hover .book-cover img {
  transform: scale(1.03);
}

/* Badge */
.badge {
  position: absolute;
  top: 10px; left: 10px;
  padding: 3px 10px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 600;
  background: #1A1A1A;
  color: #fff;
  letter-spacing: 0.02em;
}

.badge.rec {
  background: #6B6B6B;
}

/* ── Info ── */
.book-info {
  padding: 14px 14px 16px;
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.book-title {
  font-size: 14px;
  font-weight: 600;
  color: #1A1A1A;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  line-height: 1.4;
  letter-spacing: -0.01em;
}

.book-author {
  font-size: 12px;
  color: #9B9B9B;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.book-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: auto;
  padding-top: 8px;
}

.price-block {
  display: flex;
  align-items: baseline;
  gap: 6px;
}

.price-current {
  font-size: 16px;
  font-weight: 700;
  color: #1A1A1A;
  letter-spacing: -0.02em;
}

.price-original {
  font-size: 11px;
  color: #C0C0C0;
  text-decoration: line-through;
}

.cart-btn {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #F5F3F0;
  color: #4A4A4A;
  transition: all 0.15s ease;
  flex-shrink: 0;
}

.cart-btn:hover {
  background: #1A1A1A;
  color: #fff;
}
</style>
