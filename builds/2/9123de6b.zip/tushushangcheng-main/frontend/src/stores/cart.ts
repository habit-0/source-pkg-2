import { defineStore } from 'pinia'
import { ref } from 'vue'
import { cartApi, type CartSummary } from '@/api/cart'
import { useUserStore } from './user'

export const useCartStore = defineStore('cart', () => {
  const cartData = ref<CartSummary>({ items: [], total_count: 0, total_price: 0 })
  const cartCount = ref(0)
  const loading = ref(false)

  async function fetchCart() {
    const userStore = useUserStore()
    if (!userStore.isLoggedIn) return

    loading.value = true
    try {
      const data = await cartApi.getCart()
      cartData.value = data
      cartCount.value = data.items.length
    } catch {
      // ignore
    } finally {
      loading.value = false
    }
  }

  async function fetchCount() {
    const userStore = useUserStore()
    if (!userStore.isLoggedIn) return
    try {
      const data = await cartApi.getCount()
      cartCount.value = data.count
    } catch {
      // ignore
    }
  }

  async function addToCart(bookId: number, quantity = 1) {
    await cartApi.addToCart(bookId, quantity)
    await fetchCount()
  }

  async function updateQuantity(id: number, quantity: number) {
    await cartApi.updateQuantity(id, quantity)
    await fetchCart()
  }

  async function removeItem(id: number) {
    await cartApi.removeItem(id)
    await fetchCart()
  }

  function clear() {
    cartData.value = { items: [], total_count: 0, total_price: 0 }
    cartCount.value = 0
  }

  return {
    cartData,
    cartCount,
    loading,
    fetchCart,
    fetchCount,
    addToCart,
    updateQuantity,
    removeItem,
    clear,
  }
})
