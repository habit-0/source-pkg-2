import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { UserInfo } from '@/api/user'

export const useUserStore = defineStore(
  'user',
  () => {
    const token = ref<string>('')
    const userInfo = ref<UserInfo | null>(null)
    const isAdmin = ref(false)

    const isLoggedIn = computed(() => !!token.value)
    const nickname = computed(() => userInfo.value?.nickname || userInfo.value?.username || '用户')

    function setToken(t: string) {
      token.value = t
    }

    function setUserInfo(info: UserInfo) {
      userInfo.value = info
    }

    function setAdmin(info: any) {
      isAdmin.value = true
      token.value = info.token
      userInfo.value = info.user_info
    }

    function login(data: { token: string; user_info: UserInfo }) {
      token.value = data.token
      userInfo.value = data.user_info
      isAdmin.value = false
    }

    function logout() {
      token.value = ''
      userInfo.value = null
      isAdmin.value = false
    }

    return {
      token,
      userInfo,
      isAdmin,
      isLoggedIn,
      nickname,
      setToken,
      setUserInfo,
      setAdmin,
      login,
      logout,
    }
  },
  {
    persist: {
      storage: localStorage,
      paths: ['token', 'userInfo', 'isAdmin'],
    },
  },
)
