<template>
  <div class="admin-users">
    <div class="page-header">
      <h2 class="page-title">用户管理</h2>
    </div>

    <!-- Filters -->
    <n-card class="filter-card">
      <n-grid :cols="4" :x-gap="12">
        <n-grid-item>
          <n-input v-model:value="filters.keyword" placeholder="用户名 / 手机号" clearable @keyup.enter="fetchData" />
        </n-grid-item>
        <n-grid-item>
          <n-select v-model:value="filters.status" :options="statusOptions" placeholder="账号状态" clearable />
        </n-grid-item>
        <n-grid-item :span="2">
          <n-button type="primary" @click="fetchData">搜索</n-button>
          <n-button style="margin-left:8px" @click="resetFilters">重置</n-button>
        </n-grid-item>
      </n-grid>
    </n-card>

    <!-- Table -->
    <n-card>
      <n-data-table
        :columns="columns"
        :data="users"
        :loading="loading"
        :pagination="pagination"
        remote
        @update:page="handlePageChange"
      />
    </n-card>

    <!-- Detail Drawer -->
    <n-drawer v-model:show="showDetail" :width="420" placement="right">
      <n-drawer-content :title="`用户详情 - ${currentUser?.username}`" closable>
        <template v-if="currentUser">
          <div class="user-avatar-wrap">
            <n-avatar :size="72" round :src="currentUser.avatar || undefined" :fallback-src="defaultAvatar">
              <template v-if="!currentUser.avatar">
                <n-icon :size="36"><PersonOutline /></n-icon>
              </template>
            </n-avatar>
            <div class="user-name-box">
              <div class="user-name">{{ currentUser.username }}</div>
              <n-tag :type="currentUser.status === 1 ? 'success' : 'error'" size="small">
                {{ currentUser.status === 1 ? '正常' : '封禁' }}
              </n-tag>
            </div>
          </div>

          <n-descriptions :column="1" bordered label-placement="left" size="small" class="user-info">
            <n-descriptions-item label="昵称">{{ currentUser.nickname || '-' }}</n-descriptions-item>
            <n-descriptions-item label="手机号">{{ currentUser.phone || '-' }}</n-descriptions-item>
            <n-descriptions-item label="邮箱">{{ currentUser.email || '-' }}</n-descriptions-item>
            <n-descriptions-item label="注册时间">{{ currentUser.created_at }}</n-descriptions-item>
          </n-descriptions>

          <n-space class="user-actions" justify="end">
            <n-button
              :type="currentUser.status === 1 ? 'error' : 'primary'"
              @click="toggleUserStatus(currentUser)"
            >
              {{ currentUser.status === 1 ? '封禁账号' : '解封账号' }}
            </n-button>
          </n-space>
        </template>
      </n-drawer-content>
    </n-drawer>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, h } from 'vue'
import {
  NCard, NGrid, NGridItem, NButton, NIcon, NInput, NSelect,
  NDataTable, NDrawer, NDrawerContent, NDescriptions, NDescriptionsItem,
  NSpace, NTag, NAvatar, useMessage, useDialog,
} from 'naive-ui'
import type { DataTableColumns } from 'naive-ui'
import { EyeOutline, PersonOutline } from '@vicons/ionicons5'
import { adminUserApi, type User } from '@/api/user'

const message = useMessage()
const dialog = useDialog()

const users = ref<User[]>([])
const loading = ref(false)
const total = ref(0)
const page = ref(1)
const pageSize = ref(20)
const filters = ref({ keyword: '', status: null as number | null })
const showDetail = ref(false)
const currentUser = ref<User | null>(null)
const defaultAvatar = 'https://api.dicebear.com/7.x/identicon/svg'

const statusOptions = [
  { label: '正常', value: 1 },
  { label: '封禁', value: 0 },
]

const pagination = computed(() => ({
  page: page.value,
  pageSize: pageSize.value,
  pageCount: Math.ceil(total.value / pageSize.value),
  itemCount: total.value,
}))

const columns: DataTableColumns<User> = [
  { title: 'ID', key: 'id', width: 70 },
  { title: '用户名', key: 'username', width: 130 },
  { title: '昵称', key: 'nickname', width: 130 },
  { title: '手机号', key: 'phone', width: 130 },
  {
    title: '状态',
    key: 'status',
    width: 90,
    render: row => h(NTag, { type: row.status === 1 ? 'success' : 'error', size: 'small' }, {
      default: () => row.status === 1 ? '正常' : '封禁',
    }),
  },
  { title: '注册时间', key: 'created_at', width: 160 },
  {
    title: '操作',
    key: 'actions',
    width: 90,
    fixed: 'right',
    render: row => h(NButton, {
      size: 'small',
      onClick: () => { currentUser.value = row; showDetail.value = true },
    }, {
      icon: () => h(NIcon, null, { default: () => h(EyeOutline) }),
      default: () => '详情',
    }),
  },
]

async function fetchData() {
  loading.value = true
  try {
    const params: any = { page: page.value, page_size: pageSize.value }
    if (filters.value.keyword) params.keyword = filters.value.keyword
    if (filters.value.status !== null) params.status = filters.value.status
    const result = await adminUserApi.getList(params)
    users.value = result.list || []
    total.value = result.total
  } catch {
    users.value = []
  } finally {
    loading.value = false
  }
}

function resetFilters() {
  filters.value = { keyword: '', status: null }
  fetchData()
}

function handlePageChange(p: number) {
  page.value = p
  fetchData()
}

async function toggleUserStatus(user: User) {
  const newStatus = user.status === 1 ? 0 : 1
  const action = newStatus === 0 ? '封禁' : '解封'
  dialog.warning({
    title: `${action}账号`,
    content: `确定要${action}用户 "${user.username}" 吗？`,
    positiveText: '确定',
    negativeText: '取消',
    onPositiveClick: async () => {
      await adminUserApi.updateStatus(user.id, newStatus)
      message.success(`${action}成功`)
      user.status = newStatus
      if (currentUser.value?.id === user.id) currentUser.value = { ...user }
      fetchData()
    },
  })
}

onMounted(fetchData)
</script>

<style scoped>
.admin-users { padding-bottom: 24px; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.page-title { font-size: 22px; font-weight: 700; color: #1A1A1A; }
.filter-card { margin-bottom: 16px; }
.user-avatar-wrap {
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 24px;
  padding: 16px;
  background: #FAFAF8;
  border-radius: 12px;
}
.user-name-box { display: flex; flex-direction: column; gap: 8px; }
.user-name { font-size: 18px; font-weight: 700; color: #1A1A1A; }
.user-info { margin-bottom: 24px; }
.user-actions { margin-top: 16px; }
</style>
