<template>
  <div class="admin-categories">
    <div class="page-header">
      <h2 class="page-title">分类管理</h2>
      <n-button type="primary" @click="openCreate">
        <template #icon><n-icon :component="AddOutline" /></template>
        添加分类
      </n-button>
    </div>

    <n-card>
      <n-data-table
        :columns="columns"
        :data="categories"
        :loading="loading"
        :pagination="{ pageSize: 20 }"
      />
    </n-card>

    <!-- Create/Edit Modal -->
    <n-modal
      v-model:show="showModal"
      :title="editing ? '编辑分类' : '添加分类'"
      preset="card"
      style="width:420px"
    >
      <n-form ref="formRef" :model="form" :rules="rules" label-placement="left" :label-width="80">
        <n-form-item label="分类名称" path="name">
          <n-input v-model:value="form.name" placeholder="分类名称" />
        </n-form-item>
        <n-form-item label="图标">
          <n-input v-model:value="form.icon" placeholder="图标 (可选)" />
        </n-form-item>
        <n-form-item label="排序">
          <n-input-number v-model:value="form.sort_order" :min="0" style="width:100%" />
        </n-form-item>
        <n-form-item label="描述">
          <n-input v-model:value="form.description" type="textarea" :rows="3" placeholder="分类描述" />
        </n-form-item>
      </n-form>
      <template #action>
        <n-space justify="end">
          <n-button @click="showModal = false">取消</n-button>
          <n-button type="primary" :loading="saving" @click="save">保存</n-button>
        </n-space>
      </template>
    </n-modal>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, h } from 'vue'
import {
  NCard, NButton, NIcon, NDataTable, NModal, NForm, NFormItem,
  NInput, NInputNumber, NSpace, useMessage, useDialog,
} from 'naive-ui'
import type { DataTableColumns, FormInst, FormRules } from 'naive-ui'
import { AddOutline, CreateOutline, TrashOutline } from '@vicons/ionicons5'
import { adminBookApi, type Category } from '@/api/book'

const message = useMessage()
const dialog = useDialog()

const categories = ref<Category[]>([])
const loading = ref(false)
const showModal = ref(false)
const editing = ref<Category | null>(null)
const formRef = ref<FormInst | null>(null)
const saving = ref(false)

const form = ref({ name: '', icon: '', sort_order: 0, description: '' })

const rules: FormRules = {
  name: [{ required: true, message: '请输入分类名称' }],
}

const columns: DataTableColumns<Category> = [
  { title: 'ID', key: 'id', width: 70 },
  { title: '分类名称', key: 'name' },
  { title: '图标', key: 'icon', render: row => row.icon || '-' },
  { title: '排序', key: 'sort_order', width: 90 },
  {
    title: '操作',
    key: 'actions',
    width: 130,
    render: row => h(NSpace, { size: 'small' }, {
      default: () => [
        h(NButton, { size: 'small', onClick: () => openEdit(row) }, {
          icon: () => h(NIcon, null, { default: () => h(CreateOutline) }),
          default: () => '编辑',
        }),
        h(NButton, { size: 'small', type: 'error', onClick: () => del(row.id) }, {
          icon: () => h(NIcon, null, { default: () => h(TrashOutline) }),
          default: () => '删除',
        }),
      ],
    }),
  },
]

async function fetchData() {
  loading.value = true
  try {
    categories.value = await adminBookApi.getCategories()
  } catch {
    categories.value = []
  } finally {
    loading.value = false
  }
}

function openCreate() {
  editing.value = null
  form.value = { name: '', icon: '', sort_order: 0, description: '' }
  showModal.value = true
}

function openEdit(cat: Category) {
  editing.value = cat
  form.value = { name: cat.name, icon: cat.icon, sort_order: cat.sort_order, description: cat.description }
  showModal.value = true
}

async function save() {
  await formRef.value?.validate()
  saving.value = true
  try {
    if (editing.value) {
      await adminBookApi.updateCategory(editing.value.id, form.value)
    } else {
      await adminBookApi.createCategory(form.value)
    }
    showModal.value = false
    message.success('保存成功')
    fetchData()
  } catch (err: any) {
    message.error(err.message)
  } finally {
    saving.value = false
  }
}

function del(id: number) {
  dialog.warning({
    title: '确认删除',
    content: '删除分类后，该分类下图书需重新分类，确定删除？',
    positiveText: '删除',
    negativeText: '取消',
    onPositiveClick: async () => {
      await adminBookApi.deleteCategory(id)
      message.success('删除成功')
      fetchData()
    },
  })
}

onMounted(fetchData)
</script>

<style scoped>
.admin-categories { padding-bottom: 24px; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.page-title { font-size: 22px; font-weight: 700; color: #1A1A1A; }
</style>
