<template>
  <div class="admin-login-page">
    <div class="login-container">
      <!-- Left: Visual Brand Panel -->
      <div class="login-left">
        <div class="left-content">
          <div class="left-top">
            <div class="brand-icon">
              <n-icon :component="BookOutline" size="28" />
            </div>
            <h1 class="brand-name">图书商城</h1>
            <p class="brand-role">管理控制台</p>
          </div>

          <div class="left-middle">
            <div class="feature-grid">
              <div class="feature-card">
                <n-icon :component="BarChartOutline" size="22" class="feature-icon" />
                <span class="feature-label">数据分析</span>
              </div>
              <div class="feature-card">
                <n-icon :component="ReceiptOutline" size="22" class="feature-icon" />
                <span class="feature-label">订单管理</span>
              </div>
              <div class="feature-card">
                <n-icon :component="LibraryOutline" size="22" class="feature-icon" />
                <span class="feature-label">图书运营</span>
              </div>
              <div class="feature-card">
                <n-icon :component="PeopleOutline" size="22" class="feature-icon" />
                <span class="feature-label">用户管理</span>
              </div>
            </div>
          </div>

          <p class="left-footer">图书商城 · 管理系统 v1.0</p>
        </div>
      </div>

      <!-- Right: Form -->
      <div class="login-right">
        <div class="form-wrapper">
          <div class="form-header">
            <h2 class="form-title">管理员登录</h2>
            <p class="form-desc">请使用管理员账号登录后台</p>
          </div>

          <n-form ref="formRef" :model="form" :rules="rules" size="large">
            <n-form-item path="username" :show-label="false">
              <n-input
                v-model:value="form.username"
                placeholder="管理员账号"
                :input-props="{ autocomplete: 'username' }"
              >
                <template #prefix>
                  <n-icon :component="PersonOutline" color="#999" />
                </template>
              </n-input>
            </n-form-item>

            <n-form-item path="password" :show-label="false">
              <n-input
                v-model:value="form.password"
                type="password"
                placeholder="密码"
                show-password-on="click"
                :input-props="{ autocomplete: 'current-password' }"
                @keyup.enter="handleLogin"
              >
                <template #prefix>
                  <n-icon :component="LockClosedOutline" color="#999" />
                </template>
              </n-input>
            </n-form-item>

            <n-button
              block
              type="primary"
              size="large"
              :loading="loading"
              @click="handleLogin"
              class="login-btn"
            >
              登录
            </n-button>
          </n-form>

          <div class="form-footer">
            <span class="back-link" @click="router.push('/')">
              <n-icon :component="ArrowBackOutline" size="14" />
              返回前台首页
            </span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { NForm, NFormItem, NInput, NButton, NIcon, useMessage } from 'naive-ui'
import type { FormInst, FormRules } from 'naive-ui'
import {
  PersonOutline, LockClosedOutline, ArrowBackOutline,
  BookOutline, BarChartOutline, ReceiptOutline, LibraryOutline, PeopleOutline
} from '@vicons/ionicons5'
import { adminApi } from '@/api/admin'
import { useUserStore } from '@/stores/user'

const router = useRouter()
const userStore = useUserStore()
const message = useMessage()

const formRef = ref<FormInst | null>(null)
const loading = ref(false)
const form = ref({ username: 'admin', password: 'admin123' })

const rules: FormRules = {
  username: [{ required: true, message: '请输入管理员账号' }],
  password: [{ required: true, message: '请输入密码' }],
}

async function handleLogin() {
  await formRef.value?.validate()
  loading.value = true
  try {
    const data = await adminApi.login(form.value)
    userStore.setAdmin(data)
    message.success('登录成功')
    router.push('/admin/dashboard')
  } catch (err: any) {
    message.error(err.message || '登录失败')
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.admin-login-page {
  min-height: 100vh;
  background: #F5F5F0;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
}

.login-container {
  display: flex;
  width: 920px;
  max-width: 100%;
  min-height: 560px;
  background: #fff;
  border-radius: 20px;
  overflow: hidden;
  box-shadow:
    0 1px 3px rgba(0, 0, 0, 0.04),
    0 8px 40px rgba(0, 0, 0, 0.06);
}

/* ─── Left Panel ─── */
.login-left {
  flex: 1;
  background: linear-gradient(145deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 48px 40px;
  position: relative;
  overflow: hidden;
}

.login-left::before {
  content: '';
  position: absolute;
  top: -50%;
  right: -30%;
  width: 300px;
  height: 300px;
  background: radial-gradient(circle, rgba(255, 255, 255, 0.04) 0%, transparent 70%);
  border-radius: 50%;
}

.login-left::after {
  content: '';
  position: absolute;
  bottom: -30%;
  left: -20%;
  width: 250px;
  height: 250px;
  background: radial-gradient(circle, rgba(255, 255, 255, 0.03) 0%, transparent 70%);
  border-radius: 50%;
}

.left-content {
  position: relative;
  z-index: 1;
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  height: 100%;
  justify-content: space-between;
}

.left-top {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.brand-icon {
  width: 56px;
  height: 56px;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  margin-bottom: 20px;
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.08);
}

.brand-name {
  font-size: 24px;
  font-weight: 700;
  color: #fff;
  margin-bottom: 6px;
  letter-spacing: 0.02em;
}

.brand-role {
  font-size: 13px;
  color: rgba(255, 255, 255, 0.45);
  font-weight: 400;
  letter-spacing: 0.15em;
  text-transform: uppercase;
}

/* Feature Grid */
.left-middle {
  width: 100%;
  padding: 0 8px;
}

.feature-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
}

.feature-card {
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.06);
  border-radius: 12px;
  padding: 16px 12px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  backdrop-filter: blur(10px);
  transition: all 0.2s ease;
}

.feature-card:hover {
  background: rgba(255, 255, 255, 0.1);
  border-color: rgba(255, 255, 255, 0.12);
}

.feature-icon {
  color: rgba(255, 255, 255, 0.7);
}

.feature-label {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.6);
  font-weight: 500;
}

.left-footer {
  font-size: 11px;
  color: rgba(255, 255, 255, 0.2);
  letter-spacing: 0.05em;
}

/* ─── Right Panel ─── */
.login-right {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 48px;
  background: #fff;
}

.form-wrapper {
  width: 100%;
  max-width: 340px;
}

.form-header {
  margin-bottom: 40px;
}

.form-title {
  font-size: 26px;
  font-weight: 700;
  color: #1a1a2e;
  margin-bottom: 8px;
  letter-spacing: -0.02em;
}

.form-desc {
  font-size: 14px;
  color: #999;
  line-height: 1.5;
}

.login-btn {
  margin-top: 8px;
  height: 44px;
  font-size: 15px;
  font-weight: 600;
  border-radius: 10px;
}

.form-footer {
  text-align: center;
  margin-top: 28px;
  padding-top: 20px;
  border-top: 1px solid #F0F0EB;
}

.back-link {
  font-size: 13px;
  color: #999;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  transition: color 0.2s ease;
}

.back-link:hover {
  color: #1a1a2e;
}

/* ─── Responsive ─── */
@media (max-width: 640px) {
  .login-left { display: none; }
  .login-right { padding: 32px 24px; }
  .login-container { border-radius: 16px; }
}
</style>
