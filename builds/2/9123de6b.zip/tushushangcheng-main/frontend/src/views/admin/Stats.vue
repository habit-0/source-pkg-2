<template>
  <div class="admin-stats">
    <div class="page-header">
      <h2 class="page-title">数据统计</h2>
      <n-select v-model:value="period" :options="periodOptions" style="width:120px" @update:value="fetchStats" />
    </div>

    <!-- KPI Cards -->
    <n-grid :cols="4" :x-gap="16" :y-gap="16" class="kpi-grid">
      <n-grid-item v-for="kpi in kpiCards" :key="kpi.key">
        <n-card class="kpi-card">
          <div class="kpi-icon" :style="{ background: kpi.bg }">
            <n-icon :size="22" :color="kpi.color"><component :is="kpi.icon" /></n-icon>
          </div>
          <div class="kpi-info">
            <div class="kpi-label">{{ kpi.label }}</div>
            <div class="kpi-value">{{ kpi.prefix }}{{ formatNum(stats[kpi.key]) }}</div>
            <div class="kpi-trend" :class="kpi.trend > 0 ? 'up' : 'down'">
              <n-icon :size="12"><component :is="kpi.trend >= 0 ? ArrowUpOutline : ArrowDownOutline" /></n-icon>
              {{ Math.abs(kpi.trend) }}%
            </div>
          </div>
        </n-card>
      </n-grid-item>
    </n-grid>

    <!-- Charts Row -->
    <n-grid :cols="2" :x-gap="16" :y-gap="16" class="chart-row">
      <!-- Sales Trend -->
      <n-grid-item>
        <n-card title="销售趋势">
          <div class="chart-area">
            <div v-if="salesLoading" class="chart-loading">
              <n-spin size="large" />
            </div>
            <div v-else class="bar-chart">
              <div
                v-for="(item, i) in salesTrend"
                :key="i"
                class="bar-item"
              >
                <div class="bar-fill" :style="{ height: barHeight(item.amount, maxSales) + '%' }">
                  <n-tooltip>
                    <template #trigger><div class="bar-inner" /></template>
                    ¥{{ item.amount.toFixed(0) }}
                  </n-tooltip>
                </div>
                <div class="bar-label">{{ item.day }}</div>
              </div>
            </div>
          </div>
        </n-card>
      </n-grid-item>

      <!-- Category Distribution -->
      <n-grid-item>
        <n-card title="分类销量分布">
          <div class="chart-area">
            <div v-if="cateLoading" class="chart-loading"><n-spin size="large" /></div>
            <div v-else class="pie-list">
              <div v-for="(item, i) in categoryStats" :key="i" class="pie-row">
                <span class="pie-color-dot" :style="{ background: pieColors[i % pieColors.length] }" />
                <span class="pie-name">{{ item.name }}</span>
                <n-progress
                  type="line"
                  :percentage="Math.round(item.count / totalBooks * 100)"
                  :color="pieColors[i % pieColors.length]"
                  :rail-color="'#f0f0f0'"
                  style="flex:1;margin: 0 12px"
                  :indicator-placement="'inside'"
                  :height="18"
                />
                <span class="pie-count">{{ item.count }}</span>
              </div>
            </div>
          </div>
        </n-card>
      </n-grid-item>
    </n-grid>

    <!-- Recent Orders & Top Books -->
    <n-grid :cols="2" :x-gap="16" :y-gap="16" class="bottom-row">
      <n-grid-item>
        <n-card title="最近订单">
          <n-list>
            <n-list-item v-for="order in recentOrders" :key="order.id">
              <div class="order-row">
                <div class="order-no">{{ order.order_no }}</div>
                <n-tag :type="orderStatusType(order.status)" size="small">{{ orderStatusLabel(order.status) }}</n-tag>
                <div class="order-amount">¥{{ order.total_amount?.toFixed(2) }}</div>
              </div>
            </n-list-item>
          </n-list>
        </n-card>
      </n-grid-item>

      <n-grid-item>
        <n-card title="热销榜单 TOP10">
          <div v-for="(book, i) in topBooks" :key="book.id" class="top-book-row">
            <div class="rank" :class="i < 3 ? 'top-rank' : ''">{{ i + 1 }}</div>
            <n-image :src="book.cover" width="36" height="46" object-fit="cover" style="border-radius:3px;flex-shrink:0" />
            <div class="book-title-col">
              <div class="book-t">{{ book.title }}</div>
              <div class="book-a">{{ book.author }}</div>
            </div>
            <div class="sales-count">{{ book.sales }} 件</div>
          </div>
        </n-card>
      </n-grid-item>
    </n-grid>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import {
  NCard, NGrid, NGridItem, NIcon, NSelect, NSpin, NProgress,
  NList, NListItem, NTag, NTooltip,
} from 'naive-ui'
import {
  CartOutline, PeopleOutline, BookOutline, CashOutline,
  ArrowUpOutline, ArrowDownOutline,
} from '@vicons/ionicons5'
import { adminStatsApi } from '@/api/admin'

const period = ref('7d')
const periodOptions = [
  { label: '近7天', value: '7d' },
  { label: '近30天', value: '30d' },
  { label: '近90天', value: '90d' },
]

const stats = ref({ revenue: 0, orders: 0, users: 0, books: 0 })
const salesTrend = ref<{ day: string; amount: number }[]>([])
const categoryStats = ref<{ name: string; count: number }[]>([])
const recentOrders = ref<any[]>([])
const topBooks = ref<any[]>([])
const salesLoading = ref(false)
const cateLoading = ref(false)

const pieColors = ['#1A1A1A', '#f59e0b', '#10b981', '#ef4444', '#3b82f6', '#ec4899', '#14b8a6', '#f97316']

const maxSales = computed(() => Math.max(...salesTrend.value.map(i => i.amount), 1))
const totalBooks = computed(() => categoryStats.value.reduce((s, i) => s + i.count, 0) || 1)

const kpiCards = [
  { key: 'revenue', label: '总收入', prefix: '¥', icon: CashOutline, bg: '#fef3c7', color: '#d97706', trend: 12 },
  { key: 'orders', label: '总订单', prefix: '', icon: CartOutline, bg: '#ede9fe', color: '#7c3aed', trend: 8 },
  { key: 'users', label: '注册用户', prefix: '', icon: PeopleOutline, bg: '#d1fae5', color: '#059669', trend: 5 },
  { key: 'books', label: '在架图书', prefix: '', icon: BookOutline, bg: '#dbeafe', color: '#2563eb', trend: -3 },
]

function formatNum(val: number) {
  if (!val) return '0'
  if (val >= 10000) return (val / 10000).toFixed(1) + 'w'
  return val.toLocaleString()
}

function barHeight(val: number, max: number) {
  return Math.max(4, (val / max) * 100)
}

const orderStatusType = (s: number) => ({ 1: 'warning', 2: 'info', 3: 'primary', 4: 'success', 5: 'default' }[s] as any || 'default')
const orderStatusLabel = (s: number) => ({ 1: '待付款', 2: '待发货', 3: '已发货', 4: '已完成', 5: '已取消' }[s] || '')

async function fetchStats() {
  try {
    const data = await adminStatsApi.getOverview({ period: period.value })
    stats.value = data.overview || stats.value
    recentOrders.value = data.recent_orders || []
    topBooks.value = data.top_books || []
  } catch {}

  salesLoading.value = true
  try {
    salesTrend.value = await adminStatsApi.getSalesTrend({ period: period.value }) || []
  } catch {
    salesTrend.value = []
  } finally {
    salesLoading.value = false
  }

  cateLoading.value = true
  try {
    categoryStats.value = await adminStatsApi.getCategoryStats() || []
  } catch {
    categoryStats.value = []
  } finally {
    cateLoading.value = false
  }
}

onMounted(fetchStats)
</script>

<style scoped>
.admin-stats { padding-bottom: 24px; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
.page-title { font-size: 22px; font-weight: 700; color: #1A1A1A; }
.kpi-grid { margin-bottom: 16px; }
.kpi-card { display: flex; flex-direction: row; align-items: center; gap: 16px; padding: 20px; }
:deep(.kpi-card .n-card__content) { display: flex; align-items: center; gap: 16px; }
.kpi-icon { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.kpi-info { flex: 1; }
.kpi-label { font-size: 13px; color: #6b7280; margin-bottom: 4px; }
.kpi-value { font-size: 24px; font-weight: 700; color: #1A1A1A; }
.kpi-trend { font-size: 12px; display: flex; align-items: center; gap: 2px; margin-top: 2px; }
.kpi-trend.up { color: #10b981; }
.kpi-trend.down { color: #ef4444; }
.chart-row { margin-bottom: 16px; }
.chart-area { height: 220px; position: relative; overflow: hidden; }
.chart-loading { display: flex; align-items: center; justify-content: center; height: 100%; }
.bar-chart { display: flex; align-items: flex-end; gap: 6px; height: 100%; padding: 12px 0 0; }
.bar-item { flex: 1; display: flex; flex-direction: column; align-items: center; height: 100%; }
.bar-fill { width: 100%; display: flex; flex-direction: column; justify-content: flex-end; transition: height 0.3s; }
.bar-inner { width: 100%; flex: 1; background: linear-gradient(180deg, #1A1A1A, #818cf8); border-radius: 4px 4px 0 0; min-height: 4px; cursor: pointer; }
.bar-inner:hover { background: linear-gradient(180deg, #000000, #1A1A1A); }
.bar-label { font-size: 10px; color: #9ca3af; margin-top: 4px; white-space: nowrap; }
.pie-list { display: flex; flex-direction: column; gap: 12px; padding-top: 8px; }
.pie-row { display: flex; align-items: center; gap: 8px; }
.pie-color-dot { width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }
.pie-name { font-size: 13px; color: #374151; width: 80px; }
.pie-count { font-size: 13px; color: #6b7280; width: 36px; text-align: right; }
.bottom-row {}
.order-row { display: flex; align-items: center; gap: 12px; }
.order-no { flex: 1; font-size: 13px; color: #374151; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.order-amount { font-weight: 600; color: #ef4444; font-size: 14px; }
.top-book-row { display: flex; align-items: center; gap: 10px; padding: 8px 0; border-bottom: 1px solid #f0f0f0; }
.rank { width: 24px; height: 24px; border-radius: 50%; background: #f3f4f6; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; color: #6b7280; flex-shrink: 0; }
.rank.top-rank { background: #fef3c7; color: #d97706; }
.book-title-col { flex: 1; min-width: 0; }
.book-t { font-size: 13px; color: #1A1A1A; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.book-a { font-size: 11px; color: #9ca3af; }
.sales-count { font-size: 13px; color: #1A1A1A; font-weight: 600; white-space: nowrap; }
</style>
