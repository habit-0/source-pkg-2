<template>
  <div class="admin-books">
    <div class="page-header">
      <h2 class="page-title">图书管理</h2>
      <n-button type="primary" @click="openCreateModal">
        <template #icon><n-icon :component="AddOutline" /></template>
        添加图书
      </n-button>
    </div>

    <!-- Filters -->
    <n-card class="filter-card">
      <n-grid :cols="4" :x-gap="12">
        <n-grid-item>
          <n-input v-model:value="filters.keyword" placeholder="搜索书名、作者" clearable @keyup.enter="fetchData" />
        </n-grid-item>
        <n-grid-item>
          <n-select
            v-model:value="filters.category_id"
            :options="categoryOptions"
            placeholder="选择分类"
            clearable
          />
        </n-grid-item>
        <n-grid-item>
          <n-select
            v-model:value="filters.status"
            :options="statusOptions"
            placeholder="上架状态"
            clearable
          />
        </n-grid-item>
        <n-grid-item>
          <n-button type="primary" @click="fetchData">搜索</n-button>
          <n-button style="margin-left:8px" @click="resetFilters">重置</n-button>
        </n-grid-item>
      </n-grid>
    </n-card>

    <!-- Table -->
    <n-card>
      <n-data-table
        :columns="columns"
        :data="books"
        :loading="loading"
        :pagination="pagination"
        remote
        @update:page="handlePageChange"
        :scroll-x="1200"
      />
    </n-card>

    <!-- Create/Edit Modal -->
    <n-modal
      v-model:show="showModal"
      :title="editingBook ? '编辑图书' : '添加图书'"
      preset="card"
      style="width:680px"
    >
      <n-form ref="formRef" :model="bookForm" :rules="formRules" label-placement="left" :label-width="90">
        <n-grid :cols="2" :x-gap="16">
          <n-grid-item :span="2">
            <n-form-item label="书名" path="title">
              <n-input v-model:value="bookForm.title" placeholder="请输入书名" />
            </n-form-item>
          </n-grid-item>
          <n-grid-item>
            <n-form-item label="作者" path="author">
              <n-input v-model:value="bookForm.author" placeholder="作者" />
            </n-form-item>
          </n-grid-item>
          <n-grid-item>
            <n-form-item label="出版社">
              <n-input v-model:value="bookForm.publisher" placeholder="出版社" />
            </n-form-item>
          </n-grid-item>
          <n-grid-item>
            <n-form-item label="分类" path="category_id">
              <n-select v-model:value="bookForm.category_id" :options="categoryOptions" placeholder="选择分类" />
            </n-form-item>
          </n-grid-item>
          <n-grid-item>
            <n-form-item label="ISBN">
              <n-input v-model:value="bookForm.isbn" placeholder="ISBN" />
            </n-form-item>
          </n-grid-item>
          <n-grid-item>
            <n-form-item label="售价" path="price">
              <n-input-number v-model:value="bookForm.price" :precision="2" :min="0" placeholder="售价" style="width:100%" />
            </n-form-item>
          </n-grid-item>
          <n-grid-item>
            <n-form-item label="原价">
              <n-input-number v-model:value="bookForm.original_price" :precision="2" :min="0" placeholder="原价" style="width:100%" />
            </n-form-item>
          </n-grid-item>
          <n-grid-item>
            <n-form-item label="库存">
              <n-input-number v-model:value="bookForm.stock" :min="0" placeholder="库存" style="width:100%" />
            </n-form-item>
          </n-grid-item>
          <n-grid-item :span="2">
            <n-form-item label="封面图">
              <n-input v-model:value="bookForm.cover" placeholder="封面图URL" />
            </n-form-item>
          </n-grid-item>
          <n-grid-item>
            <n-form-item label="推荐">
              <n-switch v-model:value="bookFormRecommend" />
            </n-form-item>
          </n-grid-item>
          <n-grid-item>
            <n-form-item label="热门">
              <n-switch v-model:value="bookFormHot" />
            </n-form-item>
          </n-grid-item>
          <n-grid-item :span="2">
            <n-form-item label="简介">
              <n-input v-model:value="bookForm.description" type="textarea" :rows="4" placeholder="图书简介" />
            </n-form-item>
          </n-grid-item>
        </n-grid>
      </n-form>
      <template #action>
        <n-space justify="end">
          <n-button @click="showModal = false">取消</n-button>
          <n-button type="primary" :loading="saving" @click="saveBook">保存</n-button>
        </n-space>
      </template>
    </n-modal>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, h } from 'vue'
import {
  NCard, NGrid, NGridItem, NButton, NIcon, NInput, NSelect,
  NDataTable, NModal, NForm, NFormItem, NInputNumber, NSwitch,
  NSpace, NTag, NImage, useMessage, useDialog,
} from 'naive-ui'
import type { DataTableColumns, FormInst, FormRules } from 'naive-ui'
import { AddOutline, CreateOutline, TrashOutline } from '@vicons/ionicons5'
import { adminBookApi, type Book } from '@/api/book'

const message = useMessage()
const dialog = useDialog()

const books = ref<Book[]>([])
const loading = ref(false)
const total = ref(0)
const page = ref(1)
const pageSize = ref(20)
const filters = ref({ keyword: '', category_id: null as number | null, status: null as number | null })
const categories = ref<any[]>([])

const categoryOptions = computed(() =>
  categories.value.map(c => ({ label: c.name, value: c.id }))
)
const statusOptions = [
  { label: '上架', value: 1 },
  { label: '下架', value: 0 },
]

const showModal = ref(false)
const editingBook = ref<Book | null>(null)
const formRef = ref<FormInst | null>(null)
const saving = ref(false)
const bookFormRecommend = ref(false)
const bookFormHot = ref(false)

const bookForm = ref({
  title: '', author: '', publisher: '', isbn: '',
  category_id: null as number | null,
  price: 0, original_price: 0, cover: '', description: '',
  stock: 0,
})

const formRules: FormRules = {
  title: [{ required: true, message: '请输入书名' }],
  author: [{ required: true, message: '请输入作者' }],
  category_id: [{ required: true, type: 'number', message: '请选择分类' }],
  price: [{ required: true, type: 'number', message: '请输入价格' }],
}

const pagination = computed(() => ({
  page: page.value,
  pageSize: pageSize.value,
  pageCount: Math.ceil(total.value / pageSize.value),
  itemCount: total.value,
  showSizePicker: true,
  pageSizes: [10, 20, 50],
}))

const columns: DataTableColumns<Book> = [
  {
    title: '封面',
    key: 'cover',
    width: 70,
    render: (row) => h(NImage, { src: row.cover, width: 44, height: 56, objectFit: 'cover', style: 'border-radius:4px' }),
  },
  { title: '书名', key: 'title', ellipsis: { tooltip: true }, width: 200 },
  { title: '作者', key: 'author', width: 120 },
  {
    title: '分类',
    key: 'category',
    width: 100,
    render: (row) => row.category?.name || '-',
  },
  {
    title: '价格',
    key: 'price',
    width: 90,
    render: (row) => h('span', { style: 'color:#ef4444;font-weight:600' }, `¥${row.price.toFixed(2)}`),
  },
  {
    title: '库存',
    key: 'stock',
    width: 80,
    render: (row) => row.inventory?.stock ?? '-',
  },
  { title: '销量', key: 'sales', width: 80 },
  {
    title: '状态',
    key: 'status',
    width: 90,
    render: (row) => h(NTag, { type: row.status === 1 ? 'success' : 'default', size: 'small' }, { default: () => row.status === 1 ? '上架' : '下架' }),
  },
  {
    title: '操作',
    key: 'actions',
    width: 140,
    fixed: 'right',
    render: (row) => h(NSpace, { size: 'small' }, {
      default: () => [
        h(NButton, {
          size: 'small',
          onClick: () => openEditModal(row),
        }, { icon: () => h(NIcon, null, { default: () => h(CreateOutline) }) }),
        h(NButton, {
          size: 'small',
          type: 'error',
          onClick: () => deleteBook(row.id),
        }, { icon: () => h(NIcon, null, { default: () => h(TrashOutline) }) }),
      ],
    }),
  },
]

async function fetchData() {
  loading.value = true
  try {
    const result = await adminBookApi.getList({
      page: page.value,
      page_size: pageSize.value,
      keyword: filters.value.keyword,
      category_id: filters.value.category_id || undefined,
      status: filters.value.status !== null ? filters.value.status : undefined,
    })
    books.value = result.list || []
    total.value = result.total
  } catch {
    books.value = []
  } finally {
    loading.value = false
  }
}

function resetFilters() {
  filters.value = { keyword: '', category_id: null, status: null }
  fetchData()
}

function handlePageChange(p: number) {
  page.value = p
  fetchData()
}

function openCreateModal() {
  editingBook.value = null
  bookForm.value = { title: '', author: '', publisher: '', isbn: '', category_id: null, price: 0, original_price: 0, cover: '', description: '', stock: 0 }
  bookFormRecommend.value = false
  bookFormHot.value = false
  showModal.value = true
}

function openEditModal(book: Book) {
  editingBook.value = book
  bookForm.value = {
    title: book.title,
    author: book.author,
    publisher: book.publisher,
    isbn: book.isbn,
    category_id: book.category_id,
    price: book.price,
    original_price: book.original_price,
    cover: book.cover,
    description: book.description,
    stock: book.inventory?.stock || 0,
  }
  bookFormRecommend.value = book.is_recommend === 1
  bookFormHot.value = book.is_hot === 1
  showModal.value = true
}

async function saveBook() {
  await formRef.value?.validate()
  saving.value = true
  try {
    const data = {
      ...bookForm.value,
      is_recommend: bookFormRecommend.value ? 1 : 0,
      is_hot: bookFormHot.value ? 1 : 0,
    }
    if (editingBook.value) {
      await adminBookApi.update(editingBook.value.id, data)
    } else {
      await adminBookApi.create(data)
    }
    showModal.value = false
    message.success('保存成功')
    fetchData()
  } catch (err: any) {
    message.error(err.message)
  } finally {
    saving.value = false
  }
}

function deleteBook(id: number) {
  dialog.warning({
    title: '确认删除',
    content: '删除后无法恢复，确定吗？',
    positiveText: '删除',
    negativeText: '取消',
    onPositiveClick: async () => {
      await adminBookApi.delete(id)
      message.success('删除成功')
      fetchData()
    },
  })
}

onMounted(async () => {
  try {
    categories.value = await adminBookApi.getCategories()
  } catch {}
  fetchData()
})
</script>

<style scoped>
.admin-books { padding-bottom: 24px; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.page-title { font-size: 22px; font-weight: 700; color: #1A1A1A; }
.filter-card { margin-bottom: 16px; }
</style>
