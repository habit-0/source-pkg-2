<template>
  <div class="dashboard-page">
    <h2 class="page-title">控制台概览</h2>

    <!-- Stats Cards -->
    <n-grid :cols="4" :x-gap="16" :y-gap="16" class="stats-grid">
      <n-grid-item v-for="stat in statCards" :key="stat.key">
        <n-card class="stat-card" :style="{ borderTop: `4px solid ${stat.color}` }">
          <div class="stat-content">
            <div class="stat-info">
              <p class="stat-label">{{ stat.label }}</p>
              <p class="stat-value">
                <span v-if="stat.prefix">{{ stat.prefix }}</span>
                {{ formatValue(stat.value, stat.format) }}
              </p>
            </div>
            <div class="stat-icon" :style="{ background: stat.color + '18' }">
              <n-icon :component="stat.icon" :color="stat.color" size="28" />
            </div>
          </div>
          <div v-if="stat.sub" class="stat-sub">{{ stat.sub }}</div>
        </n-card>
      </n-grid-item>
    </n-grid>

    <!-- Charts -->
    <n-grid :cols="2" :x-gap="16" style="margin-top:20px">
      <n-grid-item>
        <n-card title="近7天销售趋势">
          <v-chart :option="salesChartOption" style="height:280px" autoresize />
        </n-card>
      </n-grid-item>
      <n-grid-item>
        <n-card title="近7天订单量">
          <v-chart :option="orderChartOption" style="height:280px" autoresize />
        </n-card>
      </n-grid-item>
    </n-grid>

    <!-- Quick Actions -->
    <n-card title="快捷操作" style="margin-top:20px">
      <n-space>
        <n-button type="primary" @click="router.push('/admin/books')">
          <template #icon><n-icon :component="BookOutline" /></template>
          管理图书
        </n-button>
        <n-button @click="router.push('/admin/orders')">
          <template #icon><n-icon :component="ReceiptOutline" /></template>
          管理订单
        </n-button>
        <n-button @click="router.push('/admin/users')">
          <template #icon><n-icon :component="PeopleOutline" /></template>
          管理用户
        </n-button>
        <n-button @click="router.push('/admin/categories')">
          <template #icon><n-icon :component="LibraryOutline" /></template>
          管理分类
        </n-button>
      </n-space>
    </n-card>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { NGrid, NGridItem, NCard, NIcon, NSpace, NButton } from 'naive-ui'
import {
  PeopleOutline, BookOutline, ReceiptOutline, CashOutline,
  LibraryOutline, TrendingUpOutline,
} from '@vicons/ionicons5'
import VChart from 'vue-echarts'
import { use } from 'echarts/core'
import { CanvasRenderer } from 'echarts/renderers'
import { LineChart, BarChart } from 'echarts/charts'
import {
  TitleComponent, TooltipComponent, GridComponent,
  LegendComponent,
} from 'echarts/components'
import { adminApi, type DashboardStats, type SalesChart } from '@/api/admin'

use([CanvasRenderer, LineChart, BarChart, TitleComponent, TooltipComponent, GridComponent, LegendComponent])

const router = useRouter()
const stats = ref<DashboardStats>({
  total_users: 0, total_books: 0, total_orders: 0, total_revenue: 0,
  today_orders: 0, today_revenue: 0, pending_orders: 0,
})
const chartData = ref<SalesChart[]>([])

const statCards = computed(() => [
  {
    key: 'users',
    label: '总用户数',
    value: stats.value.total_users,
    icon: PeopleOutline,
    color: '#1A1A1A',
    format: 'number',
    sub: '',
  },
  {
    key: 'books',
    label: '图书总量',
    value: stats.value.total_books,
    icon: BookOutline,
    color: '#404040',
    format: 'number',
    sub: '',
  },
  {
    key: 'orders',
    label: '总订单数',
    value: stats.value.total_orders,
    icon: ReceiptOutline,
    color: '#06b6d4',
    format: 'number',
    sub: `今日 +${stats.value.today_orders}`,
  },
  {
    key: 'revenue',
    label: '总收入',
    value: stats.value.total_revenue,
    icon: CashOutline,
    color: '#22c55e',
    prefix: '¥',
    format: 'currency',
    sub: `今日 ¥${stats.value.today_revenue.toFixed(2)}`,
  },
])

function formatValue(val: number, format: string) {
  if (format === 'currency') return val.toFixed(2)
  return val.toLocaleString()
}

const salesChartOption = computed(() => ({
  tooltip: { trigger: 'axis' },
  grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
  xAxis: {
    type: 'category',
    data: chartData.value.map(d => d.date),
    axisLabel: { fontSize: 11 },
  },
  yAxis: { type: 'value', axisLabel: { formatter: '¥{value}' } },
  series: [{
    name: '销售额',
    type: 'line',
    data: chartData.value.map(d => d.revenue),
    smooth: true,
    areaStyle: { opacity: 0.15 },
    lineStyle: { color: '#1A1A1A', width: 3 },
    itemStyle: { color: '#1A1A1A' },
  }],
}))

const orderChartOption = computed(() => ({
  tooltip: { trigger: 'axis' },
  grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
  xAxis: {
    type: 'category',
    data: chartData.value.map(d => d.date),
    axisLabel: { fontSize: 11 },
  },
  yAxis: { type: 'value' },
  series: [{
    name: '订单数',
    type: 'bar',
    data: chartData.value.map(d => d.orders),
    barMaxWidth: 48,
    itemStyle: {
      color: '#404040',
      borderRadius: [4, 4, 0, 0],
    },
  }],
}))

onMounted(async () => {
  try {
    stats.value = await adminApi.getDashboard()
  } catch {}
  try {
    chartData.value = await adminApi.getSalesChart()
  } catch {}
})
</script>

<style scoped>
.dashboard-page { padding-bottom: 24px; }
.page-title { font-size: 22px; font-weight: 700; color: #1A1A1A; margin-bottom: 20px; }

.stat-card {
  transition: transform 0.2s, box-shadow 0.2s;
}
.stat-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 24px rgba(0,0,0,0.12);
}

.stat-content {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.stat-label {
  font-size: 13px;
  color: #6B6B6B;
  margin-bottom: 6px;
}

.stat-value {
  font-size: 28px;
  font-weight: 700;
  color: #1A1A1A;
}

.stat-icon {
  width: 56px;
  height: 56px;
  border-radius: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.stat-sub {
  font-size: 12px;
  color: #9B9B9B;
  margin-top: 10px;
  padding-top: 10px;
  border-top: 1px solid #f1f5f9;
}
</style>
