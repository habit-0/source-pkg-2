<template>
  <div class="admin-orders">
    <div class="page-header">
      <h2 class="page-title">订单管理</h2>
    </div>

    <!-- Filters -->
    <n-card class="filter-card">
      <n-grid :cols="4" :x-gap="12">
        <n-grid-item>
          <n-input v-model:value="filters.order_no" placeholder="订单号" clearable />
        </n-grid-item>
        <n-grid-item>
          <n-select v-model:value="filters.status" :options="statusOptions" placeholder="订单状态" clearable />
        </n-grid-item>
        <n-grid-item>
          <n-date-picker
            v-model:value="dateRange"
            type="daterange"
            clearable
            style="width:100%"
            placeholder="下单时间范围"
          />
        </n-grid-item>
        <n-grid-item>
          <n-button type="primary" @click="fetchData">搜索</n-button>
          <n-button style="margin-left:8px" @click="resetFilters">重置</n-button>
        </n-grid-item>
      </n-grid>
    </n-card>

    <!-- Table -->
    <n-card>
      <n-data-table
        :columns="columns"
        :data="orders"
        :loading="loading"
        :pagination="pagination"
        remote
        @update:page="handlePageChange"
        :scroll-x="1000"
      />
    </n-card>

    <!-- Order Detail Drawer -->
    <n-drawer v-model:show="showDetail" :width="500" placement="right">
      <n-drawer-content :title="`订单详情 - ${currentOrder?.order_no}`" closable>
        <template v-if="currentOrder">
          <n-descriptions :column="2" bordered label-placement="left" size="small" class="order-info">
            <n-descriptions-item label="订单号">{{ currentOrder.order_no }}</n-descriptions-item>
            <n-descriptions-item label="状态">
              <n-tag :type="statusType(currentOrder.status)" size="small">{{ statusLabel(currentOrder.status) }}</n-tag>
            </n-descriptions-item>
            <n-descriptions-item label="下单时间">{{ currentOrder.created_at }}</n-descriptions-item>
            <n-descriptions-item label="总金额">
              <span style="color:#ef4444;font-weight:600">¥{{ currentOrder.total_amount?.toFixed(2) }}</span>
            </n-descriptions-item>
            <n-descriptions-item label="收货人" :span="2">
              {{ currentOrder.address?.name }} {{ currentOrder.address?.phone }}
            </n-descriptions-item>
            <n-descriptions-item label="收货地址" :span="2">
              {{ currentOrder.address?.province }}{{ currentOrder.address?.city }}{{ currentOrder.address?.district }}{{ currentOrder.address?.detail }}
            </n-descriptions-item>
          </n-descriptions>

          <div class="order-items-title">订单商品</div>
          <div v-for="item in currentOrder.items" :key="item.id" class="order-item">
            <n-image :src="item.book?.cover" width="50" height="64" object-fit="cover" style="border-radius:4px;flex-shrink:0" />
            <div class="item-info">
              <div class="item-title">{{ item.book?.title }}</div>
              <div class="item-meta">¥{{ item.price?.toFixed(2) }} × {{ item.quantity }}</div>
            </div>
            <div class="item-total">¥{{ (item.price * item.quantity).toFixed(2) }}</div>
          </div>

          <n-divider />
          <div class="order-summary">
            <span>合计：</span>
            <span class="total-amount">¥{{ currentOrder.total_amount?.toFixed(2) }}</span>
          </div>

          <n-space class="order-actions" justify="end">
            <n-button
              v-if="currentOrder.status === 2"
              type="primary"
              @click="confirmShip(currentOrder)"
            >
              确认发货
            </n-button>
          </n-space>
        </template>
      </n-drawer-content>
    </n-drawer>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, h } from 'vue'
import {
  NCard, NGrid, NGridItem, NButton, NIcon, NInput, NSelect,
  NDataTable, NDrawer, NDrawerContent, NDescriptions, NDescriptionsItem,
  NSpace, NTag, NImage, NDivider, NDatePicker, useMessage, useDialog,
} from 'naive-ui'
import type { DataTableColumns } from 'naive-ui'
import { EyeOutline } from '@vicons/ionicons5'
import { adminOrderApi, type Order } from '@/api/order'

const message = useMessage()
const dialog = useDialog()

const orders = ref<Order[]>([])
const loading = ref(false)
const total = ref(0)
const page = ref(1)
const pageSize = ref(20)
const filters = ref({ order_no: '', status: null as number | null })
const dateRange = ref<[number, number] | null>(null)
const showDetail = ref(false)
const currentOrder = ref<Order | null>(null)

const statusOptions = [
  { label: '待付款', value: 1 },
  { label: '待发货', value: 2 },
  { label: '已发货', value: 3 },
  { label: '已完成', value: 4 },
  { label: '已取消', value: 5 },
]

const statusType = (status: number) => {
  const map: Record<number, string> = { 1: 'warning', 2: 'info', 3: 'primary', 4: 'success', 5: 'default' }
  return (map[status] || 'default') as any
}
const statusLabel = (status: number) => {
  const map: Record<number, string> = { 1: '待付款', 2: '待发货', 3: '已发货', 4: '已完成', 5: '已取消' }
  return map[status] || '未知'
}

const pagination = computed(() => ({
  page: page.value,
  pageSize: pageSize.value,
  pageCount: Math.ceil(total.value / pageSize.value),
  itemCount: total.value,
}))

const columns: DataTableColumns<Order> = [
  { title: '订单号', key: 'order_no', width: 180 },
  {
    title: '金额',
    key: 'total_amount',
    width: 100,
    render: row => h('span', { style: 'color:#ef4444;font-weight:600' }, `¥${row.total_amount?.toFixed(2)}`),
  },
  {
    title: '状态',
    key: 'status',
    width: 90,
    render: row => h(NTag, { type: statusType(row.status), size: 'small' }, { default: () => statusLabel(row.status) }),
  },
  { title: '下单时间', key: 'created_at', width: 160 },
  {
    title: '操作',
    key: 'actions',
    width: 100,
    fixed: 'right',
    render: row => h(NButton, {
      size: 'small',
      onClick: () => viewDetail(row),
    }, {
      icon: () => h(NIcon, null, { default: () => h(EyeOutline) }),
      default: () => '详情',
    }),
  },
]

async function fetchData() {
  loading.value = true
  try {
    const params: any = {
      page: page.value,
      page_size: pageSize.value,
    }
    if (filters.value.order_no) params.order_no = filters.value.order_no
    if (filters.value.status !== null) params.status = filters.value.status
    if (dateRange.value) {
      params.start_time = new Date(dateRange.value[0]).toISOString()
      params.end_time = new Date(dateRange.value[1]).toISOString()
    }
    const result = await adminOrderApi.getList(params)
    orders.value = result.list || []
    total.value = result.total
  } catch {
    orders.value = []
  } finally {
    loading.value = false
  }
}

function resetFilters() {
  filters.value = { order_no: '', status: null }
  dateRange.value = null
  fetchData()
}

function handlePageChange(p: number) {
  page.value = p
  fetchData()
}

function viewDetail(order: Order) {
  currentOrder.value = order
  showDetail.value = true
}

async function confirmShip(order: Order) {
  dialog.warning({
    title: '确认发货',
    content: `确认订单 ${order.order_no} 已发货？`,
    positiveText: '确认',
    negativeText: '取消',
    onPositiveClick: async () => {
      await adminOrderApi.ship(order.id)
      message.success('已标记发货')
      fetchData()
      showDetail.value = false
    },
  })
}

onMounted(fetchData)
</script>

<style scoped>
.admin-orders { padding-bottom: 24px; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.page-title { font-size: 22px; font-weight: 700; color: #1A1A1A; }
.filter-card { margin-bottom: 16px; }
.order-info { margin-bottom: 20px; }
.order-items-title { font-weight: 600; margin-bottom: 12px; color: #374151; }
.order-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px 0;
  border-bottom: 1px solid #f0f0f0;
}
.item-info { flex: 1; min-width: 0; }
.item-title { font-size: 14px; color: #1A1A1A; margin-bottom: 4px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.item-meta { font-size: 12px; color: #6b7280; }
.item-total { font-weight: 600; color: #ef4444; white-space: nowrap; }
.order-summary { display: flex; justify-content: flex-end; align-items: center; gap: 8px; font-size: 14px; color: #374151; }
.total-amount { font-size: 18px; font-weight: 700; color: #ef4444; }
.order-actions { margin-top: 16px; }
</style>
