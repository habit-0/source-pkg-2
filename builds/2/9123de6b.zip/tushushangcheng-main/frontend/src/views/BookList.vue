<template>
  <div class="book-list-page">
    <n-grid :cols="5" :x-gap="24">
      <!-- Sidebar: Categories -->
      <n-grid-item :span="1">
        <n-card class="sidebar-card" title="图书分类">
          <n-menu
            :options="categoryOptions"
            :value="selectedCategoryId"
            @update:value="handleCategoryChange"
          />
        </n-card>
      </n-grid-item>

      <!-- Main: Book List -->
      <n-grid-item :span="4">
        <!-- Filters & Sort -->
        <div class="filter-bar">
          <n-input
            v-model:value="keyword"
            placeholder="搜索书名、作者..."
            clearable
            style="width:300px"
            @keyup.enter="handleSearch"
          >
            <template #prefix><n-icon :component="SearchOutline" /></template>
          </n-input>

          <n-select
            v-model:value="sortBy"
            :options="sortOptions"
            style="width:160px"
            @update:value="handleFilter"
          />

          <n-tag v-if="selectedCategoryName" closable @close="clearCategory">
            {{ selectedCategoryName }}
          </n-tag>
        </div>

        <!-- Results count -->
        <div class="result-info">
          共找到 <strong>{{ total }}</strong> 本图书
        </div>

        <!-- Book Grid -->
        <n-spin :show="loading">
          <div v-if="books.length > 0" class="book-grid">
            <BookCard v-for="book in books" :key="book.id" :book="book" />
          </div>
          <n-empty v-else-if="!loading" description="暂无相关图书" size="large" />
        </n-spin>

        <!-- Pagination -->
        <div v-if="total > 0" class="pagination">
          <n-pagination
            v-model:page="page"
            :page-count="Math.ceil(total / pageSize)"
            :page-size="pageSize"
            show-quick-jumper
            @update:page="handlePageChange"
          />
        </div>
      </n-grid-item>
    </n-grid>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import {
  NGrid, NGridItem, NCard, NMenu, NInput, NSelect, NTag,
  NSpin, NEmpty, NPagination, NIcon,
} from 'naive-ui'
import type { MenuOption } from 'naive-ui'
import { SearchOutline, BookOutline } from '@vicons/ionicons5'
import { bookApi, categoryApi } from '@/api/book'
import type { Book, Category } from '@/api/book'
import BookCard from '@/components/BookCard.vue'
import { h } from 'vue'

const route = useRoute()
const router = useRouter()

const books = ref<Book[]>([])
const categories = ref<Category[]>([])
const loading = ref(false)
const total = ref(0)
const page = ref(1)
const pageSize = ref(16)
const keyword = ref('')
const sortBy = ref('')
const selectedCategoryId = ref<number | null>(null)

const sortOptions = [
  { label: '综合排序', value: '' },
  { label: '销量优先', value: 'sales' },
  { label: '评分最高', value: 'rating' },
  { label: '价格升序', value: 'price_asc' },
  { label: '价格降序', value: 'price_desc' },
  { label: '最新上架', value: 'new' },
]

const selectedCategoryName = computed(() => {
  if (!selectedCategoryId.value) return ''
  return categories.value.find(c => c.id === selectedCategoryId.value)?.name || ''
})

const categoryOptions = computed<MenuOption[]>(() => [
  { label: '全部分类', key: 0, icon: () => h(NIcon, null, { default: () => h(BookOutline) }) },
  ...categories.value.map(cat => ({
    label: cat.name,
    key: cat.id,
  })),
])

async function fetchBooks() {
  loading.value = true
  try {
    const result = await bookApi.getList({
      page: page.value,
      page_size: pageSize.value,
      keyword: keyword.value,
      sort_by: sortBy.value,
      category_id: selectedCategoryId.value || undefined,
    })
    books.value = result.list || []
    total.value = result.total
  } catch {
    books.value = []
  } finally {
    loading.value = false
  }
}

function handleSearch() {
  page.value = 1
  updateQuery()
  fetchBooks()
}

function handleFilter() {
  page.value = 1
  fetchBooks()
}

function handleCategoryChange(key: number) {
  selectedCategoryId.value = key === 0 ? null : key
  page.value = 1
  updateQuery()
  fetchBooks()
}

function clearCategory() {
  selectedCategoryId.value = null
  page.value = 1
  router.push({ path: '/books' })
  fetchBooks()
}

function handlePageChange(p: number) {
  page.value = p
  window.scrollTo({ top: 0, behavior: 'smooth' })
  fetchBooks()
}

function updateQuery() {
  const query: any = {}
  if (keyword.value) query.keyword = keyword.value
  if (selectedCategoryId.value) query.category_id = selectedCategoryId.value
  router.replace({ path: '/books', query })
}

onMounted(async () => {
  categories.value = await categoryApi.getCategories().catch(() => [])

  // Read query params
  keyword.value = (route.query.keyword as string) || ''
  selectedCategoryId.value = route.query.category_id ? Number(route.query.category_id) : null

  fetchBooks()
})

watch(() => route.query, (q) => {
  keyword.value = (q.keyword as string) || ''
  selectedCategoryId.value = q.category_id ? Number(q.category_id) : null
  page.value = 1
  fetchBooks()
}, { deep: true })
</script>

<style scoped>
.book-list-page {
  padding-bottom: 40px;
}

.sidebar-card {
  position: sticky;
  top: 100px;
}

.filter-bar {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
  flex-wrap: wrap;
}

.result-info {
  color: #6B6B6B;
  font-size: 14px;
  margin-bottom: 16px;
}

.book-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(175px, 1fr));
  gap: 20px;
  margin-bottom: 32px;
}

.pagination {
  display: flex;
  justify-content: center;
  margin-top: 32px;
}
</style>
