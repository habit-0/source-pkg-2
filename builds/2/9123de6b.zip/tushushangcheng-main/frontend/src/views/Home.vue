<template>
  <div class="home-page">

    <!-- ── Hero Banner ─────────────────────────────────────── -->
    <section class="hero">
      <div class="hero-body">
        <div class="hero-text">
          <p class="hero-eyebrow">精选好书 · 每日更新</p>
          <h1 class="hero-title">发现好书<br />启迪智慧</h1>
          <p class="hero-sub">海量图书精选，每日优惠推荐，让阅读改变生活</p>
          <div class="hero-actions">
            <n-button type="primary" size="large" @click="router.push('/books')">
              浏览图书 →
            </n-button>
            <n-button size="large" quaternary @click="router.push('/books?is_hot=1')">
              热门榜单
            </n-button>
          </div>
        </div>
        <div class="hero-stats">
          <div class="stat-item">
            <span class="stat-num">10,000+</span>
            <span class="stat-label">精品图书</span>
          </div>
          <div class="stat-item">
            <span class="stat-num">100,000+</span>
            <span class="stat-label">忠实读者</span>
          </div>
          <div class="stat-item">
            <span class="stat-num">24h</span>
            <span class="stat-label">快速发货</span>
          </div>
        </div>
      </div>
    </section>

    <!-- ── Category Quick Access ───────────────────────────── -->
    <section class="section">
      <div class="section-header">
        <h2 class="section-title">图书分类</h2>
        <n-button text @click="router.push('/books')" class="see-all">
          查看全部 →
        </n-button>
      </div>
      <div class="category-grid">
        <div
          v-for="(cat, idx) in categories"
          :key="cat.id"
          class="category-card"
          @click="router.push(`/books?category_id=${cat.id}`)"
        >
          <div class="cat-icon-wrap">
            <n-icon :component="getCategoryIcon(cat.icon)" size="22" />
          </div>
          <span class="cat-name">{{ cat.name }}</span>
        </div>
      </div>
    </section>

    <!-- ── Featured Recommend ──────────────────────────────── -->
    <section class="section">
      <div class="section-header">
        <h2 class="section-title">精选推荐</h2>
        <n-button text @click="router.push('/books?is_recommend=1')" class="see-all">
          查看全部 →
        </n-button>
      </div>
      <n-spin :show="loadingRecommend">
        <div class="book-grid">
          <BookCard
            v-for="book in recommendBooks"
            :key="book.id"
            :book="book"
          />
          <div v-if="!loadingRecommend && recommendBooks.length === 0" class="empty-hint">
            暂无推荐图书
          </div>
        </div>
      </n-spin>
    </section>

    <!-- ── Hot Books ───────────────────────────────────────── -->
    <section class="section">
      <div class="section-header">
        <h2 class="section-title">热门热卖</h2>
        <n-button text @click="router.push('/books?is_hot=1')" class="see-all">
          查看全部 →
        </n-button>
      </div>
      <n-spin :show="loadingHot">
        <div class="book-grid">
          <BookCard
            v-for="book in hotBooks.slice(0, 8)"
            :key="book.id"
            :book="book"
          />
        </div>
      </n-spin>
    </section>

  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { NSpin, NButton, NIcon } from 'naive-ui'
import {
  BookOutline, FlameOutline, StarOutline, LibraryOutline,
  LaptopOutline, TrendingUpOutline, SchoolOutline,
  HeartOutline, HappyOutline, ColorPaletteOutline,
  ChevronForwardOutline,
} from '@vicons/ionicons5'
import { bookApi, categoryApi } from '@/api/book'
import type { Book, Category } from '@/api/book'
import BookCard from '@/components/BookCard.vue'

const router = useRouter()
const categories = ref<Category[]>([])
const recommendBooks = ref<Book[]>([])
const hotBooks = ref<Book[]>([])
const loadingRecommend = ref(false)
const loadingHot = ref(false)

const iconMap: Record<string, any> = {
  'book-outline':          BookOutline,
  'laptop-outline':        LaptopOutline,
  'trending-up-outline':   TrendingUpOutline,
  'library-outline':       LibraryOutline,
  'school-outline':        SchoolOutline,
  'heart-outline':         HeartOutline,
  'happy-outline':         HappyOutline,
  'color-palette-outline': ColorPaletteOutline,
}

function getCategoryIcon(icon: string) {
  return iconMap[icon] || BookOutline
}

onMounted(async () => {
  try { categories.value = await categoryApi.getCategories() } catch {}

  loadingRecommend.value = true
  try { recommendBooks.value = await bookApi.getRecommend() } catch {}
  finally { loadingRecommend.value = false }

  loadingHot.value = true
  try { hotBooks.value = await bookApi.getHot() } catch {}
  finally { loadingHot.value = false }
})
</script>

<style scoped>
.home-page {
  padding-bottom: 48px;
}

/* ─────────────── Hero ─────────────── */
.hero {
  margin-bottom: 56px;
}

.hero-body {
  padding: 64px 0 48px;
  border-bottom: 1px solid #F0EDE8;
}

.hero-eyebrow {
  font-size: 13px;
  font-weight: 500;
  color: #9B9B9B;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  margin-bottom: 16px;
}

.hero-title {
  font-size: 48px;
  font-weight: 700;
  color: #1A1A1A;
  line-height: 1.1;
  margin-bottom: 16px;
  letter-spacing: -0.03em;
}

.hero-sub {
  font-size: 16px;
  color: #6B6B6B;
  margin-bottom: 32px;
  line-height: 1.6;
  max-width: 480px;
}

.hero-actions {
  display: flex;
  gap: 12px;
  margin-bottom: 48px;
}

/* Stats */
.hero-stats {
  display: flex;
  gap: 48px;
  padding-top: 32px;
}

.stat-item {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.stat-num {
  font-size: 24px;
  font-weight: 700;
  color: #1A1A1A;
  letter-spacing: -0.02em;
  line-height: 1.2;
}

.stat-label {
  font-size: 13px;
  color: #9B9B9B;
  font-weight: 400;
}

/* ─────────────── Sections ─────────────── */
.section {
  margin-bottom: 56px;
}

.section-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 24px;
}

.section-title {
  font-size: 20px;
  font-weight: 600;
  color: #1A1A1A;
  letter-spacing: -0.02em;
}

.see-all {
  font-size: 13px;
  color: #9B9B9B !important;
  font-weight: 500;
}

.see-all:hover {
  color: #1A1A1A !important;
}

/* ─────────────── Category Grid ─────────────── */
.category-grid {
  display: grid;
  grid-template-columns: repeat(8, 1fr);
  gap: 12px;
}

.category-card {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  padding: 20px 12px;
  background: #fff;
  border-radius: 12px;
  cursor: pointer;
  transition: all 0.2s ease;
  border: 1px solid #F0EDE8;
}

.category-card:hover {
  border-color: #E0DDD8;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.06);
  transform: translateY(-2px);
}

.cat-icon-wrap {
  width: 44px;
  height: 44px;
  border-radius: 10px;
  background: #F5F3F0;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #4A4A4A;
  transition: all 0.2s ease;
}

.category-card:hover .cat-icon-wrap {
  background: #1A1A1A;
  color: #fff;
}

.cat-name {
  font-size: 12px;
  color: #4A4A4A;
  font-weight: 500;
  text-align: center;
  line-height: 1.3;
}

/* ─────────────── Book Grid ─────────────── */
.book-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 20px;
}

.empty-hint {
  color: #9B9B9B;
  font-size: 14px;
  padding: 40px;
  text-align: center;
  grid-column: 1 / -1;
}

/* ─────────────── Responsive ─────────────── */
@media (max-width: 1024px) {
  .category-grid { grid-template-columns: repeat(4, 1fr); }
}

@media (max-width: 768px) {
  .category-grid { grid-template-columns: repeat(4, 1fr); }
  .hero-title { font-size: 32px; }
  .hero-stats { gap: 24px; }
  .stat-num { font-size: 20px; }
  .book-grid { grid-template-columns: repeat(2, 1fr); gap: 12px; }
}
</style>
