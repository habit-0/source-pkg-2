<template>
  <div class="order-detail-page">
    <n-breadcrumb class="breadcrumb">
      <n-breadcrumb-item @click="router.push('/')">首页</n-breadcrumb-item>
      <n-breadcrumb-item @click="router.push('/orders')">我的订单</n-breadcrumb-item>
      <n-breadcrumb-item>订单详情</n-breadcrumb-item>
    </n-breadcrumb>

    <n-spin :show="loading">
      <template v-if="order">
        <!-- Status -->
        <n-card class="status-card">
          <div class="status-content">
            <n-icon :component="getStatusIcon(order.status)" size="48" :color="getStatusColor(order.status)" />
            <div>
              <h2 class="status-text">{{ getStatusText(order.status) }}</h2>
              <p class="status-desc">{{ getStatusDesc(order.status) }}</p>
            </div>
          </div>
          <div class="status-actions">
            <n-button v-if="order.status === 0" type="primary" @click="payOrder">立即支付</n-button>
            <n-button v-if="order.status === 0" @click="cancelOrder">取消订单</n-button>
          </div>
        </n-card>

        <n-grid :cols="3" :x-gap="16" style="margin-top:16px">
          <!-- Items -->
          <n-grid-item :span="2">
            <n-card title="商品信息">
              <div v-for="item in order.items" :key="item.id" class="order-item">
                <img :src="item.cover || defaultCover" :alt="item.title" class="item-cover" />
                <div class="item-info">
                  <p class="item-title">{{ item.title }}</p>
                  <p class="item-author">{{ item.author }}</p>
                </div>
                <div class="item-right">
                  <p class="item-price">¥{{ item.price.toFixed(2) }}</p>
                  <p class="item-qty">× {{ item.quantity }}</p>
                  <p class="item-sub">= ¥{{ item.subtotal.toFixed(2) }}</p>
                </div>
              </div>
            </n-card>
          </n-grid-item>

          <!-- Summary -->
          <n-grid-item :span="1">
            <n-card title="订单信息">
              <n-descriptions :columns="1" label-placement="left" size="small">
                <n-descriptions-item label="订单号">{{ order.order_no }}</n-descriptions-item>
                <n-descriptions-item label="下单时间">{{ formatDate(order.created_at) }}</n-descriptions-item>
                <n-descriptions-item v-if="order.paid_at" label="支付时间">{{ formatDate(order.paid_at) }}</n-descriptions-item>
                <n-descriptions-item label="收货人">{{ order.receiver_name }}</n-descriptions-item>
                <n-descriptions-item label="联系电话">{{ order.receiver_phone }}</n-descriptions-item>
                <n-descriptions-item label="收货地址">{{ order.receiver_addr }}</n-descriptions-item>
                <n-descriptions-item v-if="order.remark" label="备注">{{ order.remark }}</n-descriptions-item>
              </n-descriptions>
              <n-divider />
              <div class="price-summary">
                <div class="price-row">
                  <span>商品总价</span>
                  <span>¥{{ order.total_price.toFixed(2) }}</span>
                </div>
                <div class="price-row actual">
                  <span>实付金额</span>
                  <span class="actual-price">¥{{ order.actual_price.toFixed(2) }}</span>
                </div>
              </div>
            </n-card>
          </n-grid-item>
        </n-grid>
      </template>
    </n-spin>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import {
  NSpin, NCard, NGrid, NGridItem, NIcon, NButton,
  NBreadcrumb, NBreadcrumbItem, NDescriptions, NDescriptionsItem, NDivider,
  useMessage, useDialog,
} from 'naive-ui'
import {
  TimeOutline, CheckmarkCircleOutline, CarOutline,
  TrophyOutline, CloseCircleOutline,
} from '@vicons/ionicons5'
import { orderApi, ORDER_STATUS_MAP, type Order } from '@/api/order'
import dayjs from 'dayjs'

const route = useRoute()
const router = useRouter()
const message = useMessage()
const dialog = useDialog()

const order = ref<Order | null>(null)
const loading = ref(true)
const defaultCover = 'https://via.placeholder.com/64x80/6366f1/ffffff?text=📚'

const statusIcons: Record<number, any> = {
  0: TimeOutline,
  1: CheckmarkCircleOutline,
  2: CarOutline,
  3: TrophyOutline,
  4: CloseCircleOutline,
}

const statusColors: Record<number, string> = {
  0: '#f59e0b',
  1: '#1A1A1A',
  2: '#3b82f6',
  3: '#22c55e',
  4: '#9B9B9B',
}

const statusDescs: Record<number, string> = {
  0: '请在24小时内完成支付，超时订单将自动取消',
  1: '已支付成功，等待商家发货',
  2: '商品已发出，请耐心等待',
  3: '订单已完成，感谢您的购买！',
  4: '订单已取消',
}

function getStatusIcon(status: number) { return statusIcons[status] || TimeOutline }
function getStatusColor(status: number) { return statusColors[status] || '#9B9B9B' }
function getStatusText(status: number) { return ORDER_STATUS_MAP[status] || '未知' }
function getStatusDesc(status: number) { return statusDescs[status] || '' }
function formatDate(date: string | null) { return date ? dayjs(date).format('YYYY-MM-DD HH:mm:ss') : '-' }

async function payOrder() {
  if (!order.value) return
  dialog.info({
    title: '模拟支付',
    content: `确认支付 ¥${order.value.actual_price.toFixed(2)} ?`,
    positiveText: '确认支付',
    negativeText: '取消',
    onPositiveClick: async () => {
      try {
        await orderApi.payOrder(order.value!.id, 'mock')
        message.success('支付成功')
        loadOrder()
      } catch (err: any) {
        message.error(err.message)
      }
    },
  })
}

async function cancelOrder() {
  if (!order.value) return
  dialog.warning({
    title: '取消订单',
    content: '确定取消此订单？',
    positiveText: '确认取消',
    negativeText: '再想想',
    onPositiveClick: async () => {
      try {
        await orderApi.cancelOrder(order.value!.id)
        message.success('已取消')
        loadOrder()
      } catch (err: any) {
        message.error(err.message)
      }
    },
  })
}

async function loadOrder() {
  loading.value = true
  try {
    const id = Number(route.params.id)
    order.value = await orderApi.getDetail(id)
  } catch {
    order.value = null
  } finally {
    loading.value = false
  }
}

onMounted(loadOrder)
</script>

<style scoped>
.order-detail-page { padding-bottom: 40px; }
.breadcrumb { margin-bottom: 16px; }

.status-card { margin-bottom: 0; }

.status-content {
  display: flex;
  align-items: center;
  gap: 16px;
  margin-bottom: 16px;
}

.status-text { font-size: 24px; font-weight: 700; color: #1A1A1A; }
.status-desc { font-size: 14px; color: #6B6B6B; margin-top: 4px; }

.status-actions { display: flex; gap: 10px; }

.order-item {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 12px 0;
  border-bottom: 1px solid #f1f5f9;
}
.order-item:last-child { border-bottom: none; }

.item-cover { width: 72px; height: 88px; object-fit: cover; border-radius: 8px; }
.item-info { flex: 1; }
.item-title { font-size: 15px; font-weight: 500; color: #1A1A1A; }
.item-author { font-size: 13px; color: #9B9B9B; margin-top: 4px; }
.item-right { text-align: right; flex-shrink: 0; }
.item-price { font-size: 14px; color: #6B6B6B; }
.item-qty { font-size: 13px; color: #9B9B9B; }
.item-sub { font-size: 16px; font-weight: 600; color: #ef4444; }

.price-summary { display: flex; flex-direction: column; gap: 8px; }
.price-row { display: flex; justify-content: space-between; font-size: 14px; color: #6B6B6B; }
.price-row.actual { font-weight: 700; color: #1A1A1A; }
.actual-price { font-size: 20px; color: #ef4444; }
</style>
