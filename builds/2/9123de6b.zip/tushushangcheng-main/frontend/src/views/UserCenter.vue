<template>
  <div class="user-center">
    <n-grid :cols="4" :x-gap="20">
      <!-- Left: User Info -->
      <n-grid-item :span="1">
        <n-card class="user-card">
          <div class="user-avatar-wrapper">
            <n-avatar
              round
              :size="80"
              :src="userInfo?.avatar"
              :fallback-src="defaultAvatar"
            />
            <div class="user-name">{{ userInfo?.nickname || userInfo?.username }}</div>
            <div class="user-email">{{ userInfo?.email }}</div>
          </div>
          <n-menu
            :options="menuOptions"
            :value="activeMenu"
            @update:value="activeMenu = $event as string"
          />
        </n-card>
      </n-grid-item>

      <!-- Right: Content -->
      <n-grid-item :span="3">
        <!-- Profile -->
        <n-card v-if="activeMenu === 'profile'" title="个人信息">
          <n-form :model="profileForm" label-placement="left" :label-width="80">
            <n-form-item label="用户名">
              <n-input :value="userInfo?.username" disabled />
            </n-form-item>
            <n-form-item label="邮箱">
              <n-input :value="userInfo?.email" disabled />
            </n-form-item>
            <n-form-item label="昵称">
              <n-input v-model:value="profileForm.nickname" placeholder="请输入昵称" />
            </n-form-item>
            <n-form-item label="手机号">
              <n-input v-model:value="profileForm.phone" placeholder="请输入手机号" />
            </n-form-item>
            <n-form-item>
              <n-button type="primary" :loading="savingProfile" @click="saveProfile">
                保存修改
              </n-button>
            </n-form-item>
          </n-form>
        </n-card>

        <!-- Change Password -->
        <n-card v-else-if="activeMenu === 'password'" title="修改密码">
          <n-form :model="pwdForm" :rules="pwdRules" label-placement="left" :label-width="100" ref="pwdFormRef">
            <n-form-item label="当前密码" path="old_password">
              <n-input v-model:value="pwdForm.old_password" type="password" show-password-on="click" />
            </n-form-item>
            <n-form-item label="新密码" path="new_password">
              <n-input v-model:value="pwdForm.new_password" type="password" show-password-on="click" />
            </n-form-item>
            <n-form-item label="确认新密码" path="confirm_password">
              <n-input v-model:value="pwdForm.confirm_password" type="password" show-password-on="click" />
            </n-form-item>
            <n-form-item>
              <n-button type="primary" :loading="changingPwd" @click="changePassword">
                修改密码
              </n-button>
            </n-form-item>
          </n-form>
        </n-card>

        <!-- Addresses -->
        <n-card v-else-if="activeMenu === 'address'" title="收货地址">
          <div class="address-list">
            <n-card
              v-for="addr in addresses"
              :key="addr.id"
              class="address-card"
              :class="{ 'is-default': addr.is_default === 1 }"
              size="small"
            >
              <div class="addr-content">
                <div class="addr-info">
                  <span class="addr-name">{{ addr.name }}</span>
                  <span class="addr-phone">{{ addr.phone }}</span>
                  <n-tag v-if="addr.is_default === 1" size="small" type="primary">默认</n-tag>
                </div>
                <p class="addr-text">{{ addr.province }} {{ addr.city }} {{ addr.district }} {{ addr.address }}</p>
              </div>
              <div class="addr-actions">
                <n-button text size="small" @click="editAddress(addr)">编辑</n-button>
                <n-button text size="small" type="error" @click="deleteAddress(addr.id)">删除</n-button>
              </div>
            </n-card>
          </div>
          <n-button type="primary" dashed block style="margin-top:12px" @click="openAddAddressModal">
            <template #icon><n-icon :component="AddOutline" /></template>
            添加新地址
          </n-button>
        </n-card>
      </n-grid-item>
    </n-grid>

    <!-- Address Modal -->
    <n-modal v-model:show="showAddrModal" :title="editingAddr ? '编辑地址' : '添加地址'" preset="card" style="width:480px">
      <n-form :model="addrForm" label-placement="left" :label-width="80" :rules="addrRules" ref="addrFormRef">
        <n-grid :cols="2" :x-gap="12">
          <n-grid-item>
            <n-form-item label="收货人" path="name">
              <n-input v-model:value="addrForm.name" placeholder="请输入姓名" />
            </n-form-item>
          </n-grid-item>
          <n-grid-item>
            <n-form-item label="手机号" path="phone">
              <n-input v-model:value="addrForm.phone" placeholder="请输入手机号" />
            </n-form-item>
          </n-grid-item>
          <n-grid-item>
            <n-form-item label="省份" path="province">
              <n-input v-model:value="addrForm.province" placeholder="省份" />
            </n-form-item>
          </n-grid-item>
          <n-grid-item>
            <n-form-item label="城市" path="city">
              <n-input v-model:value="addrForm.city" placeholder="城市" />
            </n-form-item>
          </n-grid-item>
          <n-grid-item>
            <n-form-item label="区县" path="district">
              <n-input v-model:value="addrForm.district" placeholder="区县" />
            </n-form-item>
          </n-grid-item>
          <n-grid-item>
            <n-form-item label="默认地址">
              <n-switch v-model:value="addrFormDefault" />
            </n-form-item>
          </n-grid-item>
          <n-grid-item :span="2">
            <n-form-item label="详细地址" path="address">
              <n-input v-model:value="addrForm.address" type="textarea" placeholder="请输入详细地址" />
            </n-form-item>
          </n-grid-item>
        </n-grid>
      </n-form>
      <template #action>
        <n-space justify="end">
          <n-button @click="showAddrModal = false">取消</n-button>
          <n-button type="primary" :loading="savingAddr" @click="saveAddress">保存</n-button>
        </n-space>
      </template>
    </n-modal>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, h } from 'vue'
import {
  NGrid, NGridItem, NCard, NMenu, NAvatar, NForm, NFormItem,
  NInput, NButton, NIcon, NTag, NModal, NSpace, NSwitch,
  useMessage, useDialog,
} from 'naive-ui'
import type { MenuOption, FormRules, FormInst } from 'naive-ui'
import { PersonOutline, LockClosedOutline, LocationOutline, AddOutline } from '@vicons/ionicons5'
import { useUserStore } from '@/stores/user'
import { userApi, type Address } from '@/api/user'

const userStore = useUserStore()
const message = useMessage()
const dialog = useDialog()

const userInfo = computed(() => userStore.userInfo)
const defaultAvatar = 'https://api.dicebear.com/7.x/avataaars/svg?seed=bookmall'
const activeMenu = ref('profile')

const menuOptions: MenuOption[] = [
  { label: '个人信息', key: 'profile', icon: () => h(NIcon, null, { default: () => h(PersonOutline) }) },
  { label: '修改密码', key: 'password', icon: () => h(NIcon, null, { default: () => h(LockClosedOutline) }) },
  { label: '收货地址', key: 'address', icon: () => h(NIcon, null, { default: () => h(LocationOutline) }) },
]

// Profile
const profileForm = ref({ nickname: userInfo.value?.nickname || '', phone: userInfo.value?.phone || '' })
const savingProfile = ref(false)

async function saveProfile() {
  savingProfile.value = true
  try {
    await userApi.updateProfile(profileForm.value)
    if (userStore.userInfo) {
      userStore.userInfo.nickname = profileForm.value.nickname
      userStore.userInfo.phone = profileForm.value.phone
    }
    message.success('保存成功')
  } catch (err: any) {
    message.error(err.message)
  } finally {
    savingProfile.value = false
  }
}

// Password
const pwdFormRef = ref<FormInst | null>(null)
const pwdForm = ref({ old_password: '', new_password: '', confirm_password: '' })
const changingPwd = ref(false)

const pwdRules: FormRules = {
  old_password: [{ required: true, message: '请输入当前密码' }],
  new_password: [{ required: true, min: 6, message: '新密码至少6位' }],
  confirm_password: [{
    required: true,
    validator: (rule, value) => {
      if (value !== pwdForm.value.new_password) return new Error('两次密码不一致')
      return true
    },
  }],
}

async function changePassword() {
  await pwdFormRef.value?.validate()
  changingPwd.value = true
  try {
    await userApi.changePassword({
      old_password: pwdForm.value.old_password,
      new_password: pwdForm.value.new_password,
    })
    message.success('密码修改成功')
    pwdForm.value = { old_password: '', new_password: '', confirm_password: '' }
  } catch (err: any) {
    message.error(err.message)
  } finally {
    changingPwd.value = false
  }
}

// Addresses
const addresses = ref<Address[]>([])
const showAddrModal = ref(false)
const editingAddr = ref<Address | null>(null)
const addrFormRef = ref<FormInst | null>(null)
const savingAddr = ref(false)
const addrFormDefault = ref(false)
const addrForm = ref({ name: '', phone: '', province: '', city: '', district: '', address: '' })

const addrRules: FormRules = {
  name: [{ required: true, message: '请输入收货人' }],
  phone: [{ required: true, message: '请输入手机号' }],
  province: [{ required: true, message: '请输入省份' }],
  city: [{ required: true, message: '请输入城市' }],
  district: [{ required: true, message: '请输入区县' }],
  address: [{ required: true, message: '请输入详细地址' }],
}

async function loadAddresses() {
  try {
    addresses.value = await userApi.getAddresses()
  } catch {}
}

function openAddAddressModal() {
  editingAddr.value = null
  addrForm.value = { name: '', phone: '', province: '', city: '', district: '', address: '' }
  addrFormDefault.value = false
  showAddrModal.value = true
}

function editAddress(addr: Address) {
  editingAddr.value = addr
  addrForm.value = { ...addr }
  addrFormDefault.value = addr.is_default === 1
  showAddrModal.value = true
}

async function saveAddress() {
  await addrFormRef.value?.validate()
  savingAddr.value = true
  try {
    const data = { ...addrForm.value, is_default: addrFormDefault.value ? 1 : 0 }
    if (editingAddr.value) {
      await userApi.updateAddress(editingAddr.value.id, data)
    } else {
      await userApi.createAddress(data as any)
    }
    showAddrModal.value = false
    message.success('保存成功')
    loadAddresses()
  } catch (err: any) {
    message.error(err.message)
  } finally {
    savingAddr.value = false
  }
}

async function deleteAddress(id: number) {
  dialog.warning({
    title: '删除地址',
    content: '确定删除此地址吗？',
    positiveText: '删除',
    negativeText: '取消',
    onPositiveClick: async () => {
      await userApi.deleteAddress(id)
      message.success('删除成功')
      loadAddresses()
    },
  })
}

onMounted(() => {
  loadAddresses()
  profileForm.value.nickname = userInfo.value?.nickname || ''
  profileForm.value.phone = userInfo.value?.phone || ''
})
</script>

<style scoped>
.user-center { padding-bottom: 40px; }

.user-card { position: sticky; top: 100px; }

.user-avatar-wrapper {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px 0;
  border-bottom: 1px solid #f1f5f9;
  margin-bottom: 8px;
}

.user-name {
  font-size: 18px;
  font-weight: 700;
  color: #1A1A1A;
  margin-top: 12px;
}

.user-email { font-size: 13px; color: #9B9B9B; margin-top: 4px; }

.address-list { display: flex; flex-direction: column; gap: 10px; }

.address-card {
  border: 1px solid #e2e8f0;
  transition: border-color 0.2s;
}

.address-card.is-default { border-color: #1A1A1A; }

.addr-content { flex: 1; }

.addr-info {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 6px;
}

.addr-name { font-weight: 600; font-size: 15px; }
.addr-phone { color: #6B6B6B; }
.addr-text { font-size: 13px; color: #475569; }

.addr-actions { display: flex; gap: 8px; justify-content: flex-end; margin-top: 8px; }
</style>
