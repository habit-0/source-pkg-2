<template>
  <div class="book-detail-page">
    <n-spin :show="loading">
      <template v-if="book">
        <!-- Breadcrumb -->
        <n-breadcrumb class="breadcrumb">
          <n-breadcrumb-item @click="router.push('/')">首页</n-breadcrumb-item>
          <n-breadcrumb-item @click="router.push('/books')">图书列表</n-breadcrumb-item>
          <n-breadcrumb-item>{{ book.title }}</n-breadcrumb-item>
        </n-breadcrumb>

        <n-card>
          <n-grid :cols="12" :x-gap="48">
            <!-- Cover -->
            <n-grid-item :span="3">
              <div class="cover-wrapper">
                <img
                  :src="book.cover || fallbackCover"
                  :alt="book.title"
                  class="book-cover-img"
                  @error="e => ((e.target as HTMLImageElement).src = fallbackCover)"
                />
              </div>
            </n-grid-item>

            <!-- Info -->
            <n-grid-item :span="9">
              <!-- Tags -->
              <div class="tags-row">
                <n-tag v-if="book.is_hot" type="error" round size="small">🔥 热销</n-tag>
                <n-tag v-if="book.is_recommend" type="info" round size="small">⭐ 推荐</n-tag>
                <n-tag v-if="book.category" round size="small">{{ book.category.name }}</n-tag>
              </div>

              <h1 class="detail-title">{{ book.title }}</h1>
              <p class="detail-author">作者：{{ book.author }}</p>

              <!-- Rating -->
              <div class="rating-row">
                <n-rate :value="book.rating / 2" allow-half readonly />
                <span class="rating-val">{{ book.rating }}</span>
                <n-divider vertical />
                <span class="sales-info">已售 {{ book.sales.toLocaleString() }}+</span>
              </div>

              <!-- Price -->
              <div class="price-block">
                <span class="price-main">¥{{ book.price.toFixed(2) }}</span>
                <span v-if="book.original_price > book.price" class="price-origin">
                  ¥{{ book.original_price.toFixed(2) }}
                </span>
                <n-tag v-if="book.original_price > book.price" type="error" size="small">
                  {{ Math.round((1 - book.price / book.original_price) * 10) }}折
                </n-tag>
              </div>

              <!-- Stock -->
              <div class="stock-info">
                <n-icon :component="CheckmarkCircleOutline" color="#22c55e" />
                <span>
                  {{
                    (book.inventory?.stock ?? 0) > 0
                      ? `现货 (库存 ${book.inventory?.stock} 本)`
                      : '暂时缺货'
                  }}
                </span>
              </div>

              <!-- Quantity & Actions -->
              <div class="action-row">
                <n-input-number
                  v-model:value="quantity"
                  :min="1"
                  :max="book.inventory?.stock || 1"
                  style="width: 120px"
                />
                <n-button
                  size="large"
                  type="primary"
                  :loading="addingToCart"
                  @click="addToCart"
                >
                  <template #icon><n-icon :component="CartOutline" /></template>
                  加入购物车
                </n-button>
                <n-button size="large" @click="buyNow">立即购买</n-button>
              </div>

              <!-- Details -->
              <n-descriptions class="book-meta" :columns="2" label-placement="left" size="small">
                <n-descriptions-item label="出版社">{{ book.publisher || '-' }}</n-descriptions-item>
                <n-descriptions-item label="ISBN">{{ book.isbn || '-' }}</n-descriptions-item>
                <n-descriptions-item v-if="book.publish_date" label="出版日期">
                  {{ book.publish_date }}
                </n-descriptions-item>
                <n-descriptions-item v-if="book.tags" label="标签">{{ book.tags }}</n-descriptions-item>
              </n-descriptions>
            </n-grid-item>
          </n-grid>

          <!-- Description -->
          <n-divider />
          <div class="description-section">
            <h3 class="desc-title">内容简介</h3>
            <p class="desc-content">{{ book.description || '暂无简介' }}</p>
          </div>
        </n-card>
      </template>

      <n-result v-else-if="!loading" status="404" title="图书不存在">
        <template #footer>
          <n-button @click="router.push('/books')">返回列表</n-button>
        </template>
      </n-result>
    </n-spin>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import {
  NSpin, NCard, NGrid, NGridItem, NTag, NRate, NDivider,
  NButton, NInputNumber, NDescriptions, NDescriptionsItem,
  NBreadcrumb, NBreadcrumbItem, NIcon, NResult, useMessage,
} from 'naive-ui'
import { CartOutline, CheckmarkCircleOutline } from '@vicons/ionicons5'
import { bookApi } from '@/api/book'
import type { Book } from '@/api/book'
import { useUserStore } from '@/stores/user'
import { useCartStore } from '@/stores/cart'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()
const cartStore = useCartStore()
const message = useMessage()

const book = ref<Book | null>(null)
const loading = ref(true)
const quantity = ref(1)
const addingToCart = ref(false)
const fallbackCover = 'https://placehold.co/300x400/F5F3F0/9B9B9B?text=Book'

onMounted(async () => {
  try {
    const id = Number(route.params.id)
    book.value = await bookApi.getDetail(id)
  } catch {
    book.value = null
  } finally {
    loading.value = false
  }
})

async function addToCart() {
  if (!userStore.isLoggedIn) {
    message.warning('请先登录')
    router.push('/login')
    return
  }
  if (!book.value) return
  addingToCart.value = true
  try {
    await cartStore.addToCart(book.value.id, quantity.value)
    message.success('已加入购物车')
  } catch (err: any) {
    message.error(err.message || '添加失败')
  } finally {
    addingToCart.value = false
  }
}

async function buyNow() {
  await addToCart()
  if (userStore.isLoggedIn) {
    router.push('/cart')
  }
}
</script>

<style scoped>
.book-detail-page {
  padding-bottom: 40px;
}

.breadcrumb {
  margin-bottom: 16px;
}

.cover-wrapper {
  background: #F5F3F0;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 4px 20px rgba(0,0,0,0.06);
}

.book-cover-img {
  width: 100%;
  display: block;
}

.tags-row {
  display: flex;
  gap: 8px;
  margin-bottom: 12px;
  flex-wrap: wrap;
}

.detail-title {
  font-size: 28px;
  font-weight: 700;
  color: #1A1A1A;
  margin-bottom: 8px;
  line-height: 1.3;
  letter-spacing: -0.02em;
}

.detail-author {
  font-size: 15px;
  color: #6B6B6B;
  margin-bottom: 16px;
}

.rating-row {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 20px;
}

.rating-val {
  font-size: 18px;
  font-weight: 700;
  color: #f59e0b;
}

.sales-info {
  font-size: 13px;
  color: #9B9B9B;
}

.price-block {
  display: flex;
  align-items: baseline;
  gap: 10px;
  padding: 16px 20px;
  background: #F5F3F0;
  border-radius: 10px;
  margin-bottom: 16px;
}

.price-main {
  font-size: 36px;
  font-weight: 800;
  color: #1A1A1A;
}

.price-origin {
  font-size: 16px;
  color: #C0C0C0;
  text-decoration: line-through;
}

.stock-info {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 14px;
  color: #22c55e;
  margin-bottom: 20px;
}

.action-row {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 24px;
}

.book-meta {
  padding: 16px;
  background: #F5F3F0;
  border-radius: 8px;
}

.description-section {
  padding: 0 8px;
}

.desc-title {
  font-size: 18px;
  font-weight: 600;
  color: #1A1A1A;
  margin-bottom: 12px;
}

.desc-content {
  font-size: 15px;
  color: #4A4A4A;
  line-height: 1.8;
  white-space: pre-wrap;
}
</style>
