<template>
  <div class="auth-page">
    <div class="auth-container">
      <!-- Left: Visual Brand Panel -->
      <div class="auth-left">
        <div class="left-content">
          <div class="left-top">
            <div class="brand-icon">
              <n-icon :component="BookOutline" size="24" />
            </div>
            <h1 class="brand-name">图书商城</h1>
            <p class="brand-tagline">加入我们，开启阅读之旅</p>
          </div>

          <div class="left-middle">
            <div class="feature-list">
              <div class="feature-item">
                <div class="feature-icon-circle">
                  <n-icon :component="BookOutline" size="18" />
                </div>
                <div class="feature-text">
                  <span class="feature-title">每日好书</span>
                  <span class="feature-desc">精选推荐，不错过好书</span>
                </div>
              </div>
              <div class="feature-item">
                <div class="feature-icon-circle">
                  <n-icon :component="SparklesOutline" size="18" />
                </div>
                <div class="feature-text">
                  <span class="feature-title">个性化书单</span>
                  <span class="feature-desc">AI 智能推荐，懂你所爱</span>
                </div>
              </div>
              <div class="feature-item">
                <div class="feature-icon-circle">
                  <n-icon :component="GiftOutline" size="18" />
                </div>
                <div class="feature-text">
                  <span class="feature-title">专属优惠</span>
                  <span class="feature-desc">会员专享折扣与活动</span>
                </div>
              </div>
            </div>
          </div>

          <p class="left-footer">© 2024 图书商城</p>
        </div>
      </div>

      <!-- Right: Form -->
      <div class="auth-right">
        <div class="form-wrapper">
          <div class="form-header">
            <h2 class="form-title">创建账号</h2>
            <p class="form-subtitle">
              已有账号？
              <span class="link" @click="router.push('/login')">立即登录</span>
            </p>
          </div>

          <n-form ref="formRef" :model="form" :rules="rules" size="large">
            <n-form-item path="username" :show-label="false">
              <n-input v-model:value="form.username" placeholder="用户名（3-50字符）">
                <template #prefix>
                  <n-icon :component="PersonOutline" color="#999" />
                </template>
              </n-input>
            </n-form-item>

            <n-form-item path="email" :show-label="false">
              <n-input v-model:value="form.email" placeholder="邮箱">
                <template #prefix>
                  <n-icon :component="MailOutline" color="#999" />
                </template>
              </n-input>
            </n-form-item>

            <n-form-item path="password" :show-label="false">
              <n-input
                v-model:value="form.password"
                type="password"
                placeholder="密码（至少6位）"
                show-password-on="click"
              >
                <template #prefix>
                  <n-icon :component="LockClosedOutline" color="#999" />
                </template>
              </n-input>
            </n-form-item>

            <n-form-item path="confirm" :show-label="false">
              <n-input
                v-model:value="form.confirm"
                type="password"
                placeholder="确认密码"
                show-password-on="click"
              >
                <template #prefix>
                  <n-icon :component="ShieldCheckmarkOutline" color="#999" />
                </template>
              </n-input>
            </n-form-item>

            <n-button
              block
              type="primary"
              size="large"
              :loading="loading"
              @click="handleRegister"
              class="register-btn"
            >
              注册
            </n-button>
          </n-form>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { NForm, NFormItem, NInput, NButton, NIcon, useMessage } from 'naive-ui'
import type { FormInst, FormRules } from 'naive-ui'
import {
  PersonOutline, MailOutline, LockClosedOutline, ShieldCheckmarkOutline,
  BookOutline, SparklesOutline, GiftOutline
} from '@vicons/ionicons5'
import { authApi } from '@/api/user'
import { useUserStore } from '@/stores/user'

const router = useRouter()
const userStore = useUserStore()
const message = useMessage()

const formRef = ref<FormInst | null>(null)
const loading = ref(false)
const form = ref({ username: '', email: '', password: '', confirm: '' })

const rules: FormRules = {
  username: [{ required: true, min: 3, max: 50, message: '用户名3-50字符' }],
  email: [{ required: true, type: 'email', message: '请输入有效邮箱' }],
  password: [{ required: true, min: 6, message: '密码至少6位' }],
  confirm: [{
    required: true,
    validator: (rule, value) => {
      if (value !== form.value.password) return new Error('两次密码不一致')
      return true
    },
  }],
}

async function handleRegister() {
  await formRef.value?.validate()
  loading.value = true
  try {
    const data = await authApi.register({
      username: form.value.username,
      email: form.value.email,
      password: form.value.password,
    })
    userStore.login(data)
    message.success('注册成功，欢迎加入！')
    router.push('/')
  } catch (err: any) {
    message.error(err.message || '注册失败')
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.auth-page {
  min-height: 100vh;
  background: #F5F5F0;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
}

.auth-container {
  display: flex;
  width: 920px;
  max-width: 100%;
  min-height: 620px;
  background: #fff;
  border-radius: 20px;
  overflow: hidden;
  box-shadow:
    0 1px 3px rgba(0, 0, 0, 0.04),
    0 8px 40px rgba(0, 0, 0, 0.06);
}

/* ─── Left Panel ─── */
.auth-left {
  flex: 1;
  background: linear-gradient(145deg, #2d2d3f 0%, #1a1a2e 60%, #0f3460 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 48px 40px;
  position: relative;
  overflow: hidden;
}

.auth-left::before {
  content: '';
  position: absolute;
  top: -40%;
  right: -25%;
  width: 280px;
  height: 280px;
  background: radial-gradient(circle, rgba(255, 255, 255, 0.03) 0%, transparent 70%);
  border-radius: 50%;
}

.left-content {
  position: relative;
  z-index: 1;
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.left-top {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.brand-icon {
  width: 48px;
  height: 48px;
  background: rgba(255, 255, 255, 0.08);
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #fff;
  margin-bottom: 20px;
  border: 1px solid rgba(255, 255, 255, 0.06);
}

.brand-name {
  font-size: 22px;
  font-weight: 700;
  color: #fff;
  margin-bottom: 6px;
  letter-spacing: 0.02em;
}

.brand-tagline {
  font-size: 14px;
  color: rgba(255, 255, 255, 0.45);
  line-height: 1.5;
}

/* Feature List */
.left-middle {
  padding: 20px 0;
}

.feature-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.feature-item {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 14px 16px;
  background: rgba(255, 255, 255, 0.04);
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.04);
  transition: all 0.2s ease;
}

.feature-item:hover {
  background: rgba(255, 255, 255, 0.08);
}

.feature-icon-circle {
  width: 36px;
  height: 36px;
  border-radius: 10px;
  background: rgba(255, 255, 255, 0.08);
  display: flex;
  align-items: center;
  justify-content: center;
  color: rgba(255, 255, 255, 0.7);
  flex-shrink: 0;
}

.feature-text {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.feature-title {
  font-size: 13px;
  font-weight: 600;
  color: rgba(255, 255, 255, 0.85);
}

.feature-desc {
  font-size: 12px;
  color: rgba(255, 255, 255, 0.35);
}

.left-footer {
  font-size: 11px;
  color: rgba(255, 255, 255, 0.2);
}

/* ─── Right Panel ─── */
.auth-right {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 48px;
  background: #fff;
}

.form-wrapper {
  width: 100%;
  max-width: 340px;
}

.form-header {
  margin-bottom: 32px;
}

.form-title {
  font-size: 26px;
  font-weight: 700;
  color: #1a1a2e;
  margin-bottom: 8px;
  letter-spacing: -0.02em;
}

.form-subtitle {
  font-size: 14px;
  color: #999;
}

.link {
  color: #1a1a2e;
  font-weight: 600;
  cursor: pointer;
  text-decoration: underline;
  text-underline-offset: 2px;
  transition: color 0.2s;
}

.link:hover {
  color: #0f3460;
}

.register-btn {
  margin-top: 8px;
  height: 44px;
  font-size: 15px;
  font-weight: 600;
  border-radius: 10px;
}

/* ─── Responsive ─── */
@media (max-width: 640px) {
  .auth-left { display: none; }
  .auth-right { padding: 32px 24px; }
  .auth-container { border-radius: 16px; }
}
</style>
