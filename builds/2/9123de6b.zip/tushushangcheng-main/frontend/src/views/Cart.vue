<template>
  <div class="cart-page">
    <h2 class="page-title">
      <n-icon :component="CartOutline" size="24" />
      购物车
    </h2>

    <n-spin :show="loading">
      <template v-if="cartData.items && cartData.items.length > 0">
        <n-grid :cols="3" :x-gap="20">
          <!-- Cart Items -->
          <n-grid-item :span="2">
            <n-card>
              <!-- Header -->
              <div class="cart-header">
                <n-checkbox
                  :checked="isAllSelected"
                  :indeterminate="isSomeSelected && !isAllSelected"
                  @update:checked="toggleSelectAll"
                >
                  全选
                </n-checkbox>
                <span class="header-book">商品信息</span>
                <span class="header-price">单价</span>
                <span class="header-qty">数量</span>
                <span class="header-sub">小计</span>
                <span class="header-action">操作</span>
              </div>

              <n-divider style="margin:8px 0" />

              <!-- Items -->
              <div v-for="item in cartData.items" :key="item.id" class="cart-item">
                <n-checkbox
                  :checked="selectedIds.includes(item.id)"
                  @update:checked="v => toggleSelect(item.id, v)"
                />
                <div class="item-book" @click="router.push(`/books/${item.book_id}`)">
                  <img
                    :src="item.cover || defaultCover"
                    :alt="item.title"
                    class="item-cover"
                    @error="e => ((e.target as HTMLImageElement).src = defaultCover)"
                  />
                  <div class="item-info">
                    <p class="item-title">{{ item.title }}</p>
                    <p class="item-author">{{ item.author }}</p>
                  </div>
                </div>
                <span class="item-price">¥{{ item.price.toFixed(2) }}</span>
                <n-input-number
                  :value="item.quantity"
                  :min="1"
                  :max="item.stock || 99"
                  class="item-qty"
                  @update:value="v => updateQuantity(item.id, v)"
                />
                <span class="item-sub">¥{{ (item.price * item.quantity).toFixed(2) }}</span>
                <n-button
                  text
                  type="error"
                  size="small"
                  @click="removeItem(item.id)"
                >
                  <template #icon><n-icon :component="TrashOutline" /></template>
                </n-button>
              </div>
            </n-card>
          </n-grid-item>

          <!-- Order Summary -->
          <n-grid-item :span="1">
            <n-card class="summary-card" title="结算明细">
              <div class="summary-row">
                <span>已选商品</span>
                <span>{{ selectedCount }} 件</span>
              </div>
              <div class="summary-row">
                <span>商品总价</span>
                <span>¥{{ selectedTotal.toFixed(2) }}</span>
              </div>
              <n-divider />
              <div class="summary-total">
                <span>应付金额</span>
                <span class="total-price">¥{{ selectedTotal.toFixed(2) }}</span>
              </div>
              <n-button
                block
                size="large"
                type="primary"
                :disabled="selectedCount === 0"
                style="margin-top:16px"
                @click="goCheckout"
              >
                结算 ({{ selectedCount }})
              </n-button>
            </n-card>
          </n-grid-item>
        </n-grid>
      </template>

      <div v-else-if="!loading" class="empty-cart">
        <n-empty size="huge" description="购物车还是空的">
          <template #extra>
            <n-button type="primary" @click="router.push('/books')">去逛逛</n-button>
          </template>
        </n-empty>
      </div>
    </n-spin>

    <!-- Checkout Modal -->
    <n-modal v-model:show="showCheckout" title="确认订单" preset="card" style="width:560px">
      <div>
        <h4 style="margin-bottom:12px">选择收货地址</h4>
        <n-radio-group v-model:value="selectedAddressId">
          <div v-for="addr in addresses" :key="addr.id" class="address-option">
            <n-radio :value="addr.id">
              <span class="addr-name">{{ addr.name }} {{ addr.phone }}</span>
              <span class="addr-detail">{{ addr.province }} {{ addr.city }} {{ addr.district }} {{ addr.address }}</span>
            </n-radio>
          </div>
        </n-radio-group>
        <n-empty v-if="addresses.length === 0" description="请先添加收货地址" />

        <n-divider />
        <div class="checkout-summary">
          <span>合计：</span>
          <span class="checkout-price">¥{{ selectedTotal.toFixed(2) }}</span>
        </div>
      </div>
      <template #action>
        <n-space justify="end">
          <n-button @click="showCheckout = false">取消</n-button>
          <n-button
            type="primary"
            :loading="ordering"
            :disabled="!selectedAddressId"
            @click="submitOrder"
          >
            提交订单
          </n-button>
        </n-space>
      </template>
    </n-modal>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import {
  NSpin, NCard, NGrid, NGridItem, NCheckbox, NDivider,
  NButton, NInputNumber, NIcon, NEmpty, NModal, NRadioGroup,
  NRadio, NSpace, useMessage, useDialog,
} from 'naive-ui'
import { CartOutline, TrashOutline } from '@vicons/ionicons5'
import { useCartStore } from '@/stores/cart'
import { userApi, type Address } from '@/api/user'
import { orderApi } from '@/api/order'

const router = useRouter()
const cartStore = useCartStore()
const message = useMessage()
const dialog = useDialog()

const loading = ref(false)
const selectedIds = ref<number[]>([])
const showCheckout = ref(false)
const addresses = ref<Address[]>([])
const selectedAddressId = ref<number | null>(null)
const ordering = ref(false)
const defaultCover = 'https://via.placeholder.com/80x100/6366f1/ffffff?text=📚'

const cartData = computed(() => cartStore.cartData)

const isAllSelected = computed(() =>
  cartData.value.items.length > 0 &&
  cartData.value.items.every(item => selectedIds.value.includes(item.id)),
)

const isSomeSelected = computed(() =>
  cartData.value.items.some(item => selectedIds.value.includes(item.id)),
)

const selectedItems = computed(() =>
  cartData.value.items.filter(item => selectedIds.value.includes(item.id)),
)

const selectedCount = computed(() =>
  selectedItems.value.reduce((sum, item) => sum + item.quantity, 0),
)

const selectedTotal = computed(() =>
  selectedItems.value.reduce((sum, item) => sum + item.price * item.quantity, 0),
)

function toggleSelectAll(checked: boolean) {
  selectedIds.value = checked ? cartData.value.items.map(i => i.id) : []
}

function toggleSelect(id: number, checked: boolean) {
  if (checked) {
    selectedIds.value.push(id)
  } else {
    selectedIds.value = selectedIds.value.filter(i => i !== id)
  }
}

async function updateQuantity(id: number, qty: number | null) {
  if (!qty) return
  try {
    await cartStore.updateQuantity(id, qty)
  } catch (err: any) {
    message.error(err.message)
  }
}

function removeItem(id: number) {
  dialog.warning({
    title: '确认删除',
    content: '确定要从购物车移除此商品吗？',
    positiveText: '删除',
    negativeText: '取消',
    onPositiveClick: async () => {
      try {
        await cartStore.removeItem(id)
        selectedIds.value = selectedIds.value.filter(i => i !== id)
        message.success('已删除')
      } catch (err: any) {
        message.error(err.message)
      }
    },
  })
}

async function goCheckout() {
  if (selectedIds.value.length === 0) {
    message.warning('请选择要结算的商品')
    return
  }
  try {
    addresses.value = await userApi.getAddresses()
    const defaultAddr = addresses.value.find(a => a.is_default === 1)
    selectedAddressId.value = defaultAddr?.id || addresses.value[0]?.id || null
  } catch {}
  showCheckout.value = true
}

async function submitOrder() {
  if (!selectedAddressId.value) {
    message.warning('请选择收货地址')
    return
  }
  ordering.value = true
  try {
    const order = await orderApi.createOrder({
      address_id: selectedAddressId.value,
      cart_ids: selectedIds.value,
    })
    showCheckout.value = false
    message.success('订单创建成功')
    router.push(`/orders/${order.id}`)
  } catch (err: any) {
    message.error(err.message || '创建订单失败')
  } finally {
    ordering.value = false
  }
}

onMounted(async () => {
  loading.value = true
  await cartStore.fetchCart()
  selectedIds.value = cartStore.cartData.items.map(i => i.id)
  loading.value = false
})
</script>

<style scoped>
.cart-page { padding-bottom: 40px; }

.page-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 22px;
  font-weight: 700;
  color: #1A1A1A;
  margin-bottom: 20px;
}

.cart-header {
  display: grid;
  grid-template-columns: 32px 1fr 100px 120px 100px 60px;
  align-items: center;
  gap: 16px;
  color: #9B9B9B;
  font-size: 13px;
  padding: 8px 0;
}

.cart-item {
  display: grid;
  grid-template-columns: 32px 1fr 100px 120px 100px 60px;
  align-items: center;
  gap: 16px;
  padding: 16px 0;
  border-bottom: 1px solid #f1f5f9;
}

.cart-item:last-child { border-bottom: none; }

.item-book {
  display: flex;
  align-items: center;
  gap: 12px;
  cursor: pointer;
}

.item-cover {
  width: 64px;
  height: 80px;
  object-fit: cover;
  border-radius: 6px;
  flex-shrink: 0;
}

.item-title {
  font-size: 14px;
  font-weight: 500;
  color: #1A1A1A;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}

.item-author {
  font-size: 12px;
  color: #9B9B9B;
  margin-top: 4px;
}

.item-price { color: #ef4444; font-weight: 600; }
.item-sub { color: #ef4444; font-weight: 700; font-size: 16px; }

.summary-card { position: sticky; top: 100px; }

.summary-row {
  display: flex;
  justify-content: space-between;
  font-size: 14px;
  color: #6B6B6B;
  margin-bottom: 10px;
}

.summary-total {
  display: flex;
  justify-content: space-between;
  font-size: 16px;
  font-weight: 600;
  color: #1A1A1A;
}

.total-price {
  font-size: 22px;
  color: #ef4444;
  font-weight: 800;
}

.empty-cart {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
}

.address-option {
  padding: 12px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  margin-bottom: 8px;
}

.addr-name {
  font-weight: 600;
  margin-right: 8px;
}

.addr-detail {
  font-size: 13px;
  color: #6B6B6B;
}

.checkout-summary {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 8px;
  font-size: 16px;
}

.checkout-price {
  font-size: 24px;
  font-weight: 800;
  color: #ef4444;
}
</style>
