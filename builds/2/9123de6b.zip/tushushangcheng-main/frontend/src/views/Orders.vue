<template>
  <div class="orders-page">
    <h2 class="page-title">
      <n-icon :component="ReceiptOutline" size="24" />
      我的订单
    </h2>

    <!-- Status Tabs -->
    <n-tabs v-model:value="statusTab" @update:value="handleTabChange">
      <n-tab name="-1">全部</n-tab>
      <n-tab name="0">待支付</n-tab>
      <n-tab name="1">已支付</n-tab>
      <n-tab name="2">已发货</n-tab>
      <n-tab name="3">已完成</n-tab>
      <n-tab name="4">已取消</n-tab>
    </n-tabs>

    <n-spin :show="loading">
      <div v-if="orders.length > 0" class="order-list">
        <n-card
          v-for="order in orders"
          :key="order.id"
          class="order-card"
        >
          <!-- Order Header -->
          <div class="order-header">
            <div class="order-meta">
              <span class="order-no">订单号：{{ order.order_no }}</span>
              <span class="order-date">{{ formatDate(order.created_at) }}</span>
            </div>
            <n-tag :type="getStatusType(order.status)" round size="medium">
              {{ getStatusText(order.status) }}
            </n-tag>
          </div>

          <n-divider style="margin: 12px 0" />

          <!-- Items -->
          <div class="order-items">
            <div
              v-for="item in order.items"
              :key="item.id"
              class="order-item"
            >
              <img
                :src="item.cover || defaultCover"
                :alt="item.title"
                class="item-cover"
                @error="e => ((e.target as HTMLImageElement).src = defaultCover)"
              />
              <div class="item-info">
                <p class="item-title">{{ item.title }}</p>
                <p class="item-sub">{{ item.author }} × {{ item.quantity }}</p>
              </div>
              <span class="item-price">¥{{ item.subtotal.toFixed(2) }}</span>
            </div>
          </div>

          <n-divider style="margin: 12px 0" />

          <!-- Footer -->
          <div class="order-footer">
            <div class="order-total">
              共 {{ totalItemCount(order) }} 件商品，
              实付：<strong class="price">¥{{ order.actual_price.toFixed(2) }}</strong>
            </div>
            <n-space>
              <n-button size="small" @click="router.push(`/orders/${order.id}`)">
                订单详情
              </n-button>
              <n-button
                v-if="order.status === 0"
                size="small"
                type="primary"
                @click="payOrder(order)"
              >
                立即支付
              </n-button>
              <n-button
                v-if="order.status === 0"
                size="small"
                type="error"
                ghost
                @click="cancelOrder(order)"
              >
                取消订单
              </n-button>
            </n-space>
          </div>
        </n-card>
      </div>

      <n-empty v-else-if="!loading" description="暂无订单" size="large">
        <template #extra>
          <n-button type="primary" @click="router.push('/books')">去购书</n-button>
        </template>
      </n-empty>
    </n-spin>

    <!-- Pagination -->
    <div v-if="total > 0" class="pagination">
      <n-pagination
        v-model:page="page"
        :page-count="Math.ceil(total / pageSize)"
        @update:page="fetchOrders"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import {
  NSpin, NCard, NTabs, NTab, NTag, NDivider,
  NButton, NSpace, NEmpty, NPagination, NIcon, useMessage, useDialog,
} from 'naive-ui'
import { ReceiptOutline } from '@vicons/ionicons5'
import { orderApi, ORDER_STATUS_MAP, ORDER_STATUS_TYPE, type Order } from '@/api/order'
import dayjs from 'dayjs'

const router = useRouter()
const message = useMessage()
const dialog = useDialog()

const orders = ref<Order[]>([])
const loading = ref(false)
const total = ref(0)
const page = ref(1)
const pageSize = ref(10)
const statusTab = ref('-1')
const defaultCover = 'https://via.placeholder.com/64x80/6366f1/ffffff?text=📚'

function getStatusText(status: number) {
  return ORDER_STATUS_MAP[status] || '未知'
}

function getStatusType(status: number): any {
  return ORDER_STATUS_TYPE[status] || 'default'
}

function formatDate(date: string) {
  return dayjs(date).format('YYYY-MM-DD HH:mm')
}

function totalItemCount(order: Order) {
  return order.items?.reduce((sum, item) => sum + item.quantity, 0) || 0
}

function handleTabChange(val: string) {
  statusTab.value = val
  page.value = 1
  fetchOrders()
}

async function fetchOrders() {
  loading.value = true
  try {
    const params: any = { page: page.value, page_size: pageSize.value }
    if (statusTab.value !== '-1') params.status = Number(statusTab.value)
    const result = await orderApi.getList(params)
    orders.value = result.list || []
    total.value = result.total
  } catch {
    orders.value = []
  } finally {
    loading.value = false
  }
}

function payOrder(order: Order) {
  dialog.info({
    title: '模拟支付',
    content: `确认支付 ¥${order.actual_price.toFixed(2)} ?`,
    positiveText: '确认支付',
    negativeText: '取消',
    onPositiveClick: async () => {
      try {
        await orderApi.payOrder(order.id, 'mock')
        message.success('支付成功')
        fetchOrders()
      } catch (err: any) {
        message.error(err.message)
      }
    },
  })
}

function cancelOrder(order: Order) {
  dialog.warning({
    title: '取消订单',
    content: '确定要取消此订单吗？',
    positiveText: '取消订单',
    negativeText: '再想想',
    onPositiveClick: async () => {
      try {
        await orderApi.cancelOrder(order.id)
        message.success('订单已取消')
        fetchOrders()
      } catch (err: any) {
        message.error(err.message)
      }
    },
  })
}

onMounted(fetchOrders)
</script>

<style scoped>
.orders-page { padding-bottom: 40px; }

.page-title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 22px;
  font-weight: 700;
  color: #1A1A1A;
  margin-bottom: 20px;
}

.order-list { margin-top: 20px; display: flex; flex-direction: column; gap: 16px; }

.order-card { transition: box-shadow 0.2s; }
.order-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,0.1); }

.order-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.order-meta { display: flex; align-items: center; gap: 16px; }

.order-no { font-size: 14px; font-weight: 600; color: #1A1A1A; }
.order-date { font-size: 13px; color: #9B9B9B; }

.order-items { display: flex; flex-direction: column; gap: 10px; }

.order-item {
  display: flex;
  align-items: center;
  gap: 12px;
}

.item-cover {
  width: 56px;
  height: 70px;
  object-fit: cover;
  border-radius: 6px;
  flex-shrink: 0;
}

.item-info { flex: 1; }

.item-title {
  font-size: 14px;
  font-weight: 500;
  color: #1A1A1A;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.item-sub { font-size: 12px; color: #9B9B9B; margin-top: 4px; }
.item-price { font-size: 14px; font-weight: 600; color: #6B6B6B; flex-shrink: 0; }

.order-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.order-total { font-size: 14px; color: #6B6B6B; }

.price {
  font-size: 18px;
  color: #ef4444;
  font-weight: 700;
}

.pagination {
  display: flex;
  justify-content: center;
  margin-top: 24px;
}
</style>
