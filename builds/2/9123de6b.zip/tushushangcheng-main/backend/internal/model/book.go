package model

import (
	"time"

	"gorm.io/gorm"
)

// BookCategory 图书分类
type BookCategory struct {
	ID          uint           `gorm:"primarykey" json:"id"`
	Name        string         `gorm:"size:50;not null" json:"name"`
	Icon        string         `gorm:"size:100" json:"icon"`
	SortOrder   int            `gorm:"default:0" json:"sort_order"`
	ParentID    uint           `gorm:"default:0" json:"parent_id"`
	Description string         `gorm:"size:200" json:"description"`
	CreatedAt   time.Time      `json:"created_at"`
	UpdatedAt   time.Time      `json:"updated_at"`
	DeletedAt   gorm.DeletedAt `gorm:"index" json:"-"`
}

func (BookCategory) TableName() string { return "book_category" }

// Book 图书模型
type Book struct {
	ID            uint           `gorm:"primarykey" json:"id"`
	Title         string         `gorm:"size:200;not null" json:"title"`
	Author        string         `gorm:"size:100;not null" json:"author"`
	Publisher     string         `gorm:"size:100" json:"publisher"`
	ISBN          string         `gorm:"size:20" json:"isbn"`
	CategoryID    uint           `gorm:"index;not null" json:"category_id"`
	Category      *BookCategory  `gorm:"foreignKey:CategoryID" json:"category,omitempty"`
	Price         float64        `gorm:"type:decimal(10,2);not null" json:"price"`
	OriginalPrice float64        `gorm:"type:decimal(10,2);default:0" json:"original_price"`
	Cover         string         `gorm:"size:500" json:"cover"`
	Description   string         `gorm:"type:text" json:"description"`
	Tags          string         `gorm:"size:200" json:"tags"`
	Status        int8           `gorm:"default:1" json:"status"` // 1上架 0下架
	IsRecommend   int8           `gorm:"default:0" json:"is_recommend"`
	IsHot         int8           `gorm:"default:0" json:"is_hot"`
	Sales         int            `gorm:"default:0" json:"sales"`
	Rating        float64        `gorm:"type:decimal(3,1);default:5.0" json:"rating"`
	PublishDate   *time.Time     `json:"publish_date"`
	Inventory     *BookInventory `gorm:"foreignKey:BookID" json:"inventory,omitempty"`
	CreatedAt     time.Time      `json:"created_at"`
	UpdatedAt     time.Time      `json:"updated_at"`
	DeletedAt     gorm.DeletedAt `gorm:"index" json:"-"`
}

func (Book) TableName() string { return "books" }

// BookInventory 图书库存
type BookInventory struct {
	ID        uint      `gorm:"primarykey" json:"id"`
	BookID    uint      `gorm:"uniqueIndex;not null" json:"book_id"`
	Stock     int       `gorm:"not null;default:0" json:"stock"`
	Locked    int       `gorm:"not null;default:0" json:"locked"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

func (BookInventory) TableName() string { return "book_inventory" }

// BookListReq 图书列表请求
type BookListReq struct {
	Page        int    `form:"page" json:"page"`
	PageSize    int    `form:"page_size" json:"page_size"`
	CategoryID  uint   `form:"category_id" json:"category_id"`
	Keyword     string `form:"keyword" json:"keyword"`
	IsRecommend int8   `form:"is_recommend" json:"is_recommend"`
	IsHot       int8   `form:"is_hot" json:"is_hot"`
	SortBy      string `form:"sort_by" json:"sort_by"` // price_asc|price_desc|sales|rating|new
}

// CreateBookReq 创建图书请求
type CreateBookReq struct {
	Title         string  `json:"title" binding:"required"`
	Author        string  `json:"author" binding:"required"`
	Publisher     string  `json:"publisher"`
	ISBN          string  `json:"isbn"`
	CategoryID    uint    `json:"category_id" binding:"required"`
	Price         float64 `json:"price" binding:"required,gt=0"`
	OriginalPrice float64 `json:"original_price"`
	Cover         string  `json:"cover"`
	Description   string  `json:"description"`
	Tags          string  `json:"tags"`
	IsRecommend   int8    `json:"is_recommend"`
	IsHot         int8    `json:"is_hot"`
	Stock         int     `json:"stock"`
}

// UpdateBookReq 更新图书请求
type UpdateBookReq struct {
	Title         string  `json:"title"`
	Author        string  `json:"author"`
	Publisher     string  `json:"publisher"`
	ISBN          string  `json:"isbn"`
	CategoryID    uint    `json:"category_id"`
	Price         float64 `json:"price"`
	OriginalPrice float64 `json:"original_price"`
	Cover         string  `json:"cover"`
	Description   string  `json:"description"`
	Tags          string  `json:"tags"`
	Status        *int8   `json:"status"`
	IsRecommend   *int8   `json:"is_recommend"`
	IsHot         *int8   `json:"is_hot"`
	Stock         *int    `json:"stock"`
}
