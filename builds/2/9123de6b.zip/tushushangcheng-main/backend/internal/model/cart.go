package model

import "time"

// Cart 购物车
type Cart struct {
	ID        uint      `gorm:"primarykey" json:"id"`
	UserID    uint      `gorm:"uniqueIndex:uk_user_book;not null" json:"user_id"`
	BookID    uint      `gorm:"uniqueIndex:uk_user_book;not null" json:"book_id"`
	Quantity  int       `gorm:"not null;default:1" json:"quantity"`
	Book      *Book     `gorm:"foreignKey:BookID" json:"book,omitempty"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

func (Cart) TableName() string { return "cart" }

// AddCartReq 添加购物车请求
type AddCartReq struct {
	BookID   uint `json:"book_id" binding:"required"`
	Quantity int  `json:"quantity" binding:"required,min=1,max=99"`
}

// UpdateCartReq 更新购物车请求
type UpdateCartReq struct {
	Quantity int `json:"quantity" binding:"required,min=1,max=99"`
}

// CartItem 购物车条目(含汇总信息)
type CartItem struct {
	ID       uint    `json:"id"`
	BookID   uint    `json:"book_id"`
	Title    string  `json:"title"`
	Cover    string  `json:"cover"`
	Author   string  `json:"author"`
	Price    float64 `json:"price"`
	Quantity int     `json:"quantity"`
	Subtotal float64 `json:"subtotal"`
	Stock    int     `json:"stock"`
}

// CartSummary 购物车汇总
type CartSummary struct {
	Items      []CartItem `json:"items"`
	TotalCount int        `json:"total_count"`
	TotalPrice float64    `json:"total_price"`
}
