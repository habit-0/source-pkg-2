package model

import (
	"time"

	"gorm.io/gorm"
)

// Order 订单
type Order struct {
	ID            uint           `gorm:"primarykey" json:"id"`
	OrderNo       string         `gorm:"uniqueIndex;size:32;not null" json:"order_no"`
	UserID        uint           `gorm:"index;not null" json:"user_id"`
	TotalPrice    float64        `gorm:"type:decimal(10,2);not null" json:"total_price"`
	ActualPrice   float64        `gorm:"type:decimal(10,2);not null" json:"actual_price"`
	Status        int8           `gorm:"not null;default:0" json:"status"` // 0待支付 1已支付 2已发货 3已完成 4已取消
	AddressID     *uint          `json:"address_id"`
	ReceiverName  string         `gorm:"size:50" json:"receiver_name"`
	ReceiverPhone string         `gorm:"size:20" json:"receiver_phone"`
	ReceiverAddr  string         `gorm:"size:300" json:"receiver_addr"`
	Remark        string         `gorm:"size:200" json:"remark"`
	PaidAt        *time.Time     `json:"paid_at"`
	ShippedAt     *time.Time     `json:"shipped_at"`
	CompletedAt   *time.Time     `json:"completed_at"`
	Items         []OrderItem    `gorm:"foreignKey:OrderID" json:"items,omitempty"`
	CreatedAt     time.Time      `json:"created_at"`
	UpdatedAt     time.Time      `json:"updated_at"`
	DeletedAt     gorm.DeletedAt `gorm:"index" json:"-"`
}

func (Order) TableName() string { return "orders" }

// OrderStatusText maps status to text
var OrderStatusText = map[int8]string{
	0: "待支付",
	1: "已支付",
	2: "已发货",
	3: "已完成",
	4: "已取消",
}

// OrderItem 订单明细
type OrderItem struct {
	ID       uint    `gorm:"primarykey" json:"id"`
	OrderID  uint    `gorm:"index;not null" json:"order_id"`
	BookID   uint    `gorm:"index;not null" json:"book_id"`
	Title    string  `gorm:"size:200;not null" json:"title"`
	Cover    string  `gorm:"size:500" json:"cover"`
	Author   string  `gorm:"size:100" json:"author"`
	Price    float64 `gorm:"type:decimal(10,2);not null" json:"price"`
	Quantity int     `gorm:"not null" json:"quantity"`
	Subtotal float64 `gorm:"type:decimal(10,2);not null" json:"subtotal"`
	CreatedAt time.Time `json:"created_at"`
}

func (OrderItem) TableName() string { return "order_items" }

// CreateOrderReq 创建订单请求
type CreateOrderReq struct {
	AddressID uint   `json:"address_id" binding:"required"`
	CartIDs   []uint `json:"cart_ids" binding:"required,min=1"`
	Remark    string `json:"remark"`
}

// PayOrderReq 支付订单请求
type PayOrderReq struct {
	PayMethod string `json:"pay_method" binding:"required"` // alipay|wechat|mock
}

// OrderListReq 订单列表请求
type OrderListReq struct {
	Page     int  `form:"page"`
	PageSize int  `form:"page_size"`
	Status   *int8 `form:"status"`
}

// AdminOrderListReq 管理员订单列表
type AdminOrderListReq struct {
	Page     int    `form:"page"`
	PageSize int    `form:"page_size"`
	Status   *int8  `form:"status"`
	UserID   uint   `form:"user_id"`
	OrderNo  string `form:"order_no"`
}

// UpdateOrderStatusReq 更新订单状态
type UpdateOrderStatusReq struct {
	Status int8 `json:"status" binding:"required"`
}
