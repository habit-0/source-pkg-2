package model

import (
	"time"

	"gorm.io/gorm"
)

// AdminUser 管理员
type AdminUser struct {
	ID        uint           `gorm:"primarykey" json:"id"`
	Username  string         `gorm:"uniqueIndex;size:50;not null" json:"username"`
	Password  string         `gorm:"size:255;not null" json:"-"`
	Nickname  string         `gorm:"size:50" json:"nickname"`
	Email     string         `gorm:"size:100" json:"email"`
	Role      string         `gorm:"size:20;default:admin" json:"role"` // super_admin|admin
	Status    int8           `gorm:"default:1" json:"status"`
	LastLogin *time.Time     `json:"last_login"`
	CreatedAt time.Time      `json:"created_at"`
	UpdatedAt time.Time      `json:"updated_at"`
	DeletedAt gorm.DeletedAt `gorm:"index" json:"-"`
}

func (AdminUser) TableName() string { return "admin_users" }

// AdminLoginReq 管理员登录请求
type AdminLoginReq struct {
	Username string `json:"username" binding:"required"`
	Password string `json:"password" binding:"required"`
}

// AdminLoginResp 管理员登录响应
type AdminLoginResp struct {
	Token    string     `json:"token"`
	UserInfo *AdminUser `json:"user_info"`
}

// DashboardStats 仪表盘统计
type DashboardStats struct {
	TotalUsers    int64   `json:"total_users"`
	TotalBooks    int64   `json:"total_books"`
	TotalOrders   int64   `json:"total_orders"`
	TotalRevenue  float64 `json:"total_revenue"`
	TodayOrders   int64   `json:"today_orders"`
	TodayRevenue  float64 `json:"today_revenue"`
	PendingOrders int64   `json:"pending_orders"`
}

// SalesChart 销售统计
type SalesChart struct {
	Date    string  `json:"date"`
	Orders  int64   `json:"orders"`
	Revenue float64 `json:"revenue"`
}
