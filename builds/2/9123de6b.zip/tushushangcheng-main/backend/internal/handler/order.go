package handler

import (
	"strconv"

	"github.com/bookmall/backend/internal/middleware"
	"github.com/bookmall/backend/internal/model"
	"github.com/bookmall/backend/internal/service"
	"github.com/bookmall/backend/pkg/response"
	"github.com/gin-gonic/gin"
)

type OrderHandler struct {
	orderSvc *service.OrderService
}

func NewOrderHandler(orderSvc *service.OrderService) *OrderHandler {
	return &OrderHandler{orderSvc: orderSvc}
}

// CreateOrder POST /api/orders
func (h *OrderHandler) CreateOrder(c *gin.Context) {
	var req model.CreateOrderReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	userID := middleware.GetUserID(c)
	order, err := h.orderSvc.CreateOrder(userID, &req)
	if err != nil {
		response.Fail(c, response.CodeParamError, err.Error())
		return
	}
	response.Success(c, order)
}

// GetOrderList GET /api/orders
func (h *OrderHandler) GetOrderList(c *gin.Context) {
	var req model.OrderListReq
	if err := c.ShouldBindQuery(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	userID := middleware.GetUserID(c)
	orders, total, err := h.orderSvc.GetOrderList(userID, &req)
	if err != nil {
		response.ServerError(c, "获取订单列表失败")
		return
	}
	response.PageSuccess(c, orders, total, req.Page, req.PageSize)
}

// GetOrderDetail GET /api/orders/:id
func (h *OrderHandler) GetOrderDetail(c *gin.Context) {
	id, _ := strconv.ParseUint(c.Param("id"), 10, 64)
	userID := middleware.GetUserID(c)
	order, err := h.orderSvc.GetOrderDetail(userID, uint(id))
	if err != nil {
		response.NotFound(c, err.Error())
		return
	}
	response.Success(c, order)
}

// PayOrder POST /api/orders/:id/pay
func (h *OrderHandler) PayOrder(c *gin.Context) {
	id, _ := strconv.ParseUint(c.Param("id"), 10, 64)
	var req model.PayOrderReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	userID := middleware.GetUserID(c)
	if err := h.orderSvc.PayOrder(userID, uint(id), &req); err != nil {
		response.Fail(c, response.CodeParamError, err.Error())
		return
	}
	response.SuccessWithMsg(c, "支付成功", nil)
}

// CancelOrder POST /api/orders/:id/cancel
func (h *OrderHandler) CancelOrder(c *gin.Context) {
	id, _ := strconv.ParseUint(c.Param("id"), 10, 64)
	userID := middleware.GetUserID(c)
	if err := h.orderSvc.CancelOrder(userID, uint(id)); err != nil {
		response.Fail(c, response.CodeParamError, err.Error())
		return
	}
	response.SuccessWithMsg(c, "取消成功", nil)
}

// === Admin handlers ===

// AdminListOrders GET /api/admin/orders
func (h *OrderHandler) AdminListOrders(c *gin.Context) {
	var req model.AdminOrderListReq
	if err := c.ShouldBindQuery(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	orders, total, err := h.orderSvc.AdminListOrders(&req)
	if err != nil {
		response.ServerError(c, "获取订单列表失败")
		return
	}
	response.PageSuccess(c, orders, total, req.Page, req.PageSize)
}

// AdminUpdateOrderStatus PUT /api/admin/orders/:id/status
func (h *OrderHandler) AdminUpdateOrderStatus(c *gin.Context) {
	id, _ := strconv.ParseUint(c.Param("id"), 10, 64)
	var req model.UpdateOrderStatusReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	if err := h.orderSvc.AdminUpdateOrderStatus(uint(id), &req); err != nil {
		response.ServerError(c, err.Error())
		return
	}
	response.SuccessWithMsg(c, "更新成功", nil)
}
