package handler

import (
	"strconv"

	"github.com/bookmall/backend/internal/middleware"
	"github.com/bookmall/backend/internal/model"
	"github.com/bookmall/backend/internal/service"
	"github.com/bookmall/backend/pkg/response"
	"github.com/gin-gonic/gin"
)

type CartHandler struct {
	cartSvc *service.CartService
}

func NewCartHandler(cartSvc *service.CartService) *CartHandler {
	return &CartHandler{cartSvc: cartSvc}
}

// GetCart GET /api/cart
func (h *CartHandler) GetCart(c *gin.Context) {
	userID := middleware.GetUserID(c)
	summary, err := h.cartSvc.GetCart(userID)
	if err != nil {
		response.ServerError(c, "获取购物车失败")
		return
	}
	response.Success(c, summary)
}

// AddToCart POST /api/cart
func (h *CartHandler) AddToCart(c *gin.Context) {
	var req model.AddCartReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	userID := middleware.GetUserID(c)
	if err := h.cartSvc.AddToCart(userID, &req); err != nil {
		response.Fail(c, response.CodeStockNotEnough, err.Error())
		return
	}
	response.SuccessWithMsg(c, "添加成功", nil)
}

// UpdateCart PUT /api/cart/:id
func (h *CartHandler) UpdateCart(c *gin.Context) {
	id, _ := strconv.ParseUint(c.Param("id"), 10, 64)
	var req model.UpdateCartReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	userID := middleware.GetUserID(c)
	if err := h.cartSvc.UpdateQuantity(uint(id), userID, &req); err != nil {
		response.Fail(c, response.CodeParamError, err.Error())
		return
	}
	response.SuccessWithMsg(c, "更新成功", nil)
}

// DeleteCart DELETE /api/cart/:id
func (h *CartHandler) DeleteCart(c *gin.Context) {
	id, _ := strconv.ParseUint(c.Param("id"), 10, 64)
	userID := middleware.GetUserID(c)
	if err := h.cartSvc.DeleteCartItem(uint(id), userID); err != nil {
		response.ServerError(c, err.Error())
		return
	}
	response.SuccessWithMsg(c, "删除成功", nil)
}

// GetCartCount GET /api/cart/count
func (h *CartHandler) GetCartCount(c *gin.Context) {
	userID := middleware.GetUserID(c)
	count, err := h.cartSvc.GetCartCount(userID)
	if err != nil {
		response.ServerError(c, err.Error())
		return
	}
	response.Success(c, gin.H{"count": count})
}
