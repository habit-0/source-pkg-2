package handler

import (
	"strconv"

	"github.com/bookmall/backend/internal/middleware"
	"github.com/bookmall/backend/internal/model"
	"github.com/bookmall/backend/internal/service"
	"github.com/bookmall/backend/pkg/response"
	"github.com/gin-gonic/gin"
)

type UserHandler struct {
	userSvc *service.UserService
}

func NewUserHandler(userSvc *service.UserService) *UserHandler {
	return &UserHandler{userSvc: userSvc}
}

// Register POST /api/auth/register
func (h *UserHandler) Register(c *gin.Context) {
	var req model.RegisterReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}

	resp, err := h.userSvc.Register(&req)
	if err != nil {
		response.Fail(c, response.CodeParamError, err.Error())
		return
	}
	response.Success(c, resp)
}

// Login POST /api/auth/login
func (h *UserHandler) Login(c *gin.Context) {
	var req model.LoginReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}

	resp, err := h.userSvc.Login(&req)
	if err != nil {
		response.Fail(c, response.CodePassError, err.Error())
		return
	}
	response.Success(c, resp)
}

// GetProfile GET /api/user/profile
func (h *UserHandler) GetProfile(c *gin.Context) {
	userID := middleware.GetUserID(c)
	user, err := h.userSvc.GetProfile(userID)
	if err != nil {
		response.ServerError(c, "获取用户信息失败")
		return
	}
	response.Success(c, user)
}

// UpdateProfile PUT /api/user/profile
func (h *UserHandler) UpdateProfile(c *gin.Context) {
	var req model.UpdateProfileReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	userID := middleware.GetUserID(c)
	if err := h.userSvc.UpdateProfile(userID, &req); err != nil {
		response.ServerError(c, err.Error())
		return
	}
	response.SuccessWithMsg(c, "更新成功", nil)
}

// ChangePassword PUT /api/user/password
func (h *UserHandler) ChangePassword(c *gin.Context) {
	var req model.ChangePasswordReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	userID := middleware.GetUserID(c)
	if err := h.userSvc.ChangePassword(userID, &req); err != nil {
		response.Fail(c, response.CodePassError, err.Error())
		return
	}
	response.SuccessWithMsg(c, "密码修改成功", nil)
}

// GetAddresses GET /api/user/addresses
func (h *UserHandler) GetAddresses(c *gin.Context) {
	userID := middleware.GetUserID(c)
	addrs, err := h.userSvc.GetAddresses(userID)
	if err != nil {
		response.ServerError(c, err.Error())
		return
	}
	response.Success(c, addrs)
}

// CreateAddress POST /api/user/addresses
func (h *UserHandler) CreateAddress(c *gin.Context) {
	var req model.AddressReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	userID := middleware.GetUserID(c)
	addr, err := h.userSvc.CreateAddress(userID, &req)
	if err != nil {
		response.ServerError(c, err.Error())
		return
	}
	response.Success(c, addr)
}

// UpdateAddress PUT /api/user/addresses/:id
func (h *UserHandler) UpdateAddress(c *gin.Context) {
	id, _ := strconv.ParseUint(c.Param("id"), 10, 64)
	var req model.AddressReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	userID := middleware.GetUserID(c)
	if err := h.userSvc.UpdateAddress(uint(id), userID, &req); err != nil {
		response.ServerError(c, err.Error())
		return
	}
	response.SuccessWithMsg(c, "更新成功", nil)
}

// DeleteAddress DELETE /api/user/addresses/:id
func (h *UserHandler) DeleteAddress(c *gin.Context) {
	id, _ := strconv.ParseUint(c.Param("id"), 10, 64)
	userID := middleware.GetUserID(c)
	if err := h.userSvc.DeleteAddress(uint(id), userID); err != nil {
		response.ServerError(c, err.Error())
		return
	}
	response.SuccessWithMsg(c, "删除成功", nil)
}
