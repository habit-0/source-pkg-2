package handler

import (
	"strconv"

	"github.com/bookmall/backend/internal/model"
	"github.com/bookmall/backend/internal/service"
	"github.com/bookmall/backend/pkg/response"
	"github.com/gin-gonic/gin"
)

type BookHandler struct {
	bookSvc *service.BookService
}

func NewBookHandler(bookSvc *service.BookService) *BookHandler {
	return &BookHandler{bookSvc: bookSvc}
}

// GetCategories GET /api/categories
func (h *BookHandler) GetCategories(c *gin.Context) {
	cats, err := h.bookSvc.GetCategories()
	if err != nil {
		response.ServerError(c, "获取分类失败")
		return
	}
	response.Success(c, cats)
}

// ListBooks GET /api/books
func (h *BookHandler) ListBooks(c *gin.Context) {
	var req model.BookListReq
	if err := c.ShouldBindQuery(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}

	books, total, err := h.bookSvc.ListBooks(&req)
	if err != nil {
		response.ServerError(c, "获取图书列表失败")
		return
	}
	response.PageSuccess(c, books, total, req.Page, req.PageSize)
}

// GetBookDetail GET /api/books/:id
func (h *BookHandler) GetBookDetail(c *gin.Context) {
	id, _ := strconv.ParseUint(c.Param("id"), 10, 64)
	book, err := h.bookSvc.GetBookDetail(uint(id))
	if err != nil {
		response.NotFound(c, "图书不存在")
		return
	}
	response.Success(c, book)
}

// GetHotBooks GET /api/books/hot
func (h *BookHandler) GetHotBooks(c *gin.Context) {
	books, err := h.bookSvc.GetHotBooks()
	if err != nil {
		response.ServerError(c, "获取热门图书失败")
		return
	}
	response.Success(c, books)
}

// GetRecommendBooks GET /api/books/recommend
func (h *BookHandler) GetRecommendBooks(c *gin.Context) {
	books, err := h.bookSvc.GetRecommendBooks()
	if err != nil {
		response.ServerError(c, "获取推荐图书失败")
		return
	}
	response.Success(c, books)
}

// === Admin handlers ===

// AdminListBooks GET /api/admin/books
func (h *BookHandler) AdminListBooks(c *gin.Context) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("page_size", "20"))
	keyword := c.Query("keyword")
	categoryIDStr := c.Query("category_id")
	statusStr := c.Query("status")

	var categoryID uint
	if v, err := strconv.ParseUint(categoryIDStr, 10, 64); err == nil {
		categoryID = uint(v)
	}

	var status *int8
	if statusStr != "" {
		if v, err := strconv.ParseInt(statusStr, 10, 8); err == nil {
			s := int8(v)
			status = &s
		}
	}

	books, total, err := h.bookSvc.AdminListBooks(page, pageSize, keyword, categoryID, status)
	if err != nil {
		response.ServerError(c, "获取图书列表失败")
		return
	}
	response.PageSuccess(c, books, total, page, pageSize)
}

// AdminCreateBook POST /api/admin/books
func (h *BookHandler) AdminCreateBook(c *gin.Context) {
	var req model.CreateBookReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	book, err := h.bookSvc.CreateBook(&req)
	if err != nil {
		response.ServerError(c, err.Error())
		return
	}
	response.Success(c, book)
}

// AdminUpdateBook PUT /api/admin/books/:id
func (h *BookHandler) AdminUpdateBook(c *gin.Context) {
	id, _ := strconv.ParseUint(c.Param("id"), 10, 64)
	var req model.UpdateBookReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	if err := h.bookSvc.UpdateBook(uint(id), &req); err != nil {
		response.ServerError(c, err.Error())
		return
	}
	response.SuccessWithMsg(c, "更新成功", nil)
}

// AdminDeleteBook DELETE /api/admin/books/:id
func (h *BookHandler) AdminDeleteBook(c *gin.Context) {
	id, _ := strconv.ParseUint(c.Param("id"), 10, 64)
	if err := h.bookSvc.DeleteBook(uint(id)); err != nil {
		response.ServerError(c, err.Error())
		return
	}
	response.SuccessWithMsg(c, "删除成功", nil)
}

// AdminGetCategories GET /api/admin/categories
func (h *BookHandler) AdminGetCategories(c *gin.Context) {
	h.GetCategories(c)
}

// AdminCreateCategory POST /api/admin/categories
func (h *BookHandler) AdminCreateCategory(c *gin.Context) {
	var cat model.BookCategory
	if err := c.ShouldBindJSON(&cat); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	if err := h.bookSvc.CreateCategory(&cat); err != nil {
		response.ServerError(c, err.Error())
		return
	}
	response.Success(c, cat)
}

// AdminUpdateCategory PUT /api/admin/categories/:id
func (h *BookHandler) AdminUpdateCategory(c *gin.Context) {
	id, _ := strconv.ParseUint(c.Param("id"), 10, 64)
	var updates map[string]interface{}
	if err := c.ShouldBindJSON(&updates); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	if err := h.bookSvc.UpdateCategory(uint(id), updates); err != nil {
		response.ServerError(c, err.Error())
		return
	}
	response.SuccessWithMsg(c, "更新成功", nil)
}

// AdminDeleteCategory DELETE /api/admin/categories/:id
func (h *BookHandler) AdminDeleteCategory(c *gin.Context) {
	id, _ := strconv.ParseUint(c.Param("id"), 10, 64)
	if err := h.bookSvc.DeleteCategory(uint(id)); err != nil {
		response.ServerError(c, err.Error())
		return
	}
	response.SuccessWithMsg(c, "删除成功", nil)
}
