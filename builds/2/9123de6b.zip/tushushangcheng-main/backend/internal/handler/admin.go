package handler

import (
	"strconv"

	"github.com/bookmall/backend/internal/model"
	"github.com/bookmall/backend/internal/service"
	"github.com/bookmall/backend/pkg/response"
	"github.com/gin-gonic/gin"
)

type AdminHandler struct {
	adminSvc *service.AdminService
}

func NewAdminHandler(adminSvc *service.AdminService) *AdminHandler {
	return &AdminHandler{adminSvc: adminSvc}
}

// Login POST /api/admin/login
func (h *AdminHandler) Login(c *gin.Context) {
	var req model.AdminLoginReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	resp, err := h.adminSvc.Login(&req)
	if err != nil {
		response.Fail(c, response.CodePassError, err.Error())
		return
	}
	response.Success(c, resp)
}

// GetDashboard GET /api/admin/dashboard
func (h *AdminHandler) GetDashboard(c *gin.Context) {
	stats, err := h.adminSvc.GetDashboard()
	if err != nil {
		response.ServerError(c, "获取统计数据失败")
		return
	}
	response.Success(c, stats)
}

// GetSalesChart GET /api/admin/stats/sales
func (h *AdminHandler) GetSalesChart(c *gin.Context) {
	charts, err := h.adminSvc.GetSalesChart()
	if err != nil {
		response.ServerError(c, "获取销售图表失败")
		return
	}
	response.Success(c, charts)
}

// ListUsers GET /api/admin/users
func (h *AdminHandler) ListUsers(c *gin.Context) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("page_size", "20"))
	users, total, err := h.adminSvc.ListUsers(page, pageSize)
	if err != nil {
		response.ServerError(c, "获取用户列表失败")
		return
	}
	response.PageSuccess(c, users, total, page, pageSize)
}

// UpdateUserStatus PUT /api/admin/users/:id/status
func (h *AdminHandler) UpdateUserStatus(c *gin.Context) {
	id, _ := strconv.ParseUint(c.Param("id"), 10, 64)
	var req struct {
		Status int8 `json:"status"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		response.BadRequest(c, err.Error())
		return
	}
	if err := h.adminSvc.UpdateUserStatus(uint(id), req.Status); err != nil {
		response.ServerError(c, err.Error())
		return
	}
	response.SuccessWithMsg(c, "更新成功", nil)
}
