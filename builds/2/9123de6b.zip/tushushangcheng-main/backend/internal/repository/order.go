package repository

import (
	"github.com/bookmall/backend/internal/model"
	"gorm.io/gorm"
)

type OrderRepository struct {
	db *gorm.DB
}

func NewOrderRepository(db *gorm.DB) *OrderRepository {
	return &OrderRepository{db: db}
}

func (r *OrderRepository) Create(order *model.Order) error {
	return r.db.Create(order).Error
}

func (r *OrderRepository) GetByID(id uint) (*model.Order, error) {
	var order model.Order
	err := r.db.Preload("Items").First(&order, id).Error
	return &order, err
}

func (r *OrderRepository) GetByOrderNo(orderNo string) (*model.Order, error) {
	var order model.Order
	err := r.db.Where("order_no = ?", orderNo).Preload("Items").First(&order).Error
	return &order, err
}

func (r *OrderRepository) GetUserOrders(userID uint, req *model.OrderListReq) ([]model.Order, int64, error) {
	var orders []model.Order
	var total int64
	page := req.Page
	if page <= 0 { page = 1 }
	pageSize := req.PageSize
	if pageSize <= 0 { pageSize = 10 }
	offset := (page - 1) * pageSize

	query := r.db.Model(&model.Order{}).Where("user_id = ?", userID)
	if req.Status != nil {
		query = query.Where("status = ?", *req.Status)
	}

	query.Count(&total)
	err := query.Preload("Items").Order("id DESC").
		Offset(offset).Limit(pageSize).Find(&orders).Error
	return orders, total, err
}

func (r *OrderRepository) ListAdmin(req *model.AdminOrderListReq) ([]model.Order, int64, error) {
	var orders []model.Order
	var total int64
	page := req.Page
	if page <= 0 { page = 1 }
	pageSize := req.PageSize
	if pageSize <= 0 { pageSize = 20 }
	offset := (page - 1) * pageSize

	query := r.db.Model(&model.Order{})
	if req.Status != nil {
		query = query.Where("status = ?", *req.Status)
	}
	if req.UserID > 0 {
		query = query.Where("user_id = ?", req.UserID)
	}
	if req.OrderNo != "" {
		query = query.Where("order_no LIKE ?", "%"+req.OrderNo+"%")
	}

	query.Count(&total)
	err := query.Preload("Items").Order("id DESC").
		Offset(offset).Limit(pageSize).Find(&orders).Error
	return orders, total, err
}

func (r *OrderRepository) Update(id uint, updates map[string]interface{}) error {
	return r.db.Model(&model.Order{}).Where("id = ?", id).Updates(updates).Error
}

func (r *OrderRepository) Count() (int64, error) {
	var total int64
	err := r.db.Model(&model.Order{}).Count(&total).Error
	return total, err
}

func (r *OrderRepository) CountByStatus(status int8) (int64, error) {
	var total int64
	err := r.db.Model(&model.Order{}).Where("status = ?", status).Count(&total).Error
	return total, err
}

func (r *OrderRepository) TotalRevenue() (float64, error) {
	var total float64
	err := r.db.Model(&model.Order{}).
		Where("status IN ?", []int8{1, 2, 3}).
		Select("COALESCE(SUM(actual_price), 0)").Scan(&total).Error
	return total, err
}

func (r *OrderRepository) TodayStats() (int64, float64, error) {
	var count int64
	var revenue float64
	r.db.Model(&model.Order{}).
		Where("DATE(created_at) = CURDATE()").Count(&count)
	r.db.Model(&model.Order{}).
		Where("DATE(created_at) = CURDATE() AND status IN ?", []int8{1, 2, 3}).
		Select("COALESCE(SUM(actual_price), 0)").Scan(&revenue)
	return count, revenue, nil
}

func (r *OrderRepository) Last7DaysChart() ([]model.SalesChart, error) {
	var charts []model.SalesChart
	err := r.db.Model(&model.Order{}).
		Select("DATE(created_at) as date, COUNT(*) as orders, COALESCE(SUM(CASE WHEN status IN (1,2,3) THEN actual_price ELSE 0 END), 0) as revenue").
		Where("created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)").
		Group("DATE(created_at)").
		Order("date ASC").
		Scan(&charts).Error
	return charts, err
}
