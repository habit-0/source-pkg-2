package repository

import (
	"github.com/bookmall/backend/internal/model"
	"gorm.io/gorm"
)

type AdminRepository struct {
	db *gorm.DB
}

func NewAdminRepository(db *gorm.DB) *AdminRepository {
	return &AdminRepository{db: db}
}

func (r *AdminRepository) GetByUsername(username string) (*model.AdminUser, error) {
	var admin model.AdminUser
	err := r.db.Where("username = ?", username).First(&admin).Error
	return &admin, err
}

func (r *AdminRepository) GetByID(id uint) (*model.AdminUser, error) {
	var admin model.AdminUser
	err := r.db.First(&admin, id).Error
	return &admin, err
}

func (r *AdminRepository) UpdateLastLogin(id uint) error {
	return r.db.Model(&model.AdminUser{}).Where("id = ?", id).
		UpdateColumn("last_login", gorm.Expr("NOW()")).Error
}

// Add Count method to UserRepository
func (r *UserRepository) Count() (int64, error) {
	var total int64
	err := r.db.Model(&model.User{}).Count(&total).Error
	return total, err
}
