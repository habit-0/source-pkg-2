package repository

import (
	"github.com/bookmall/backend/internal/model"
	"gorm.io/gorm"
)

type UserRepository struct {
	db *gorm.DB
}

func NewUserRepository(db *gorm.DB) *UserRepository {
	return &UserRepository{db: db}
}

func (r *UserRepository) Create(user *model.User) error {
	return r.db.Create(user).Error
}

func (r *UserRepository) GetByID(id uint) (*model.User, error) {
	var user model.User
	err := r.db.First(&user, id).Error
	return &user, err
}

func (r *UserRepository) GetByUsername(username string) (*model.User, error) {
	var user model.User
	err := r.db.Where("username = ?", username).First(&user).Error
	return &user, err
}

func (r *UserRepository) GetByEmail(email string) (*model.User, error) {
	var user model.User
	err := r.db.Where("email = ?", email).First(&user).Error
	return &user, err
}

func (r *UserRepository) Update(id uint, updates map[string]interface{}) error {
	return r.db.Model(&model.User{}).Where("id = ?", id).Updates(updates).Error
}

func (r *UserRepository) List(page, pageSize int) ([]model.User, int64, error) {
	var users []model.User
	var total int64
	offset := (page - 1) * pageSize

	r.db.Model(&model.User{}).Count(&total)
	err := r.db.Offset(offset).Limit(pageSize).Order("id DESC").Find(&users).Error
	return users, total, err
}

// Address operations
func (r *UserRepository) CreateAddress(addr *model.UserAddress) error {
	return r.db.Create(addr).Error
}

func (r *UserRepository) GetAddressByID(id, userID uint) (*model.UserAddress, error) {
	var addr model.UserAddress
	err := r.db.Where("id = ? AND user_id = ?", id, userID).First(&addr).Error
	return &addr, err
}

func (r *UserRepository) GetUserAddresses(userID uint) ([]model.UserAddress, error) {
	var addrs []model.UserAddress
	err := r.db.Where("user_id = ?", userID).Order("is_default DESC, id DESC").Find(&addrs).Error
	return addrs, err
}

func (r *UserRepository) UpdateAddress(id, userID uint, updates map[string]interface{}) error {
	return r.db.Model(&model.UserAddress{}).Where("id = ? AND user_id = ?", id, userID).Updates(updates).Error
}

func (r *UserRepository) DeleteAddress(id, userID uint) error {
	return r.db.Where("id = ? AND user_id = ?", id, userID).Delete(&model.UserAddress{}).Error
}

func (r *UserRepository) ClearDefaultAddress(userID uint) error {
	return r.db.Model(&model.UserAddress{}).Where("user_id = ?", userID).Update("is_default", 0).Error
}
