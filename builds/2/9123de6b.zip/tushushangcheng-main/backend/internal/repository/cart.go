package repository

import (
	"github.com/bookmall/backend/internal/model"
	"gorm.io/gorm"
)

type CartRepository struct {
	db *gorm.DB
}

func NewCartRepository(db *gorm.DB) *CartRepository {
	return &CartRepository{db: db}
}

func (r *CartRepository) GetUserCart(userID uint) ([]model.Cart, error) {
	var items []model.Cart
	err := r.db.Where("user_id = ?", userID).
		Preload("Book").Preload("Book.Inventory").
		Order("id DESC").Find(&items).Error
	return items, err
}

func (r *CartRepository) GetCartItem(userID, bookID uint) (*model.Cart, error) {
	var item model.Cart
	err := r.db.Where("user_id = ? AND book_id = ?", userID, bookID).First(&item).Error
	return &item, err
}

func (r *CartRepository) GetCartItemByID(id, userID uint) (*model.Cart, error) {
	var item model.Cart
	err := r.db.Where("id = ? AND user_id = ?", id, userID).First(&item).Error
	return &item, err
}

func (r *CartRepository) GetCartItemsByIDs(userID uint, ids []uint) ([]model.Cart, error) {
	var items []model.Cart
	err := r.db.Where("user_id = ? AND id IN ?", userID, ids).
		Preload("Book").Preload("Book.Inventory").Find(&items).Error
	return items, err
}

func (r *CartRepository) Create(item *model.Cart) error {
	return r.db.Create(item).Error
}

func (r *CartRepository) UpdateQuantity(id, userID uint, quantity int) error {
	return r.db.Model(&model.Cart{}).
		Where("id = ? AND user_id = ?", id, userID).
		Update("quantity", quantity).Error
}

func (r *CartRepository) Delete(id, userID uint) error {
	return r.db.Where("id = ? AND user_id = ?", id, userID).Delete(&model.Cart{}).Error
}

func (r *CartRepository) DeleteByIDs(userID uint, ids []uint) error {
	return r.db.Where("user_id = ? AND id IN ?", userID, ids).Delete(&model.Cart{}).Error
}

func (r *CartRepository) CountByUser(userID uint) (int64, error) {
	var count int64
	err := r.db.Model(&model.Cart{}).Where("user_id = ?", userID).Count(&count).Error
	return count, err
}
