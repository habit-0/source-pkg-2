package repository

import (
	"github.com/bookmall/backend/internal/model"
	"gorm.io/gorm"
)

type BookRepository struct {
	db *gorm.DB
}

func NewBookRepository(db *gorm.DB) *BookRepository {
	return &BookRepository{db: db}
}

func (r *BookRepository) Create(book *model.Book) error {
	return r.db.Create(book).Error
}

func (r *BookRepository) GetByID(id uint) (*model.Book, error) {
	var book model.Book
	err := r.db.Preload("Category").Preload("Inventory").First(&book, id).Error
	return &book, err
}

func (r *BookRepository) Update(id uint, updates map[string]interface{}) error {
	return r.db.Model(&model.Book{}).Where("id = ?", id).Updates(updates).Error
}

func (r *BookRepository) Delete(id uint) error {
	return r.db.Delete(&model.Book{}, id).Error
}

func (r *BookRepository) List(req *model.BookListReq) ([]model.Book, int64, error) {
	var books []model.Book
	var total int64

	page := req.Page
	if page <= 0 {
		page = 1
	}
	pageSize := req.PageSize
	if pageSize <= 0 || pageSize > 100 {
		pageSize = 12
	}
	offset := (page - 1) * pageSize

	query := r.db.Model(&model.Book{}).Where("status = 1")

	if req.CategoryID > 0 {
		query = query.Where("category_id = ?", req.CategoryID)
	}
	if req.Keyword != "" {
		like := "%" + req.Keyword + "%"
		query = query.Where("title LIKE ? OR author LIKE ?", like, like)
	}
	if req.IsRecommend == 1 {
		query = query.Where("is_recommend = 1")
	}
	if req.IsHot == 1 {
		query = query.Where("is_hot = 1")
	}

	query.Count(&total)

	// Sort
	switch req.SortBy {
	case "price_asc":
		query = query.Order("price ASC")
	case "price_desc":
		query = query.Order("price DESC")
	case "sales":
		query = query.Order("sales DESC")
	case "rating":
		query = query.Order("rating DESC")
	case "new":
		query = query.Order("id DESC")
	default:
		query = query.Order("is_recommend DESC, sales DESC")
	}

	err := query.Preload("Category").Preload("Inventory").
		Offset(offset).Limit(pageSize).Find(&books).Error
	return books, total, err
}

func (r *BookRepository) ListAdmin(page, pageSize int, keyword string, categoryID uint, status *int8) ([]model.Book, int64, error) {
	var books []model.Book
	var total int64
	if page <= 0 { page = 1 }
	if pageSize <= 0 { pageSize = 20 }
	offset := (page - 1) * pageSize

	query := r.db.Model(&model.Book{})
	if keyword != "" {
		like := "%" + keyword + "%"
		query = query.Where("title LIKE ? OR author LIKE ?", like, like)
	}
	if categoryID > 0 {
		query = query.Where("category_id = ?", categoryID)
	}
	if status != nil {
		query = query.Where("status = ?", *status)
	}

	query.Count(&total)
	err := query.Preload("Category").Preload("Inventory").
		Offset(offset).Limit(pageSize).Order("id DESC").Find(&books).Error
	return books, total, err
}

func (r *BookRepository) GetHotBooks(limit int) ([]model.Book, error) {
	var books []model.Book
	err := r.db.Where("is_hot = 1 AND status = 1").
		Order("sales DESC").Limit(limit).
		Preload("Category").Find(&books).Error
	return books, err
}

func (r *BookRepository) GetRecommendBooks(limit int) ([]model.Book, error) {
	var books []model.Book
	err := r.db.Where("is_recommend = 1 AND status = 1").
		Order("rating DESC").Limit(limit).
		Preload("Category").Find(&books).Error
	return books, err
}

// Category operations
func (r *BookRepository) GetAllCategories() ([]model.BookCategory, error) {
	var cats []model.BookCategory
	err := r.db.Order("sort_order ASC, id ASC").Find(&cats).Error
	return cats, err
}

func (r *BookRepository) CreateCategory(cat *model.BookCategory) error {
	return r.db.Create(cat).Error
}

func (r *BookRepository) UpdateCategory(id uint, updates map[string]interface{}) error {
	return r.db.Model(&model.BookCategory{}).Where("id = ?", id).Updates(updates).Error
}

func (r *BookRepository) DeleteCategory(id uint) error {
	return r.db.Delete(&model.BookCategory{}, id).Error
}

// Inventory operations
func (r *BookRepository) CreateInventory(inv *model.BookInventory) error {
	return r.db.Create(inv).Error
}

func (r *BookRepository) GetInventory(bookID uint) (*model.BookInventory, error) {
	var inv model.BookInventory
	err := r.db.Where("book_id = ?", bookID).First(&inv).Error
	return &inv, err
}

func (r *BookRepository) DeductStock(bookID uint, qty int) error {
	return r.db.Model(&model.BookInventory{}).
		Where("book_id = ? AND stock >= ?", bookID, qty).
		UpdateColumn("stock", gorm.Expr("stock - ?", qty)).Error
}

func (r *BookRepository) IncreaseSales(bookID uint, qty int) error {
	return r.db.Model(&model.Book{}).
		Where("id = ?", bookID).
		UpdateColumn("sales", gorm.Expr("sales + ?", qty)).Error
}

func (r *BookRepository) Count() (int64, error) {
	var total int64
	err := r.db.Model(&model.Book{}).Count(&total).Error
	return total, err
}
