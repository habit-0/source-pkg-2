package router

import (
	"time"

	"github.com/bookmall/backend/internal/handler"
	"github.com/bookmall/backend/internal/middleware"
	"github.com/bookmall/backend/internal/repository"
	"github.com/bookmall/backend/internal/service"
	"github.com/bookmall/backend/config"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
)

// Setup initializes all routes and dependencies
func Setup(conf *config.Config, db *gorm.DB) *gin.Engine {
	gin.SetMode(conf.App.Mode)
	r := gin.New()

	// Global middleware
	r.Use(gin.Recovery())
	r.Use(middleware.Logger())
	r.Use(middleware.CORS())

	// Initialize repositories
	userRepo  := repository.NewUserRepository(db)
	bookRepo  := repository.NewBookRepository(db)
	cartRepo  := repository.NewCartRepository(db)
	orderRepo := repository.NewOrderRepository(db)
	adminRepo := repository.NewAdminRepository(db)

	// Initialize services
	userSvc  := service.NewUserService(userRepo, conf)
	bookSvc  := service.NewBookService(bookRepo)
	cartSvc  := service.NewCartService(cartRepo, bookRepo)
	orderSvc := service.NewOrderService(orderRepo, cartRepo, bookRepo, userRepo)
	adminSvc := service.NewAdminService(adminRepo, userRepo, bookRepo, orderRepo, conf)

	// Initialize handlers
	userH  := handler.NewUserHandler(userSvc)
	bookH  := handler.NewBookHandler(bookSvc)
	cartH  := handler.NewCartHandler(cartSvc)
	orderH := handler.NewOrderHandler(orderSvc)
	adminH := handler.NewAdminHandler(adminSvc)

	api := r.Group("/api")

	// ============================================================
	// Public routes
	// ============================================================
	auth := api.Group("/auth")
	auth.Use(middleware.RateLimit(10, time.Minute)) // 10 requests per minute
	{
		auth.POST("/register", userH.Register)
		auth.POST("/login", userH.Login)
	}

	// Books - public
	books := api.Group("/books")
	{
		books.GET("", bookH.ListBooks)
		books.GET("/hot", bookH.GetHotBooks)
		books.GET("/recommend", bookH.GetRecommendBooks)
		books.GET("/:id", bookH.GetBookDetail)
	}

	// Categories - public
	api.GET("/categories", bookH.GetCategories)

	// ============================================================
	// User authenticated routes
	// ============================================================
	user := api.Group("/user")
	user.Use(middleware.JWTAuth())
	{
		user.GET("/profile", userH.GetProfile)
		user.PUT("/profile", userH.UpdateProfile)
		user.PUT("/password", userH.ChangePassword)
		user.GET("/addresses", userH.GetAddresses)
		user.POST("/addresses", userH.CreateAddress)
		user.PUT("/addresses/:id", userH.UpdateAddress)
		user.DELETE("/addresses/:id", userH.DeleteAddress)
	}

	// Cart
	cart := api.Group("/cart")
	cart.Use(middleware.JWTAuth())
	{
		cart.GET("", cartH.GetCart)
		cart.GET("/count", cartH.GetCartCount)
		cart.POST("", cartH.AddToCart)
		cart.PUT("/:id", cartH.UpdateCart)
		cart.DELETE("/:id", cartH.DeleteCart)
	}

	// Orders
	orders := api.Group("/orders")
	orders.Use(middleware.JWTAuth())
	{
		orders.POST("", orderH.CreateOrder)
		orders.GET("", orderH.GetOrderList)
		orders.GET("/:id", orderH.GetOrderDetail)
		orders.POST("/:id/pay", orderH.PayOrder)
		orders.POST("/:id/cancel", orderH.CancelOrder)
	}

	// ============================================================
	// Admin routes
	// ============================================================
	admin := api.Group("/admin")
	{
		admin.POST("/login", adminH.Login)
	}

	adminAuth := api.Group("/admin")
	adminAuth.Use(middleware.AdminAuth())
	{
		adminAuth.GET("/dashboard", adminH.GetDashboard)
		adminAuth.GET("/stats/sales", adminH.GetSalesChart)

		// User management
		adminAuth.GET("/users", adminH.ListUsers)
		adminAuth.PUT("/users/:id/status", adminH.UpdateUserStatus)

		// Book management
		adminAuth.GET("/books", bookH.AdminListBooks)
		adminAuth.POST("/books", bookH.AdminCreateBook)
		adminAuth.PUT("/books/:id", bookH.AdminUpdateBook)
		adminAuth.DELETE("/books/:id", bookH.AdminDeleteBook)

		// Category management
		adminAuth.GET("/categories", bookH.AdminGetCategories)
		adminAuth.POST("/categories", bookH.AdminCreateCategory)
		adminAuth.PUT("/categories/:id", bookH.AdminUpdateCategory)
		adminAuth.DELETE("/categories/:id", bookH.AdminDeleteCategory)

		// Order management
		adminAuth.GET("/orders", orderH.AdminListOrders)
		adminAuth.PUT("/orders/:id/status", orderH.AdminUpdateOrderStatus)
	}

	// Health check
	r.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "ok", "version": conf.App.Version})
	})

	return r
}
