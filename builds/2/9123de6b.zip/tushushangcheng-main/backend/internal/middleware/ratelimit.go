package middleware

import (
	"context"
	"fmt"
	"time"

	rdb "github.com/bookmall/backend/pkg/redis"
	"github.com/bookmall/backend/pkg/response"
	"github.com/gin-gonic/gin"
)

// RateLimit 接口限流中间件
// limit: 每个时间窗口最大请求数, window: 时间窗口
func RateLimit(limit int64, window time.Duration) gin.HandlerFunc {
	return func(c *gin.Context) {
		ip := c.ClientIP()
		key := fmt.Sprintf("%s%s:%s", rdb.KeyRateLimit, c.FullPath(), ip)

		ctx := context.Background()

		count, err := rdb.Incr(ctx, key)
		if err != nil {
			c.Next()
			return
		}

		// 首次访问设置过期时间
		if count == 1 {
			_ = rdb.Expire(ctx, key, window)
		}

		if count > limit {
			response.Fail(c, 429, "请求太频繁，请稍后再试")
			c.Abort()
			return
		}

		c.Next()
	}
}
