package service

import (
	"errors"
	"fmt"

	"github.com/bookmall/backend/config"
	"github.com/bookmall/backend/internal/model"
	"github.com/bookmall/backend/internal/repository"
	"github.com/bookmall/backend/pkg/jwt"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
)

type AdminService struct {
	adminRepo *repository.AdminRepository
	userRepo  *repository.UserRepository
	bookRepo  *repository.BookRepository
	orderRepo *repository.OrderRepository
	conf      *config.Config
}

func NewAdminService(
	adminRepo *repository.AdminRepository,
	userRepo *repository.UserRepository,
	bookRepo *repository.BookRepository,
	orderRepo *repository.OrderRepository,
	conf *config.Config,
) *AdminService {
	return &AdminService{
		adminRepo: adminRepo,
		userRepo:  userRepo,
		bookRepo:  bookRepo,
		orderRepo: orderRepo,
		conf:      conf,
	}
}

func (s *AdminService) Login(req *model.AdminLoginReq) (*model.AdminLoginResp, error) {
	admin, err := s.adminRepo.GetByUsername(req.Username)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, fmt.Errorf("管理员不存在")
		}
		return nil, err
	}

	if admin.Status == 0 {
		return nil, fmt.Errorf("账号已被禁用")
	}

	if err := bcrypt.CompareHashAndPassword([]byte(admin.Password), []byte(req.Password)); err != nil {
		return nil, fmt.Errorf("密码错误")
	}

	token, err := jwt.GenerateToken(admin.ID, admin.Username, "admin", s.conf.App.JwtExpire)
	if err != nil {
		return nil, err
	}

	return &model.AdminLoginResp{Token: token, UserInfo: admin}, nil
}

func (s *AdminService) GetDashboard() (*model.DashboardStats, error) {
	totalUsers, _ := s.userRepo.Count()
	totalBooks, _ := s.bookRepo.Count()
	totalOrders, _ := s.orderRepo.Count()
	totalRevenue, _ := s.orderRepo.TotalRevenue()
	todayOrders, todayRevenue, _ := s.orderRepo.TodayStats()
	pendingOrders, _ := s.orderRepo.CountByStatus(0)

	return &model.DashboardStats{
		TotalUsers:    totalUsers,
		TotalBooks:    totalBooks,
		TotalOrders:   totalOrders,
		TotalRevenue:  totalRevenue,
		TodayOrders:   todayOrders,
		TodayRevenue:  todayRevenue,
		PendingOrders: pendingOrders,
	}, nil
}

func (s *AdminService) GetSalesChart() ([]model.SalesChart, error) {
	return s.orderRepo.Last7DaysChart()
}

func (s *AdminService) ListUsers(page, pageSize int) ([]model.User, int64, error) {
	return s.userRepo.List(page, pageSize)
}

func (s *AdminService) UpdateUserStatus(userID uint, status int8) error {
	return s.userRepo.Update(userID, map[string]interface{}{"status": status})
}
