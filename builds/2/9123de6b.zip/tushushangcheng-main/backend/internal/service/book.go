package service

import (
	"context"
	"encoding/json"
	"time"

	"github.com/bookmall/backend/internal/model"
	"github.com/bookmall/backend/internal/repository"
	rdb "github.com/bookmall/backend/pkg/redis"
)

type BookService struct {
	bookRepo *repository.BookRepository
}

func NewBookService(bookRepo *repository.BookRepository) *BookService {
	return &BookService{bookRepo: bookRepo}
}

func (s *BookService) GetCategories() ([]model.BookCategory, error) {
	ctx := context.Background()
	cacheKey := "book:categories"

	// Try cache
	if cached, err := rdb.Get(ctx, cacheKey); err == nil {
		var cats []model.BookCategory
		if json.Unmarshal([]byte(cached), &cats) == nil {
			return cats, nil
		}
	}

	cats, err := s.bookRepo.GetAllCategories()
	if err != nil {
		return nil, err
	}

	// Cache for 10 minutes
	if data, err := json.Marshal(cats); err == nil {
		_ = rdb.Set(ctx, cacheKey, data, 10*time.Minute)
	}
	return cats, nil
}

func (s *BookService) ListBooks(req *model.BookListReq) ([]model.Book, int64, error) {
	return s.bookRepo.List(req)
}

func (s *BookService) GetBookDetail(id uint) (*model.Book, error) {
	ctx := context.Background()
	cacheKey := rdb.KeyBookDetail + string(rune(id+'0'))

	// Cache hit
	if cached, err := rdb.Get(ctx, cacheKey); err == nil {
		var book model.Book
		if json.Unmarshal([]byte(cached), &book) == nil {
			return &book, nil
		}
	}

	book, err := s.bookRepo.GetByID(id)
	if err != nil {
		return nil, err
	}

	// Cache for 5 minutes
	if data, err := json.Marshal(book); err == nil {
		_ = rdb.Set(ctx, cacheKey, data, 5*time.Minute)
	}
	return book, nil
}

func (s *BookService) GetHotBooks() ([]model.Book, error) {
	ctx := context.Background()
	cacheKey := rdb.KeyBookHot

	if cached, err := rdb.Get(ctx, cacheKey); err == nil {
		var books []model.Book
		if json.Unmarshal([]byte(cached), &books) == nil {
			return books, nil
		}
	}

	books, err := s.bookRepo.GetHotBooks(20)
	if err != nil {
		return nil, err
	}

	if data, err := json.Marshal(books); err == nil {
		_ = rdb.Set(ctx, cacheKey, data, 10*time.Minute)
	}
	return books, nil
}

func (s *BookService) GetRecommendBooks() ([]model.Book, error) {
	ctx := context.Background()
	cacheKey := rdb.KeyBookRecommend

	if cached, err := rdb.Get(ctx, cacheKey); err == nil {
		var books []model.Book
		if json.Unmarshal([]byte(cached), &books) == nil {
			return books, nil
		}
	}

	books, err := s.bookRepo.GetRecommendBooks(12)
	if err != nil {
		return nil, err
	}

	if data, err := json.Marshal(books); err == nil {
		_ = rdb.Set(ctx, cacheKey, data, 10*time.Minute)
	}
	return books, nil
}

// Admin operations
func (s *BookService) AdminListBooks(page, pageSize int, keyword string, categoryID uint, status *int8) ([]model.Book, int64, error) {
	return s.bookRepo.ListAdmin(page, pageSize, keyword, categoryID, status)
}

func (s *BookService) CreateBook(req *model.CreateBookReq) (*model.Book, error) {
	book := &model.Book{
		Title:         req.Title,
		Author:        req.Author,
		Publisher:     req.Publisher,
		ISBN:          req.ISBN,
		CategoryID:    req.CategoryID,
		Price:         req.Price,
		OriginalPrice: req.OriginalPrice,
		Cover:         req.Cover,
		Description:   req.Description,
		Tags:          req.Tags,
		IsRecommend:   req.IsRecommend,
		IsHot:         req.IsHot,
		Status:        1,
	}
	if err := s.bookRepo.Create(book); err != nil {
		return nil, err
	}

	// Create inventory
	inv := &model.BookInventory{BookID: book.ID, Stock: req.Stock}
	if err := s.bookRepo.CreateInventory(inv); err != nil {
		return nil, err
	}

	s.clearBookCache()
	return book, nil
}

func (s *BookService) UpdateBook(id uint, req *model.UpdateBookReq) error {
	updates := map[string]interface{}{}
	if req.Title != "" { updates["title"] = req.Title }
	if req.Author != "" { updates["author"] = req.Author }
	if req.Publisher != "" { updates["publisher"] = req.Publisher }
	if req.ISBN != "" { updates["isbn"] = req.ISBN }
	if req.CategoryID > 0 { updates["category_id"] = req.CategoryID }
	if req.Price > 0 { updates["price"] = req.Price }
	if req.OriginalPrice >= 0 { updates["original_price"] = req.OriginalPrice }
	if req.Cover != "" { updates["cover"] = req.Cover }
	if req.Description != "" { updates["description"] = req.Description }
	if req.Tags != "" { updates["tags"] = req.Tags }
	if req.Status != nil { updates["status"] = *req.Status }
	if req.IsRecommend != nil { updates["is_recommend"] = *req.IsRecommend }
	if req.IsHot != nil { updates["is_hot"] = *req.IsHot }

	if err := s.bookRepo.Update(id, updates); err != nil {
		return err
	}

	// Update inventory if provided
	if req.Stock != nil {
		inv, err := s.bookRepo.GetInventory(id)
		if err == nil {
			_ = s.bookRepo.Update(inv.ID, map[string]interface{}{"stock": *req.Stock})
		}
	}

	s.clearBookCache()
	return nil
}

func (s *BookService) DeleteBook(id uint) error {
	s.clearBookCache()
	return s.bookRepo.Delete(id)
}

func (s *BookService) CreateCategory(req *model.BookCategory) error {
	err := s.bookRepo.CreateCategory(req)
	if err == nil {
		_ = rdb.Del(context.Background(), "book:categories")
	}
	return err
}

func (s *BookService) UpdateCategory(id uint, updates map[string]interface{}) error {
	err := s.bookRepo.UpdateCategory(id, updates)
	if err == nil {
		_ = rdb.Del(context.Background(), "book:categories")
	}
	return err
}

func (s *BookService) DeleteCategory(id uint) error {
	err := s.bookRepo.DeleteCategory(id)
	if err == nil {
		_ = rdb.Del(context.Background(), "book:categories")
	}
	return err
}

func (s *BookService) clearBookCache() {
	ctx := context.Background()
	_ = rdb.Del(ctx, rdb.KeyBookHot, rdb.KeyBookRecommend)
}
