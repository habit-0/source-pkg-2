package service

import (
	"errors"
	"fmt"

	"github.com/bookmall/backend/config"
	"github.com/bookmall/backend/internal/model"
	"github.com/bookmall/backend/internal/repository"
	"github.com/bookmall/backend/pkg/jwt"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
)

type UserService struct {
	userRepo *repository.UserRepository
	conf     *config.Config
}

func NewUserService(userRepo *repository.UserRepository, conf *config.Config) *UserService {
	return &UserService{userRepo: userRepo, conf: conf}
}

func (s *UserService) Register(req *model.RegisterReq) (*model.LoginResp, error) {
	// Check username exists
	if _, err := s.userRepo.GetByUsername(req.Username); err == nil {
		return nil, fmt.Errorf("用户名已被注册")
	}
	// Check email exists
	if _, err := s.userRepo.GetByEmail(req.Email); err == nil {
		return nil, fmt.Errorf("邮箱已被注册")
	}

	// Hash password
	hashedPwd, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
	if err != nil {
		return nil, err
	}

	nickname := req.Nickname
	if nickname == "" {
		nickname = req.Username
	}

	user := &model.User{
		Username: req.Username,
		Email:    req.Email,
		Password: string(hashedPwd),
		Nickname: nickname,
	}

	if err := s.userRepo.Create(user); err != nil {
		return nil, err
	}

	token, err := jwt.GenerateToken(user.ID, user.Username, "user", s.conf.App.JwtExpire)
	if err != nil {
		return nil, err
	}

	return &model.LoginResp{Token: token, UserInfo: user}, nil
}

func (s *UserService) Login(req *model.LoginReq) (*model.LoginResp, error) {
	user, err := s.userRepo.GetByUsername(req.Username)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, fmt.Errorf("用户不存在")
		}
		return nil, err
	}

	if user.Status == 0 {
		return nil, fmt.Errorf("账号已被禁用")
	}

	if err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(req.Password)); err != nil {
		return nil, fmt.Errorf("密码错误")
	}

	token, err := jwt.GenerateToken(user.ID, user.Username, "user", s.conf.App.JwtExpire)
	if err != nil {
		return nil, err
	}

	return &model.LoginResp{Token: token, UserInfo: user}, nil
}

func (s *UserService) GetProfile(userID uint) (*model.User, error) {
	return s.userRepo.GetByID(userID)
}

func (s *UserService) UpdateProfile(userID uint, req *model.UpdateProfileReq) error {
	updates := map[string]interface{}{}
	if req.Nickname != "" {
		updates["nickname"] = req.Nickname
	}
	if req.Avatar != "" {
		updates["avatar"] = req.Avatar
	}
	if req.Phone != "" {
		updates["phone"] = req.Phone
	}
	return s.userRepo.Update(userID, updates)
}

func (s *UserService) ChangePassword(userID uint, req *model.ChangePasswordReq) error {
	user, err := s.userRepo.GetByID(userID)
	if err != nil {
		return err
	}

	if err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(req.OldPassword)); err != nil {
		return fmt.Errorf("原密码错误")
	}

	hashedPwd, err := bcrypt.GenerateFromPassword([]byte(req.NewPassword), bcrypt.DefaultCost)
	if err != nil {
		return err
	}

	return s.userRepo.Update(userID, map[string]interface{}{"password": string(hashedPwd)})
}

// Address methods
func (s *UserService) GetAddresses(userID uint) ([]model.UserAddress, error) {
	return s.userRepo.GetUserAddresses(userID)
}

func (s *UserService) CreateAddress(userID uint, req *model.AddressReq) (*model.UserAddress, error) {
	if req.IsDefault == 1 {
		_ = s.userRepo.ClearDefaultAddress(userID)
	}
	addr := &model.UserAddress{
		UserID:    userID,
		Name:      req.Name,
		Phone:     req.Phone,
		Province:  req.Province,
		City:      req.City,
		District:  req.District,
		Address:   req.Address,
		IsDefault: req.IsDefault,
	}
	if err := s.userRepo.CreateAddress(addr); err != nil {
		return nil, err
	}
	return addr, nil
}

func (s *UserService) UpdateAddress(id, userID uint, req *model.AddressReq) error {
	if req.IsDefault == 1 {
		_ = s.userRepo.ClearDefaultAddress(userID)
	}
	return s.userRepo.UpdateAddress(id, userID, map[string]interface{}{
		"name":       req.Name,
		"phone":      req.Phone,
		"province":   req.Province,
		"city":       req.City,
		"district":   req.District,
		"address":    req.Address,
		"is_default": req.IsDefault,
	})
}

func (s *UserService) DeleteAddress(id, userID uint) error {
	return s.userRepo.DeleteAddress(id, userID)
}
