package service

import (
	"fmt"
	"time"

	"github.com/bookmall/backend/internal/model"
	"github.com/bookmall/backend/internal/repository"
	"github.com/google/uuid"
)

type OrderService struct {
	orderRepo *repository.OrderRepository
	cartRepo  *repository.CartRepository
	bookRepo  *repository.BookRepository
	userRepo  *repository.UserRepository
}

func NewOrderService(
	orderRepo *repository.OrderRepository,
	cartRepo *repository.CartRepository,
	bookRepo *repository.BookRepository,
	userRepo *repository.UserRepository,
) *OrderService {
	return &OrderService{
		orderRepo: orderRepo,
		cartRepo:  cartRepo,
		bookRepo:  bookRepo,
		userRepo:  userRepo,
	}
}

func (s *OrderService) CreateOrder(userID uint, req *model.CreateOrderReq) (*model.Order, error) {
	// Get address
	addr, err := s.userRepo.GetAddressByID(req.AddressID, userID)
	if err != nil {
		return nil, fmt.Errorf("收货地址不存在")
	}

	// Get cart items
	cartItems, err := s.cartRepo.GetCartItemsByIDs(userID, req.CartIDs)
	if err != nil || len(cartItems) == 0 {
		return nil, fmt.Errorf("购物车商品不存在")
	}

	// Build order items and calculate total
	var orderItems []model.OrderItem
	var totalPrice float64

	for _, ci := range cartItems {
		if ci.Book == nil {
			continue
		}
		// Check stock
		if ci.Book.Inventory == nil || ci.Book.Inventory.Stock < ci.Quantity {
			return nil, fmt.Errorf("《%s》库存不足", ci.Book.Title)
		}

		subtotal := ci.Book.Price * float64(ci.Quantity)
		totalPrice += subtotal

		orderItems = append(orderItems, model.OrderItem{
			BookID:   ci.BookID,
			Title:    ci.Book.Title,
			Cover:    ci.Book.Cover,
			Author:   ci.Book.Author,
			Price:    ci.Book.Price,
			Quantity: ci.Quantity,
			Subtotal: subtotal,
		})
	}

	if len(orderItems) == 0 {
		return nil, fmt.Errorf("订单商品为空")
	}

	// Generate order number
	orderNo := generateOrderNo()

	order := &model.Order{
		OrderNo:       orderNo,
		UserID:        userID,
		TotalPrice:    totalPrice,
		ActualPrice:   totalPrice,
		Status:        0,
		AddressID:     &req.AddressID,
		ReceiverName:  addr.Name,
		ReceiverPhone: addr.Phone,
		ReceiverAddr:  fmt.Sprintf("%s %s %s %s", addr.Province, addr.City, addr.District, addr.Address),
		Remark:        req.Remark,
		Items:         orderItems,
	}

	if err := s.orderRepo.Create(order); err != nil {
		return nil, err
	}

	// Deduct stock and increase sales
	for _, ci := range cartItems {
		_ = s.bookRepo.DeductStock(ci.BookID, ci.Quantity)
		_ = s.bookRepo.IncreaseSales(ci.BookID, ci.Quantity)
	}

	// Remove from cart
	_ = s.cartRepo.DeleteByIDs(userID, req.CartIDs)

	return order, nil
}

func (s *OrderService) PayOrder(userID uint, orderID uint, req *model.PayOrderReq) error {
	order, err := s.orderRepo.GetByID(orderID)
	if err != nil {
		return fmt.Errorf("订单不存在")
	}
	if order.UserID != userID {
		return fmt.Errorf("无权操作此订单")
	}
	if order.Status != 0 {
		return fmt.Errorf("订单状态异常，无法支付")
	}

	// Mock payment (in production, integrate with real payment gateway)
	now := time.Now()
	return s.orderRepo.Update(orderID, map[string]interface{}{
		"status":  1,
		"paid_at": now,
	})
}

func (s *OrderService) GetOrderList(userID uint, req *model.OrderListReq) ([]model.Order, int64, error) {
	return s.orderRepo.GetUserOrders(userID, req)
}

func (s *OrderService) GetOrderDetail(userID, orderID uint) (*model.Order, error) {
	order, err := s.orderRepo.GetByID(orderID)
	if err != nil {
		return nil, fmt.Errorf("订单不存在")
	}
	if order.UserID != userID {
		return nil, fmt.Errorf("无权查看此订单")
	}
	return order, nil
}

func (s *OrderService) CancelOrder(userID, orderID uint) error {
	order, err := s.orderRepo.GetByID(orderID)
	if err != nil {
		return fmt.Errorf("订单不存在")
	}
	if order.UserID != userID {
		return fmt.Errorf("无权操作此订单")
	}
	if order.Status != 0 {
		return fmt.Errorf("只有待支付的订单可以取消")
	}

	// Restore stock
	for _, item := range order.Items {
		s.bookRepo.DeductStock(item.BookID, -item.Quantity) // negative to restore
	}

	return s.orderRepo.Update(orderID, map[string]interface{}{"status": 4})
}

// Admin operations
func (s *OrderService) AdminListOrders(req *model.AdminOrderListReq) ([]model.Order, int64, error) {
	return s.orderRepo.ListAdmin(req)
}

func (s *OrderService) AdminUpdateOrderStatus(orderID uint, req *model.UpdateOrderStatusReq) error {
	updates := map[string]interface{}{"status": req.Status}
	now := time.Now()
	switch req.Status {
	case 1:
		updates["paid_at"] = now
	case 2:
		updates["shipped_at"] = now
	case 3:
		updates["completed_at"] = now
	}
	return s.orderRepo.Update(orderID, updates)
}

func generateOrderNo() string {
	id := uuid.New().String()
	// Format: 20240101-xxxxxxxx
	return fmt.Sprintf("%s-%s", time.Now().Format("20060102"), id[:8])
}
