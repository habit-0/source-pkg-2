package service

import (
	"fmt"

	"github.com/bookmall/backend/internal/model"
	"github.com/bookmall/backend/internal/repository"
)

type CartService struct {
	cartRepo *repository.CartRepository
	bookRepo *repository.BookRepository
}

func NewCartService(cartRepo *repository.CartRepository, bookRepo *repository.BookRepository) *CartService {
	return &CartService{cartRepo: cartRepo, bookRepo: bookRepo}
}

func (s *CartService) GetCart(userID uint) (*model.CartSummary, error) {
	items, err := s.cartRepo.GetUserCart(userID)
	if err != nil {
		return nil, err
	}

	var cartItems []model.CartItem
	var totalPrice float64
	var totalCount int

	for _, item := range items {
		if item.Book == nil {
			continue
		}
		stock := 0
		if item.Book.Inventory != nil {
			stock = item.Book.Inventory.Stock
		}
		subtotal := item.Book.Price * float64(item.Quantity)
		cartItems = append(cartItems, model.CartItem{
			ID:       item.ID,
			BookID:   item.BookID,
			Title:    item.Book.Title,
			Cover:    item.Book.Cover,
			Author:   item.Book.Author,
			Price:    item.Book.Price,
			Quantity: item.Quantity,
			Subtotal: subtotal,
			Stock:    stock,
		})
		totalPrice += subtotal
		totalCount += item.Quantity
	}

	return &model.CartSummary{
		Items:      cartItems,
		TotalCount: totalCount,
		TotalPrice: totalPrice,
	}, nil
}

func (s *CartService) AddToCart(userID uint, req *model.AddCartReq) error {
	// Check book exists and is on sale
	book, err := s.bookRepo.GetByID(req.BookID)
	if err != nil {
		return fmt.Errorf("图书不存在")
	}
	if book.Status != 1 {
		return fmt.Errorf("图书已下架")
	}

	// Check stock
	if book.Inventory == nil || book.Inventory.Stock < req.Quantity {
		return fmt.Errorf("库存不足")
	}

	// Check if already in cart
	existing, err := s.cartRepo.GetCartItem(userID, req.BookID)
	if err == nil {
		// Update quantity
		newQty := existing.Quantity + req.Quantity
		if newQty > 99 {
			newQty = 99
		}
		return s.cartRepo.UpdateQuantity(existing.ID, userID, newQty)
	}

	// Create new cart item
	return s.cartRepo.Create(&model.Cart{
		UserID:   userID,
		BookID:   req.BookID,
		Quantity: req.Quantity,
	})
}

func (s *CartService) UpdateQuantity(id, userID uint, req *model.UpdateCartReq) error {
	_, err := s.cartRepo.GetCartItemByID(id, userID)
	if err != nil {
		return fmt.Errorf("购物车条目不存在")
	}
	return s.cartRepo.UpdateQuantity(id, userID, req.Quantity)
}

func (s *CartService) DeleteCartItem(id, userID uint) error {
	return s.cartRepo.Delete(id, userID)
}

func (s *CartService) GetCartCount(userID uint) (int64, error) {
	return s.cartRepo.CountByUser(userID)
}
