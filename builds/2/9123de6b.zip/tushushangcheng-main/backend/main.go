package main

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/bookmall/backend/config"
	"github.com/bookmall/backend/internal/router"
	"github.com/bookmall/backend/pkg/database"
	jwtpkg "github.com/bookmall/backend/pkg/jwt"
	"github.com/bookmall/backend/pkg/logger"
	rdb "github.com/bookmall/backend/pkg/redis"
	"go.uber.org/zap"
)

func main() {
	// Load configuration
	configPath := "./config/config.yaml"
	if path := os.Getenv("CONFIG_PATH"); path != "" {
		configPath = path
	}

	conf, err := config.Load(configPath)
	if err != nil {
		fmt.Printf("Failed to load config: %v\n", err)
		os.Exit(1)
	}

	// Initialize logger
	if err := logger.Init(&conf.Log); err != nil {
		fmt.Printf("Failed to initialize logger: %v\n", err)
		os.Exit(1)
	}
	defer logger.Logger.Sync() //nolint:errcheck

	logger.Info("图书商城 API starting...",
		zap.String("version", conf.App.Version),
		zap.String("mode", conf.App.Mode),
	)

	// Initialize JWT
	jwtpkg.Init(conf.App.JwtSecret)

	// Initialize MySQL
	db, err := database.Init(&conf.Database)
	if err != nil {
		logger.Fatal("Failed to connect to MySQL", zap.Error(err))
	}
	logger.Info("MySQL connected successfully")

	// Initialize Redis
	_, err = rdb.Init(&conf.Redis)
	if err != nil {
		logger.Fatal("Failed to connect to Redis", zap.Error(err))
	}
	logger.Info("Redis connected successfully")

	// Setup router
	engine := router.Setup(conf, db)

	// Start HTTP server
	addr := fmt.Sprintf(":%d", conf.App.Port)
	srv := &http.Server{
		Addr:         addr,
		Handler:      engine,
		ReadTimeout:  30 * time.Second,
		WriteTimeout: 60 * time.Second,
		IdleTimeout:  120 * time.Second,
	}

	// Graceful shutdown
	go func() {
		logger.Info("Server starting", zap.String("addr", addr))
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			logger.Fatal("Failed to start server", zap.Error(err))
		}
	}()

	// Wait for interrupt signal
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit

	logger.Info("Server shutting down...")
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if err := srv.Shutdown(ctx); err != nil {
		logger.Fatal("Server forced to shutdown", zap.Error(err))
	}
	logger.Info("Server exited gracefully")
}
