package response

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

// Response is the unified API response structure
type Response struct {
	Code    int         `json:"code"`
	Message string      `json:"message"`
	Data    interface{} `json:"data,omitempty"`
}

// PageData wraps paginated data
type PageData struct {
	List     interface{} `json:"list"`
	Total    int64       `json:"total"`
	Page     int         `json:"page"`
	PageSize int         `json:"page_size"`
}

// Error codes
const (
	CodeSuccess      = 0
	CodeBadRequest   = 400
	CodeUnauthorized = 401
	CodeForbidden    = 403
	CodeNotFound     = 404
	CodeServerError  = 500

	CodeParamError   = 1001
	CodeUserExist    = 1002
	CodeUserNotExist = 1003
	CodePassError    = 1004
	CodeTokenInvalid = 1005
	CodeStockNotEnough = 2001
)

var codeMessages = map[int]string{
	CodeSuccess:        "success",
	CodeBadRequest:     "bad request",
	CodeUnauthorized:   "unauthorized",
	CodeForbidden:      "forbidden",
	CodeNotFound:       "not found",
	CodeServerError:    "internal server error",
	CodeParamError:     "参数错误",
	CodeUserExist:      "用户已存在",
	CodeUserNotExist:   "用户不存在",
	CodePassError:      "密码错误",
	CodeTokenInvalid:   "Token无效或已过期",
	CodeStockNotEnough: "库存不足",
}

func getMessage(code int) string {
	if msg, ok := codeMessages[code]; ok {
		return msg
	}
	return "unknown error"
}

// Success returns a successful response
func Success(c *gin.Context, data interface{}) {
	c.JSON(http.StatusOK, Response{
		Code:    CodeSuccess,
		Message: "success",
		Data:    data,
	})
}

// SuccessWithMsg returns a successful response with custom message
func SuccessWithMsg(c *gin.Context, msg string, data interface{}) {
	c.JSON(http.StatusOK, Response{
		Code:    CodeSuccess,
		Message: msg,
		Data:    data,
	})
}

// Fail returns a failed response
func Fail(c *gin.Context, code int, msg string) {
	if msg == "" {
		msg = getMessage(code)
	}
	c.JSON(http.StatusOK, Response{
		Code:    code,
		Message: msg,
	})
}

// BadRequest returns a 400 error
func BadRequest(c *gin.Context, msg string) {
	Fail(c, CodeBadRequest, msg)
}

// Unauthorized returns a 401 error
func Unauthorized(c *gin.Context, msg string) {
	if msg == "" {
		msg = getMessage(CodeUnauthorized)
	}
	c.JSON(http.StatusOK, Response{
		Code:    CodeUnauthorized,
		Message: msg,
	})
}

// Forbidden returns a 403 error
func Forbidden(c *gin.Context, msg string) {
	Fail(c, CodeForbidden, msg)
}

// NotFound returns a 404 error
func NotFound(c *gin.Context, msg string) {
	Fail(c, CodeNotFound, msg)
}

// ServerError returns a 500 error
func ServerError(c *gin.Context, msg string) {
	if msg == "" {
		msg = getMessage(CodeServerError)
	}
	Fail(c, CodeServerError, msg)
}

// PageSuccess returns paginated data
func PageSuccess(c *gin.Context, list interface{}, total int64, page, pageSize int) {
	c.JSON(http.StatusOK, Response{
		Code:    CodeSuccess,
		Message: "success",
		Data: PageData{
			List:     list,
			Total:    total,
			Page:     page,
			PageSize: pageSize,
		},
	})
}
