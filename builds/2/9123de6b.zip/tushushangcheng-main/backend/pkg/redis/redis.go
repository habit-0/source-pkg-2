package redis

import (
	"context"
	"fmt"
	"time"

	"github.com/bookmall/backend/config"
	"github.com/redis/go-redis/v9"
)

var Client *redis.Client

// Redis key prefixes
const (
	KeyBookList     = "book:list:"
	KeyBookDetail   = "book:detail:"
	KeyBookHot      = "book:hot"
	KeyBookRecommend = "book:recommend"
	KeyUserToken    = "user:token:"
	KeyAdminToken   = "admin:token:"
	KeyCartUser     = "cart:user:"
	KeyRateLimit    = "rate:limit:"
)

// Init initializes Redis client
func Init(cfg *config.RedisConfig) (*redis.Client, error) {
	client := redis.NewClient(&redis.Options{
		Addr:     cfg.Addr(),
		Password: cfg.Password,
		DB:       cfg.DB,
		PoolSize: cfg.PoolSize,
	})

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if _, err := client.Ping(ctx).Result(); err != nil {
		return nil, fmt.Errorf("failed to connect to redis: %w", err)
	}

	Client = client
	return client, nil
}

// Get retrieves a value from Redis
func Get(ctx context.Context, key string) (string, error) {
	return Client.Get(ctx, key).Result()
}

// Set stores a value in Redis with expiration
func Set(ctx context.Context, key string, value interface{}, expiration time.Duration) error {
	return Client.Set(ctx, key, value, expiration).Err()
}

// Del deletes one or more keys
func Del(ctx context.Context, keys ...string) error {
	return Client.Del(ctx, keys...).Err()
}

// Exists checks if a key exists
func Exists(ctx context.Context, key string) (bool, error) {
	n, err := Client.Exists(ctx, key).Result()
	return n > 0, err
}

// Expire sets key expiration
func Expire(ctx context.Context, key string, expiration time.Duration) error {
	return Client.Expire(ctx, key, expiration).Err()
}

// Incr increments a counter
func Incr(ctx context.Context, key string) (int64, error) {
	return Client.Incr(ctx, key).Result()
}

// TTL returns the remaining TTL of a key
func TTL(ctx context.Context, key string) (time.Duration, error) {
	return Client.TTL(ctx, key).Result()
}
