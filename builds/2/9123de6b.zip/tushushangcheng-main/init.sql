-- ============================================================
-- 图书商城系统数据库初始化脚本
-- 图书商城 System Database Initialization
-- ============================================================

CREATE DATABASE IF NOT EXISTS bookmall DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE bookmall;

-- ============================================================
-- 用户表
-- ============================================================
CREATE TABLE IF NOT EXISTS `users` (
  `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username`   VARCHAR(50)     NOT NULL COMMENT '用户名',
  `email`      VARCHAR(100)    NOT NULL COMMENT '邮箱',
  `password`   VARCHAR(255)    NOT NULL COMMENT '密码(bcrypt)',
  `nickname`   VARCHAR(50)     DEFAULT '' COMMENT '昵称',
  `avatar`     VARCHAR(500)    DEFAULT '' COMMENT '头像URL',
  `phone`      VARCHAR(20)     DEFAULT '' COMMENT '手机号',
  `status`     TINYINT         DEFAULT 1 COMMENT '状态: 1正常 0禁用',
  `created_at` DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` DATETIME        DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  UNIQUE KEY `uk_email` (`email`),
  KEY `idx_status` (`status`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- ============================================================
-- 用户收货地址表
-- ============================================================
CREATE TABLE IF NOT EXISTS `user_address` (
  `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`      BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
  `name`         VARCHAR(50)     NOT NULL COMMENT '收货人',
  `phone`        VARCHAR(20)     NOT NULL COMMENT '手机号',
  `province`     VARCHAR(50)     NOT NULL COMMENT '省份',
  `city`         VARCHAR(50)     NOT NULL COMMENT '城市',
  `district`     VARCHAR(50)     NOT NULL COMMENT '区县',
  `address`      VARCHAR(200)    NOT NULL COMMENT '详细地址',
  `is_default`   TINYINT         DEFAULT 0 COMMENT '是否默认: 1是 0否',
  `created_at`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`   DATETIME        DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户收货地址表';

-- ============================================================
-- 图书分类表
-- ============================================================
CREATE TABLE IF NOT EXISTS `book_category` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`        VARCHAR(50)     NOT NULL COMMENT '分类名称',
  `icon`        VARCHAR(100)    DEFAULT '' COMMENT '分类图标',
  `sort_order`  INT             DEFAULT 0 COMMENT '排序',
  `parent_id`   BIGINT UNSIGNED DEFAULT 0 COMMENT '父分类ID',
  `description` VARCHAR(200)    DEFAULT '' COMMENT '描述',
  `created_at`  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`  DATETIME        DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='图书分类表';

-- ============================================================
-- 图书表
-- ============================================================
CREATE TABLE IF NOT EXISTS `books` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title`         VARCHAR(200)    NOT NULL COMMENT '书名',
  `author`        VARCHAR(100)    NOT NULL COMMENT '作者',
  `publisher`     VARCHAR(100)    DEFAULT '' COMMENT '出版社',
  `isbn`          VARCHAR(20)     DEFAULT '' COMMENT 'ISBN',
  `category_id`   BIGINT UNSIGNED NOT NULL COMMENT '分类ID',
  `price`         DECIMAL(10,2)   NOT NULL COMMENT '价格',
  `original_price` DECIMAL(10,2)  DEFAULT 0 COMMENT '原价',
  `cover`         VARCHAR(500)    DEFAULT '' COMMENT '封面图URL',
  `description`   TEXT            COMMENT '简介',
  `tags`          VARCHAR(200)    DEFAULT '' COMMENT '标签(逗号分隔)',
  `status`        TINYINT         DEFAULT 1 COMMENT '状态: 1上架 0下架',
  `is_recommend`  TINYINT         DEFAULT 0 COMMENT '是否推荐',
  `is_hot`        TINYINT         DEFAULT 0 COMMENT '是否热门',
  `sales`         INT             DEFAULT 0 COMMENT '销量',
  `rating`        DECIMAL(3,1)    DEFAULT 5.0 COMMENT '评分',
  `publish_date`  DATE            DEFAULT NULL COMMENT '出版日期',
  `created_at`    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`    DATETIME        DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_category_id` (`category_id`),
  KEY `idx_status` (`status`),
  KEY `idx_is_recommend` (`is_recommend`),
  KEY `idx_is_hot` (`is_hot`),
  KEY `idx_deleted_at` (`deleted_at`),
  FULLTEXT KEY `ft_title_author` (`title`, `author`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='图书表';

-- ============================================================
-- 图书库存表
-- ============================================================
CREATE TABLE IF NOT EXISTS `book_inventory` (
  `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `book_id`    BIGINT UNSIGNED NOT NULL COMMENT '图书ID',
  `stock`      INT             NOT NULL DEFAULT 0 COMMENT '库存数量',
  `locked`     INT             NOT NULL DEFAULT 0 COMMENT '锁定库存(待支付)',
  `created_at` DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_book_id` (`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='图书库存表';

-- ============================================================
-- 购物车表
-- ============================================================
CREATE TABLE IF NOT EXISTS `cart` (
  `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
  `book_id`    BIGINT UNSIGNED NOT NULL COMMENT '图书ID',
  `quantity`   INT             NOT NULL DEFAULT 1 COMMENT '数量',
  `created_at` DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_book` (`user_id`, `book_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='购物车表';

-- ============================================================
-- 订单表
-- ============================================================
CREATE TABLE IF NOT EXISTS `orders` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_no`       VARCHAR(32)     NOT NULL COMMENT '订单号',
  `user_id`        BIGINT UNSIGNED NOT NULL COMMENT '用户ID',
  `total_price`    DECIMAL(10,2)   NOT NULL COMMENT '订单总价',
  `actual_price`   DECIMAL(10,2)   NOT NULL COMMENT '实付金额',
  `status`         TINYINT         NOT NULL DEFAULT 0 COMMENT '状态: 0待支付 1已支付 2已发货 3已完成 4已取消',
  `address_id`     BIGINT UNSIGNED DEFAULT NULL COMMENT '收货地址ID',
  `receiver_name`  VARCHAR(50)     DEFAULT '' COMMENT '收货人',
  `receiver_phone` VARCHAR(20)     DEFAULT '' COMMENT '收货手机',
  `receiver_addr`  VARCHAR(300)    DEFAULT '' COMMENT '收货地址(快照)',
  `remark`         VARCHAR(200)    DEFAULT '' COMMENT '备注',
  `paid_at`        DATETIME        DEFAULT NULL COMMENT '支付时间',
  `shipped_at`     DATETIME        DEFAULT NULL COMMENT '发货时间',
  `completed_at`   DATETIME        DEFAULT NULL COMMENT '完成时间',
  `created_at`     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`     DATETIME        DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_no` (`order_no`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表';

-- ============================================================
-- 订单明细表
-- ============================================================
CREATE TABLE IF NOT EXISTS `order_items` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `order_id`    BIGINT UNSIGNED NOT NULL COMMENT '订单ID',
  `book_id`     BIGINT UNSIGNED NOT NULL COMMENT '图书ID',
  `title`       VARCHAR(200)    NOT NULL COMMENT '书名(快照)',
  `cover`       VARCHAR(500)    DEFAULT '' COMMENT '封面(快照)',
  `author`      VARCHAR(100)    DEFAULT '' COMMENT '作者(快照)',
  `price`       DECIMAL(10,2)   NOT NULL COMMENT '单价(快照)',
  `quantity`    INT             NOT NULL COMMENT '数量',
  `subtotal`    DECIMAL(10,2)   NOT NULL COMMENT '小计',
  `created_at`  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_book_id` (`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单明细表';

-- ============================================================
-- 管理员表
-- ============================================================
CREATE TABLE IF NOT EXISTS `admin_users` (
  `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username`   VARCHAR(50)     NOT NULL COMMENT '用户名',
  `password`   VARCHAR(255)    NOT NULL COMMENT '密码',
  `nickname`   VARCHAR(50)     DEFAULT '' COMMENT '昵称',
  `email`      VARCHAR(100)    DEFAULT '' COMMENT '邮箱',
  `role`       VARCHAR(20)     DEFAULT 'admin' COMMENT '角色: super_admin/admin',
  `status`     TINYINT         DEFAULT 1 COMMENT '状态: 1正常 0禁用',
  `last_login` DATETIME        DEFAULT NULL COMMENT '最后登录时间',
  `created_at` DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` DATETIME        DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  KEY `idx_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='管理员表';

-- ============================================================
-- 初始化数据
-- ============================================================

-- 管理员账号 (密码: admin123)
INSERT INTO `admin_users` (`username`, `password`, `nickname`, `email`, `role`) VALUES
('admin', '$2b$10$5NeuIcwpEXjeBqYjU0oKRO9MQuiYEEx9yvPlFaaEurfG/PHpDCbg2', '超级管理员', 'admin@bookmall.com', 'super_admin');

-- 测试用户 (密码: test123)
INSERT INTO `users` (`username`, `email`, `password`, `nickname`) VALUES
('testuser', 'test@bookmall.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '测试用户');

-- 图书分类
INSERT INTO `book_category` (`id`, `name`, `icon`, `sort_order`) VALUES
(1, '文学小说', 'book-outline', 1),
(2, '科技计算机', 'laptop-outline', 2),
(3, '经济管理', 'trending-up-outline', 3),
(4, '历史文化', 'library-outline', 4),
(5, '教育考试', 'school-outline', 5),
(6, '艺术设计', 'color-palette-outline', 6),
(7, '生活健康', 'heart-outline', 7),
(8, '儿童读物', 'happy-outline', 8);

-- 示例图书数据
INSERT INTO `books` (`title`, `author`, `publisher`, `isbn`, `category_id`, `price`, `original_price`, `cover`, `description`, `is_recommend`, `is_hot`, `sales`, `rating`) VALUES
('活着', '余华', '作家出版社', '9787506365437', 1, 29.80, 39.80, 'https://img3m3.ddimg.cn/23/25/29311943-1_b_1747301862.jpg', '《活着》讲述了农村人福贵悲惨的人生遭遇。福贵本是个阔少爷，可他嗜赌如命，终于在一夜之间将家产输得精光，父亲因此被气死。', 1, 1, 52680, 9.4),
('三体', '刘慈欣', '重庆出版社', '9787536692930', 1, 45.00, 58.00, 'https://img3m4.ddimg.cn/32/35/23579654-1_b_1740123779.jpg', '文化大革命如火如荼进行的同时，军事科研机构开展了一个代号为"红岸"的绝密项目。', 1, 1, 98520, 9.4),
('百年孤独', '加西亚·马尔克斯', '南海出版公司', '9787544253994', 1, 49.50, 65.00, 'https://img3m0.ddimg.cn/46/30/29819440-1_b_1762827510.jpg', '《百年孤独》，是哥伦比亚作家加西亚·马尔克斯创作的长篇小说，是其代表作，也是拉丁美洲魔幻现实主义文学的代表作。', 1, 0, 45230, 9.3),
('深度学习', 'Ian Goodfellow', '人民邮电出版社', '9787115461476', 2, 168.00, 198.00, 'https://img3m5.ddimg.cn/42/27/29248305-1_b_1725326061.jpg', '深度学习领域的权威教材，由深度学习领域三位领军人物共同撰写。', 1, 1, 23450, 9.2),
('Go程序设计语言', 'Alan Donovan', '机械工业出版社', '9787111558422', 2, 79.00, 99.00, 'https://img3m2.ddimg.cn/76/19/11958194632-1_b_1750789869.jpg', 'Go语言官方推荐教程，全面介绍Go语言特性与最佳实践。', 0, 1, 18920, 9.1),
('乌合之众', '古斯塔夫·勒庞', '中央编译出版社', '9787511719515', 3, 25.00, 36.00, 'https://img3m9.ddimg.cn/25/29/25246609-1_b_1715221975.jpg', '研究大众心理的经典作品，深刻揭示群体行为的规律。', 0, 1, 67890, 8.9),
('人类简史', '尤瓦尔·赫拉利', '中信出版社', '9787508660752', 4, 68.00, 88.00, 'https://img3m6.ddimg.cn/97/31/29859586-1_b_1744096062.jpg', '从十万年前有生命迹象开始到21世纪资本、科技交织的人类发展史。', 1, 1, 89320, 9.1),
('小王子', '圣埃克苏佩里', '人民文学出版社', '9787020042494', 8, 22.00, 28.00, 'https://platform-permanent.ddimg.cn/pt-front-cms-upload-file/2025/12/19/2025121912002032910.png', '《小王子》是法国作家安托万·德·圣-埃克苏佩里于1943年出版的著名儿童文学短篇小说。', 1, 0, 34560, 9.0),
('明朝那些事儿', '当年明月', '中国海关出版社', '9787801657435', 4, 198.00, 258.00, 'https://img3m6.ddimg.cn/23/11/29296796-1_b_1723625443.jpg', '讲述了从1344年到1644年，共300年间关于明朝的一些事情。', 0, 1, 78650, 9.1),
('Python编程：从入门到实践', 'Eric Matthes', '人民邮电出版社', '9787115428028', 2, 79.80, 99.80, 'https://img3m9.ddimg.cn/23/13/29564789-1_b_1752223967.jpg', 'Python基础教程，适合零基础入门学习。', 1, 1, 56780, 8.8);

-- 库存数据
INSERT INTO `book_inventory` (`book_id`, `stock`) VALUES
(1, 1000), (2, 800), (3, 600), (4, 500), (5, 400),
(6, 300), (7, 700), (8, 900), (9, 200), (10, 600);
