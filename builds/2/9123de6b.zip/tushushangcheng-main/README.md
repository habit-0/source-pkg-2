# BookMall - 图书商城管理系统‍​​‌‌‌​​‌​​‌‌​​​‌​​‌‌​​‌​​​‌‌​​‌‌​‌‌​​‌​​​‌‌​​‌​‌​​‌‌​‌‌​​‌‌​​​‌​​​‌‌‌​​​​​‌‌​‌‌‌​​‌‌​​​​​‌‌​​​‌​​​‌‌‌​​​​‌‌​​‌‌​​‌‌​​​​‌​​‌‌​​​‌‍

> 前后端分离架构 · Go + Vue3 · 生产级代码标准

---

## 环境要求

| 依赖 | 最低版本 | 推荐版本 | 说明 |
|------|---------|---------|------|
| **Go** | 1.21 | 1.21+ | 后端编译运行 |
| **Node.js** | 16.x | 18.x LTS | 前端构建 |
| **npm** | 8.x | 9.x+ | 包管理 |
| **MySQL** | 5.7 | 8.0 | 关系型数据库 |
| **Redis** | 6.x | 7.x | 缓存 / Token 存储 |
| **Docker** | 20.x | 24.x+ | 容器化部署（可选） |
| **Docker Compose** | 2.x | 2.20+ | 容器编排（可选） |
| **Nginx** | 1.18 | 1.24+ | 反向代理（生产环境） |

### 操作系统支持

- Linux (Ubuntu 20.04+ / CentOS 7+ / Debian 11+)
- macOS 12+
- Windows 10+ (WSL2 推荐)

---

## 技术栈

### 后端

| 技术 | 版本 | 说明 |
|------|------|------|
| Go | 1.21 | 主要编程语言 |
| Gin | v1.9.1 | HTTP Web 框架 |
| GORM | v2.25 | ORM 框架 |
| MySQL Driver | v1.5.4 | MySQL 驱动 |
| go-redis | v9.4.0 | Redis 客户端 |
| JWT | v5.2.0 | 用户认证 (golang-jwt) |
| Zap | v1.26.0 | 结构化日志 |
| Viper | v1.18.2 | 配置管理 |
| bcrypt | - | 密码加密 (golang.org/x/crypto) |
| UUID | v1.5.0 | 订单号生成 |
| CORS | v1.5.0 | 跨域中间件 |

### 前端

| 技术 | 版本 | 说明 |
|------|------|------|
| Vue | ^3.4.0 | 前端框架 (Composition API + `<script setup>`) |
| Vite | ^5.0.8 | 构建工具 |
| TypeScript | ^5.3.2 | 类型安全 |
| NaiveUI | ^2.38.1 | UI 组件库 |
| Pinia | ^2.1.7 | 状态管理 |
| Vue Router | ^4.2.5 | 前端路由 (History 模式) |
| Axios | ^1.6.2 | HTTP 请求 |
| ECharts | ^5.4.3 | 数据可视化 |
| vue-echarts | ^6.6.9 | ECharts Vue 封装 |
| @vicons/ionicons5 | ^0.12.0 | 图标库 |
| dayjs | ^1.11.10 | 日期处理 |
| nprogress | ^0.2.0 | 路由加载进度条 |
| pinia-plugin-persistedstate | ^3.2.1 | Pinia 状态持久化 |

---

## 项目结构

```
tushushangcheng/
├── backend/                    # Go 后端
│   ├── config/
│   │   ├── config.go           # Viper 配置加载
│   │   └── config.yaml         # 配置文件
│   ├── internal/
│   │   ├── handler/            # HTTP 处理器层
│   │   ├── middleware/         # 中间件 (JWT, CORS, 日志, 限流)
│   │   ├── model/              # GORM 数据模型
│   │   ├── repository/         # 数据访问层
│   │   ├── router/             # 路由注册
│   │   └── service/            # 业务逻辑层
│   ├── pkg/
│   │   ├── database/           # MySQL 连接池
│   │   ├── jwt/                # JWT 工具
│   │   ├── logger/             # Zap 日志
│   │   ├── redis/              # Redis 客户端
│   │   └── response/           # 统一响应结构
│   ├── main.go                 # 入口文件
│   ├── Dockerfile              # 后端镜像构建
│   ├── go.mod
│   └── go.sum
├── frontend/                   # Vue3 前端
│   ├── src/
│   │   ├── api/                # Axios API 模块
│   │   ├── components/         # 公共组件 (BookCard 等)
│   │   ├── layouts/            # 布局 (DefaultLayout, AdminLayout)
│   │   ├── router/             # Vue Router 配置
│   │   ├── stores/             # Pinia 状态
│   │   ├── styles/             # 全局样式
│   │   └── views/
│   │       ├── admin/          # 管理后台 (Dashboard, Books, Orders...)
│   │       ├── Home.vue        # 用户端首页
│   │       ├── BookList.vue    # 图书列表
│   │       ├── BookDetail.vue  # 图书详情
│   │       ├── Cart.vue        # 购物车
│   │       ├── Orders.vue      # 我的订单
│   │       └── ...
│   ├── Dockerfile              # 前端镜像构建 (多阶段: node→nginx)
│   ├── vite.config.ts
│   ├── tsconfig.json
│   └── package.json
├── nginx/
│   └── nginx.conf              # Nginx 反向代理配置
├── docker-compose.yml          # 容器编排 (MySQL + Redis + 后端 + 前端)
├── init.sql                    # 数据库初始化脚本 (DDL + 种子数据)
├── .gitignore
└── README.md
```

---

## 功能模块

### 用户端
- **首页**: 推荐图书、热门图书、分类导航
- **图书列表**: 分类筛选、关键词搜索、排序
- **图书详情**: 详细信息、加入购物车、库存状态
- **购物车**: 增减数量、删除商品、选择结算
- **订单系统**: 创建订单、模拟支付、查看状态、订单详情
- **用户中心**: 个人信息、地址管理、修改密码

### 管理后台
- **控制台**: 数据概览 (ECharts 图表：销售趋势、分类分布、热销排行)
- **图书管理**: CRUD、上下架、库存管理
- **分类管理**: 增删改查、树形层级
- **订单管理**: 查询、发货、状态跟踪
- **用户管理**: 查询、封禁/解封
- **数据统计**: 销售趋势、分类分布、热销排行

---

## 快速启动

### 方式一：Docker Compose（推荐，一键启动）

```bash
# 1. 克隆项目
git clone <repo-url>
cd tushushangcheng

# 2. 启动所有服务（MySQL + Redis + 后端 + 前端）
docker-compose up -d

# 3. 等待 MySQL 初始化完成（首次约 30 秒）
docker-compose logs -f mysql   # 看到 "ready for connections" 即可 Ctrl+C

# 4. 访问
# 用户端:    http://localhost
# 管理后台:  http://localhost/admin
# API:       http://localhost:8080
```

**停止 / 销毁：**

```bash
# 停止服务（保留数据）
docker-compose stop

# 停止并删除容器+网络（数据卷保留）
docker-compose down

# 停止并删除所有（包括数据卷，慎用）
docker-compose down -v
```

### 方式二：本地开发

#### 1. 准备数据库

```bash
# 确保 MySQL 8.0 和 Redis 7.x 已启动
# 导入数据库
mysql -u root -p < init.sql
```

#### 2. 启动后端

```bash
cd backend

# 安装 Go 依赖
go mod download

# 修改数据库/Redis 配置
vim config/config.yaml

# 运行（开发模式）
go run main.go

# 或编译后运行
go build -o bookmall-api . && ./bookmall-api
```

后端启动后监听 `http://localhost:8080`。

#### 3. 启动前端

```bash
cd frontend

# 安装依赖
npm install

# 开发模式（热更新，自动代理 /api → localhost:8080）
npm run dev

# 访问 http://localhost:3000
```

#### 4. 生产构建

```bash
cd frontend

# TypeScript 检查 + 构建
npm run build

# 产物在 frontend/dist/ 目录
# 使用 Nginx 托管 dist 并反代 /api → 后端
```

---

## 环境配置

编辑 `backend/config/config.yaml`：

```yaml
app:
  name: "图书商城 API"
  version: "1.0.0"
  port: 8080
  mode: "debug"           # debug | release | test

database:
  host: "localhost"       # Docker 环境用 mysql
  port: 3306
  user: "bookmall"
  password: "bookmall123"
  dbname: "bookmall"
  charset: "utf8mb4"
  max_open_conns: 100
  max_idle_conns: 20
  conn_max_lifetime: 3600 # 秒

redis:
  host: "localhost"       # Docker 环境用 redis
  port: 6379
  password: "bookmall123"
  db: 0
  pool_size: 10

jwt:
  secret: "your_jwt_secret_key"  # 生产环境务必修改
  expire: 72              # Token 有效期（小时）

log:
  level: "debug"          # debug | info | warn | error
  filename: "./logs/bookmall.log"
  max_size: 100           # MB
  max_age: 30             # 天
  max_backups: 5
  compress: true
```

> **注意**：Docker Compose 环境下，`database.host` 改为 `mysql`，`redis.host` 改为 `redis`（使用 Docker 内部 DNS）。

---

## 数据库设计

核心表结构（详细 DDL 见 `init.sql`）：

| 表名 | 说明 | 关键字段 |
|------|------|---------|
| `users` | 用户信息 | username, email, password(bcrypt), status |
| `user_address` | 用户收货地址 | user_id, 省市区, is_default |
| `books` | 图书信息 | title, author, price, category_id, status |
| `book_category` | 图书分类 | name, parent_id, sort_order |
| `book_inventory` | 图书库存 | book_id, stock, locked |
| `cart` | 购物车 | user_id, book_id, quantity |
| `orders` | 订单主表 | order_no(UUID), user_id, total_price, status |
| `order_items` | 订单商品明细 | order_id, book_id, price(快照), quantity |
| `admin_users` | 管理员账号 | username, password, role |

---

## Redis 缓存策略

| Key 模式 | 用途 | TTL |
|----------|------|-----|
| `books:list:*` | 图书列表缓存 | 5 min |
| `books:hot` | 热门图书 | 10 min |
| `books:recommend` | 首页推荐 | 10 min |
| `books:detail:{id}` | 图书详情 | 30 min |
| `user:token:{id}` | 登录 Token | 7 day |
| `cart:{uid}` | 购物车缓存 | 1 day |
| `rate:{ip}` | 接口限流 | 1 min |

---

## API 设计

### 统一返回结构

```json
{
  "code": 0,
  "message": "success",
  "data": {}
}
```

| code | 含义 |
|------|------|
| 0 | 成功 |
| 400 | 参数错误 |
| 401 | 未认证 / Token 过期 |
| 403 | 无权限 |
| 404 | 资源不存在 |
| 500 | 服务器内部错误 |

### 主要接口

**认证**
```
POST /api/auth/login        用户登录
POST /api/auth/register     用户注册
POST /api/admin/login       管理员登录
```

**图书**
```
GET  /api/books             图书列表 (分页/搜索/分类)
GET  /api/books/:id         图书详情
GET  /api/books/hot         热门图书
GET  /api/books/recommend   推荐图书
GET  /api/categories        图书分类
```

**购物车（需登录）**
```
GET    /api/cart            购物车列表
POST   /api/cart            加入购物车
PUT    /api/cart/:id        修改数量
DELETE /api/cart/:id        删除商品
```

**订单（需登录）**
```
POST /api/orders            创建订单
GET  /api/orders            订单列表
GET  /api/orders/:id        订单详情
POST /api/orders/:id/pay    支付订单
POST /api/orders/:id/cancel 取消订单
```

**管理员（需管理员 Token）**
```
GET  /api/admin/dashboard              控制台数据
GET  /api/admin/books                  图书列表 (管理)
POST /api/admin/books                  添加图书
PUT  /api/admin/books/:id              修改图书
DEL  /api/admin/books/:id              删除图书
GET  /api/admin/orders                 订单列表
PUT  /api/admin/orders/:id/status      更新订单状态
GET  /api/admin/users                  用户列表
PUT  /api/admin/users/:id/status       更新用户状态
GET  /api/admin/categories             分类列表
POST /api/admin/categories             新增分类
PUT  /api/admin/categories/:id         修改分类
DEL  /api/admin/categories/:id         删除分类
GET  /api/admin/stats                  统计数据
```

---

## 生产部署

### 方案 A：Docker Compose（推荐）

```bash
# 1. 修改配置（生产密码、JWT secret）
vim backend/config/config.yaml
vim docker-compose.yml    # 修改 MYSQL_ROOT_PASSWORD 等

# 2. 启动
docker-compose up -d --build

# 3. 检查健康
curl http://localhost:8080/health
```

### 方案 B：手动部署（Ubuntu/CentOS）

```bash
# ── 1. 编译后端 ──
cd backend
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -o bookmall-api .

# ── 2. 构建前端 ──
cd frontend
npm ci
npm run build     # 产物 → frontend/dist/

# ── 3. 上传到服务器 ──
scp bookmall-api user@server:/opt/bookmall/
scp -r frontend/dist/ user@server:/opt/bookmall/frontend/
scp backend/config/config.yaml user@server:/opt/bookmall/config/
scp nginx/nginx.conf user@server:/etc/nginx/conf.d/bookmall.conf

# ── 4. 服务器上 ──
# 导入数据库
mysql -u root -p < init.sql

# 启动后端（使用 systemd 或 nohup）
nohup /opt/bookmall/bookmall-api &

# 配置 Nginx
# 修改 nginx.conf 中 root 为 /opt/bookmall/frontend/dist
# 修改 proxy_pass 为 http://127.0.0.1:8080
nginx -t && systemctl reload nginx
```

### Nginx 生产配置要点

```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /opt/bookmall/frontend/dist;
    index index.html;

    # Vue Router History 模式
    location / {
        try_files $uri $uri/ /index.html;
    }

    # API 反向代理
    location /api/ {
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # 静态资源缓存
    location ~* \.(js|css|png|jpg|ico|svg|woff2?)$ {
        expires 7d;
        add_header Cache-Control "public, immutable";
    }
}
```

### Systemd 服务配置（可选）

创建 `/etc/systemd/system/bookmall.service`：

```ini
[Unit]
Description=BookMall API Server
After=network.target mysql.service redis.service

[Service]
Type=simple
User=www-data
WorkingDirectory=/opt/bookmall
ExecStart=/opt/bookmall/bookmall-api
Restart=always
RestartSec=5
Environment=GIN_MODE=release

[Install]
WantedBy=multi-user.target
```

```bash
systemctl daemon-reload
systemctl enable bookmall
systemctl start bookmall
systemctl status bookmall
```

---

## 初始账号

| 类型 | 账号 | 密码 | 访问地址 |
|------|------|------|---------|
| 管理员 | admin | admin123 | /admin |
| 测试用户 | testuser | test123 | / |

> **生产环境部署后请立即修改默认密码。**

---

## 开发规范

- **后端**: Go 标准项目布局，handler → service → repository 三层架构
- **前端**: 组件化开发，Composition API + `<script setup>`，TypeScript 严格类型
- **API**: RESTful 风格，统一错误码，统一响应格式
- **日志**: 结构化日志 (Zap)，按天轮转，保留 30 天
- **安全**: JWT 鉴权，密码 bcrypt 加密，GORM 防 SQL 注入，CORS 白名单
- **缓存**: Redis 缓存热点数据，写操作后主动失效

---

## 常见问题

### Q: `npm run build` 报 TypeScript 错误？
确保 Node.js >= 16，执行 `npm install` 安装所有依赖后重试。

### Q: 后端连接 MySQL 失败？
检查 `config.yaml` 中数据库配置，确保 MySQL 已启动且 `bookmall` 数据库已创建（执行 `init.sql`）。

### Q: Docker Compose 启动后前端白屏？
等待 MySQL 初始化完成后重启后端容器：`docker-compose restart backend`。

### Q: Redis 连接被拒绝？
检查 Redis 密码配置，Docker 环境默认密码为 `bookmall123`。

---

## License

MIT
